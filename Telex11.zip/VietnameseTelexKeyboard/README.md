# Bàn Phím Telex (Vietnamese Telex Android Keyboard)

Một bàn phím ảo Android (IME) với bố cục dạng QWERTY giống bàn phím PC,
gõ tiếng Việt theo kiểu **Telex** (giống Unikey/EVKey khi bật Telex trên máy tính).

## Cấu trúc dự án

```
VietnameseTelexKeyboard/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/telexkeyboard/
│       │   ├── TelexEngine.kt   # bộ xử lý quy tắc gõ Telex -> tiếng Việt
│       │   ├── TelexIME.kt      # InputMethodService + bàn phím
│       │   ├── VoiceInputActivity.kt # nhập bằng giọng nói tiếng Việt
│       │   └── SetupActivity.kt # màn hình hướng dẫn bật bàn phím
│       └── res/
│           ├── xml/
│           │   ├── method.xml
│           │   ├── keyboard_qwerty.xml   # layout QWERTY chính
│           │   └── keyboard_symbols.xml  # layout số/ký hiệu (phím ?123)
│           ├── mipmap-anydpi-v26/        # icon adaptive (API 26+)
│           ├── mipmap/ic_launcher.xml    # icon fallback (API 21-25)
│           └── values/strings.xml
├── app/proguard-rules.pro
├── PRIVACY_POLICY.md
├── build.gradle
└── settings.gradle
```

## Cách build & cài đặt

1. Mở thư mục `VietnameseTelexKeyboard` bằng **Android Studio** (File → Open).
2. Đợi Gradle sync xong (cần kết nối mạng để tải Gradle/AGP/Kotlin lần đầu).
3. Cắm điện thoại (hoặc dùng máy ảo) và bấm **Run ▶**.
4. App sẽ mở màn hình hướng dẫn — bấm **"Mở cài đặt bàn phím"** rồi bật
   **"Bàn Phím Telex"** trong danh sách bàn phím của Android.
5. Vào một ô nhập văn bản bất kỳ (Tin nhắn, Ghi chú...), chạm giữ biểu
   tượng chuyển bàn phím (hoặc phím dấu cách khi có nhiều bàn phím) để
   chọn "Bàn Phím Telex".
6. Chạm biểu tượng **micro** trên thanh công cụ, cấp quyền micro khi được
   hỏi, nói tiếng Việt rồi xác nhận kết quả để chèn vào ô nhập.

## Quy tắc gõ Telex đã hỗ trợ

| Gõ | Ra | Gõ | Ra |
|----|----|----|----|
| aa | â  | dd | đ  |
| aw | ă  | s  | dấu sắc (á) |
| ee | ê  | f  | dấu huyền (à) |
| oo | ô  | r  | dấu hỏi (ả) |
| ow | ơ  | x  | dấu ngã (ã) |
| uw | ư  | j  | dấu nặng (ạ) |
| w  | ư (gõ riêng lẻ) | z | xóa dấu vừa đặt |

Ví dụ: `vieejt nam` → `việt nam`, `chaof` → `chào`, `ddeejp` → `đẹp`.

## Giới hạn hiện tại (v1)

- Việc đặt dấu thanh vào đúng nguyên âm trong các cụm 2–3 nguyên âm dùng
  quy tắc phổ biến (ưu tiên nguyên âm đã biến đổi như ê/ơ/ư; nếu không,
  âm tiết đóng → dấu ở nguyên âm cuối, âm tiết mở → dấu ở nguyên âm đầu).
  Đây là quy tắc chuẩn cho phần lớn trường hợp, nhưng vài từ hiếm có thể
  cần bạn gõ lại `z` rồi gõ dấu ở vị trí khác nếu sai.
- Chưa có gợi ý từ (word suggestion). Đây là hướng có thể mở rộng thêm sau.
- Có 2 tính năng tự sửa lỗi gõ chạy âm thầm (không hỏi xác nhận): nhận
  diện từ tiếng Anh gõ xen giữa câu tiếng Việt (`EnglishWordList`) và tự
  sửa vị trí dấu thanh sai trong câu (`VietnameseDiacriticFixer`). Từ
  điển tiếng Anh và tiếng Việt hiện chỉ có khoảng 150 từ, chọn thủ công,
  nên vẫn có thể sửa sai với từ hiếm. Có thể tắt riêng từng tính năng ở
  màn hình cài đặt ("Tự nhận từ tiếng Anh" / "Tự sửa dấu câu tiếng
  Việt").

## Nhấn giữ phím

- **Nhấn giữ hàng số** (1-0): hiện popup ký hiệu tương ứng
  (`1→!`, `2→@`, `3→#`, `4→$`, `5→%`, `6→^`, `7→&`, `8→*`, `9→(`, `0→)`).
  Trượt ngón tay lên ô ký hiệu trong popup rồi thả ra để gõ ký hiệu đó.
- **Nhấn giữ phím Xóa**: tự lặp lại khi giữ (`isRepeatable` trong XML).
- **Di chuyển con trỏ**: dùng cụm phím mũi tên trên thanh công cụ (không
  phải vuốt trên bàn phím) — giữ để tự lặp lại liên tục.
- **Chuyển QWERTY ⇄ Ký hiệu**: chạm phím `?123` / `ABC`.

> Bàn phím dùng `android.inputmethodservice.KeyboardView` (API cũ nhưng
> vẫn hoạt động tốt trên mọi phiên bản Android hiện hành). Toàn bộ thao
> tác chạm được xử lý theo cơ chế mặc định của `KeyboardView` — không có
> tính năng vuốt cử chỉ (đổi lớp bàn phím, di chuyển con trỏ, ẩn bàn
> phím bằng vuốt) hay gõ vuốt liên tục (glide typing); các phiên bản rất
> sớm của project có thử nghiệm việc này nhưng đã gỡ bỏ hoàn toàn để đơn
> giản hóa và tránh xung đột thao tác chạm với các phím thường.

## Phím Enter thông minh theo ô nhập

Nhãn và hành vi phím Enter tự đổi theo `EditorInfo.imeOptions` mà ô nhập
đang focus khai báo — giống hầu hết bàn phím khác:

| Hành động ô nhập khai báo | Nhãn hiện | Khi bấm |
|---|---|---|
| Tìm kiếm (`IME_ACTION_SEARCH`) | Tìm | gọi hành động Tìm của ô nhập |
| Gửi (`IME_ACTION_SEND`) | Gửi | gọi hành động Gửi |
| Đi (`IME_ACTION_GO`) | Đi | gọi hành động Đi |
| Tiếp theo (`IME_ACTION_NEXT`) | Tiếp | nhảy sang ô nhập kế tiếp |
| Xong (`IME_ACTION_DONE`) | Xong | gọi hành động Xong |
| Không khai báo / đa dòng | ⏎ | xuống dòng bình thường |

Nhờ vậy Enter thật sự "gửi"/"tìm" được trong các app chỉ lắng nghe
`performEditorAction()` (khung chat, ô tìm kiếm, form nhiều trường) thay
vì chỉ xuống dòng như khi gửi phím Enter thô.

## Mở rộng thêm

- Muốn giao diện đẹp hơn (theo Material 3, có preview phím nổi khi
  chạm...) thì viết lại `onCreateInputView()` bằng Jetpack Compose hoặc
  custom View thay vì `KeyboardView` cũ.
- Muốn gõ kiểu VNI thay vì Telex: chỉ cần viết thêm một `VniEngine.kt`
  tương tự và cho người dùng chọn kiểu gõ trong `SetupActivity`.

## Phát hành bản release

- **Icon**: icon adaptive thật ở `app/src/main/res/mipmap-anydpi-v26/`
  (nền + biểu tượng chữ "đ" cách điệu) cho Android 8+, và bản vector gộp
  ở `app/src/main/res/mipmap/ic_launcher.xml` làm dự phòng cho Android
  5.0–7.1. Muốn đổi thiết kế: sửa
  `drawable/ic_launcher_background.xml` và
  `drawable/ic_launcher_foreground.xml`, rồi cập nhật lại bản gộp trong
  `mipmap/ic_launcher.xml` cho khớp.
- **versionCode / versionName**: khai báo trong `app/build.gradle`.
  Tăng `versionCode` thêm 1 ở MỌI bản build nộp lên Play Store (bắt
  buộc, phải tăng dần); `versionName` tuỳ bạn đặt sao cho người dùng dễ
  hiểu (bản này là `1.2`, có thêm nhập bằng giọng nói).
- **targetSdk / compileSdk**: hiện đang ở **35** (Android 15) — mức tối
  thiểu Google Play yêu cầu cho ứng dụng **đã phát hành** kể từ
  31/8/2026. Ứng dụng **mới** hoặc **bản cập nhật mới** nộp sau mốc đó
  cần target **36** (Android 16), đòi hỏi nâng lên AGP 9.x — một bản
  nâng cấp lớn (đổi hẳn kiểu DSL, không tương thích ngược với plugin
  `kotlin-android` đang dùng) nên chưa làm sẵn ở đây; làm riêng thành
  một bước độc lập, theo dõi kỹ qua GitHub Actions, khi nào chuẩn bị
  phát hành thật. AGP đã nâng lên **8.6.0** để hỗ trợ compileSdk 35 —
  nếu build qua GitHub Actions, nhớ nâng dòng `gradle-version: 8.5`
  trong file workflow lên **8.7** trở lên (AGP 8.6 yêu cầu Gradle tối
  thiểu 8.7), vì file workflow không nằm trong project này.
- **ProGuard/R8**: `buildTypes.release` đã bật `minifyEnabled true` +
  `shrinkResources true`, dùng rule ở `app/proguard-rules.pro`. Build
  release: `./gradlew assembleRelease` (hoặc `bundleRelease` cho AAB).
- **Ký ứng dụng (signing)**: dự án **không** kèm theo keystore (đây là
  bí mật, không nên đưa vào repo — mất keystore nghĩa là không thể phát
  hành bản cập nhật cho cùng một app trên Play Store nữa). Xem hướng
  dẫn tạo keystore + khai báo `signingConfig` ngay trong comment ở đầu
  `app/build.gradle`.
- **Chính sách quyền riêng tư**: `PRIVACY_POLICY.md` ở thư mục gốc —
  nội dung giống hệt màn hình "Chính sách quyền riêng tư" trong app
  (`PrivacyPolicyActivity`, đọc từ `res/raw/privacy_policy.txt`). Play
  Console yêu cầu một **URL công khai** cho chính sách này — host file
  `PRIVACY_POLICY.md` ở đâu đó công khai (GitHub Pages, Gist, trang web
  riêng...) rồi dán URL đó vào Play Console. Sửa nội dung ở cả hai chỗ
  nếu chính sách thay đổi (hai bản hiện đang giống hệt nhau).
