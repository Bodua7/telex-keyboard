package com.example.telexkeyboard

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoFixPolicyTest {

    @Test
    fun shouldFixEnglishWord_trueWhenAllConditionsMet() {
        assertTrue(
            AutoFixPolicy.shouldFixEnglishWord(
                vietnameseOn = true,
                composedLength = 3,
                rawWord = "was",
                autoFixEnabled = true
            )
        )
    }

    @Test
    fun shouldFixEnglishWord_falseWhenSettingTurnedOff() {
        assertFalse(
            AutoFixPolicy.shouldFixEnglishWord(
                vietnameseOn = true,
                composedLength = 3,
                rawWord = "was",
                autoFixEnabled = false
            )
        )
    }

    @Test
    fun shouldFixEnglishWord_falseWhenVietnameseModeOff() {
        assertFalse(
            AutoFixPolicy.shouldFixEnglishWord(
                vietnameseOn = false,
                composedLength = 3,
                rawWord = "was",
                autoFixEnabled = true
            )
        )
    }

    @Test
    fun shouldFixEnglishWord_falseWhenNothingWasComposed() {
        assertFalse(
            AutoFixPolicy.shouldFixEnglishWord(
                vietnameseOn = true,
                composedLength = 0,
                rawWord = "was",
                autoFixEnabled = true
            )
        )
    }

    @Test
    fun shouldFixEnglishWord_falseWhenNotAnEnglishWord() {
        assertFalse(
            AutoFixPolicy.shouldFixEnglishWord(
                vietnameseOn = true,
                composedLength = 3,
                rawWord = "khong_phai_tu_tieng_anh",
                autoFixEnabled = true
            )
        )
    }

    @Test
    fun shouldFixDiacritics_trueOnlyWhenVietnameseOnAndEnabled() {
        assertTrue(AutoFixPolicy.shouldFixDiacritics(vietnameseOn = true, autoFixEnabled = true))
        assertFalse(AutoFixPolicy.shouldFixDiacritics(vietnameseOn = false, autoFixEnabled = true))
        assertFalse(AutoFixPolicy.shouldFixDiacritics(vietnameseOn = true, autoFixEnabled = false))
    }
}
