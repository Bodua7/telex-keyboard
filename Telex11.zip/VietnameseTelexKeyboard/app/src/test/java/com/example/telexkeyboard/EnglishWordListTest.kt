package com.example.telexkeyboard

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnglishWordListTest {

    @Test
    fun contains_commonEnglishWords() {
        assertTrue(EnglishWordList.contains("was"))
        assertTrue(EnglishWordList.contains("is"))
        assertTrue(EnglishWordList.contains("as"))
        assertTrue(EnglishWordList.contains("wifi"))
        assertTrue(EnglishWordList.contains("WAS")) // case-insensitive
    }

    @Test
    fun contains_isFalseForVietnameseSyllables() {
        assertFalse(EnglishWordList.contains("việt"))
        assertFalse(EnglishWordList.contains("không"))
    }

    @Test
    fun theWordsTelexWouldActuallyMangle_transformDiffersFromRaw() {
        // Sanity check that the words this feature exists for really are
        // ones TelexEngine changes — otherwise TelexIME's "only fix if
        // transformed != raw" guard would just never fire for them.
        assertTrue(TelexEngine.transform("was") != "was")
        assertTrue(TelexEngine.transform("is") != "is")
        assertTrue(TelexEngine.transform("as") != "as")
    }
}
