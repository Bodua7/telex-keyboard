package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Test

class EmojiDataTest {

    @Test
    fun emojiList_hasNoDuplicates() {
        assertEquals(
            "emojiList has a duplicate entry — each repeat wastes a grid cell " +
                "that could show a different emoji",
            EmojiData.emojiList.size,
            EmojiData.emojiList.distinct().size
        )
    }

    @Test
    fun symbolList_hasNoDuplicates() {
        assertEquals(
            "symbolList has a duplicate entry — each repeat wastes a grid cell " +
                "that could show a different symbol",
            EmojiData.symbolList.size,
            EmojiData.symbolList.distinct().size
        )
    }
}
