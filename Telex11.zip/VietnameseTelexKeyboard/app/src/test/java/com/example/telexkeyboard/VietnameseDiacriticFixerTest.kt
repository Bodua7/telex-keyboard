package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Regression tests for VietnameseDiacriticFixer + the toneless-skeleton
 * dictionary index it relies on. Run with: ./gradlew test
 */
class VietnameseDiacriticFixerTest {

    @Test
    fun toneless_stripsOnlyToneMarks_keepsVowelIdentity() {
        // "tấm" = t + â(sắc) + m -> toneless keeps the "â" identity,
        // it must NOT collapse down to plain "a".
        assertEquals("tâm", TelexEngine.toneless("tấm"))
        assertEquals("Duong", TelexEngine.toneless("Dương"))
        assertEquals("duoc", TelexEngine.toneless("được"))
    }

    @Test
    fun fix_leavesAlreadyCorrectSentenceUntouched() {
        assertNull(VietnameseDiacriticFixer.fix("tôi là người việt nam"))
    }

    @Test
    fun fix_leavesAmbiguousSkeletonAlone() {
        // "ba" and "bà" are both real dictionary words with the same
        // skeleton — must NOT be guessed at.
        assertNull(VietnameseDiacriticFixer.fix("ba di dau vay"))
    }

    @Test
    fun fix_correctsUnambiguousSkeletonMatch() {
        // "day" has no tone marks at all but its skeleton only matches one
        // dictionary word ("dạy") — safe to auto-fix.
        assertEquals("dạy", VietnameseDiacriticFixer.fix("day"))
    }

    @Test
    fun fix_isNoOpWhenWordIsAlreadyInDictionary() {
        // Sanity check: a correctly-typed dictionary word is never
        // "fixed" into something else.
        assertNull(VietnameseDiacriticFixer.fix("cảm ơn bạn nhé"))
    }
}
