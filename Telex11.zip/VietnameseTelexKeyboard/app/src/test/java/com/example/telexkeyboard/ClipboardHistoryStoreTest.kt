package com.example.telexkeyboard

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ClipboardHistoryStoreTest {

    @Test
    fun looksSensitive_trueForShortDigitRuns() {
        assertTrue(ClipboardHistoryStore.looksSensitive("123456")) // typical OTP
        assertTrue(ClipboardHistoryStore.looksSensitive("123 456"))
        assertTrue(ClipboardHistoryStore.looksSensitive("123-456"))
    }

    @Test
    fun looksSensitive_falseForOrdinaryCopiedText() {
        assertFalse(ClipboardHistoryStore.looksSensitive("Hẹn gặp lúc 7 giờ tối nhé"))
        assertFalse(ClipboardHistoryStore.looksSensitive("https://example.com"))
        assertFalse(ClipboardHistoryStore.looksSensitive("ab")) // too short to matter
    }

    @Test
    fun looksSensitive_falseForLongDigitRuns() {
        // A long number (e.g. a copied phone/account number) shouldn't be
        // swallowed by the OTP heuristic — only SHORT all-digit runs are.
        assertFalse(ClipboardHistoryStore.looksSensitive("0123456789012"))
    }

    @Test
    fun onNewClip_addsOrdinaryTextToHistory() {
        val store = ClipboardHistoryStore()
        store.onNewClip("hello world")
        val rows = store.rows("Đã ghim", "Gần đây", "Trống")
        assertTrue(rows.any { it is ClipboardRow.Item && it.text == "hello world" })
    }

    @Test
    fun onNewClip_skipsOtpLikeText() {
        val store = ClipboardHistoryStore()
        store.onNewClip("482913")
        assertTrue(store.isEmpty())
    }

    @Test
    fun onNewClip_deduplicatesAndMovesToFront() {
        val store = ClipboardHistoryStore()
        store.onNewClip("first")
        store.onNewClip("second")
        store.onNewClip("first")
        val items = store.rows("P", "R", "E").filterIsInstance<ClipboardRow.Item>()
        assertTrue(items.first().text == "first")
        assertTrue(items.count { it.text == "first" } == 1)
    }
}
