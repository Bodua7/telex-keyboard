package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

/**
 * Bộ test hồi quy cho TelexEngine.transform(). Chạy bằng:
 *   ./gradlew test
 * hoặc trong CI thêm bước:
 *   - run: ./gradlew test
 *
 * Mỗi case là một cặp (chuỗi Telex gõ vào, kết quả tiếng Việt mong đợi).
 * Khi sửa TelexEngine, chạy lại bộ này để chắc chắn không hồi quy các quy
 * tắc đã đúng trước đó.
 */
@RunWith(Parameterized::class)
class TelexEngineTest(
    private val input: String,
    private val expected: String
) {

    @Test
    fun transform_matchesExpected() {
        assertEquals(
            "transform(\"$input\") sai",
            expected,
            TelexEngine.transform(input)
        )
    }

    companion object {
        @JvmStatic
        @Parameterized.Parameters(name = "{0} -> {1}")
        fun cases(): List<Array<String>> = listOf(
            // --- Nguyên âm biến đổi cơ bản (doubling) ---
            arrayOf("aa", "â"),
            arrayOf("ee", "ê"),
            arrayOf("oo", "ô"),
            arrayOf("khoong", "không"),
            arrayOf("xuaan", "xuân"), // â áp dụng lùi lại qua phụ âm đứng giữa

            // --- Móc (horn): a->ă, o->ơ, u->ư qua phím w ---
            arrayOf("aw", "ă"),
            arrayOf("ow", "ơ"),
            arrayOf("uw", "ư"),
            arrayOf("thuowng", "thương"), // uo + w (ngay sau "uo") -> ươ áp dụng cả 2 nguyên âm
            arrayOf("nuoc", "nuoc"),      // chưa gõ w thì chưa biến đổi
            arrayOf("nuowc", "nươc"),
            arrayOf("quow", "quơ"),       // u sau q là âm đệm câm, không nhận móc

            // --- w gõ đơn lẻ -> ư, và w gõ đôi để hủy (undo) ---
            arrayOf("w", "ư"),
            arrayOf("ww", "w"),           // gõ w hai lần liên tiếp -> literal "w"
            // "w" chỉ hủy nếu gõ ngay sau chính "w" vừa tạo ra "ư"/móc — ở giữa
            // một từ tiếng Anh như "wifi", "f" phía sau lại bị hiểu nhầm thành
            // dấu huyền (Telex thuần không biết đây là từ tiếng Anh). Đây là lý
            // do bàn phím có nút chuyển VN/EN riêng, không phải lỗi engine.
            arrayOf("wifi", "ừii"),

            // --- đ ---
            arrayOf("dd", "đ"),
            arrayOf("ddepj", "đẹp"),
            arrayOf("dem" + "d", "đem"),  // d gõ trễ vẫn convert đúng chữ d đầu âm tiết

            // --- Dấu thanh: s/f/r/x/j ---
            arrayOf("as", "á"),
            arrayOf("af", "à"),
            arrayOf("ar", "ả"),
            arrayOf("ax", "ã"),
            arrayOf("aj", "ạ"),
            arrayOf("vieets", "viết"),
            arrayOf("chaof", "chào"),

            // --- z: xóa dấu đã gõ; gõ đè phím dấu khác để SỬA dấu đã đặt ---
            // (bug đã fix: trước đây findToneTarget() không nhận ra một nguyên
            // âm ĐÃ có dấu là nguyên âm nữa, nên "z" hay đổi dấu ngay sau khi đã
            // gõ dấu sẽ chèn nhầm ký tự chữ cái thay vì tác động lên dấu).
            arrayOf("as" + "z", "a"),
            arrayOf("as" + "f", "à"),         // gõ "f" đè lên "as" -> sửa sắc thành huyền
            arrayOf("vieets" + "z", "viêt"),  // z chỉ xóa dấu, không hủy "ê" (ee->ê là biến đổi riêng)

            // --- Vị trí dấu thanh: âm tiết đóng vs mở ---
            arrayOf("hoas", "hóa"),   // mở, không có nguyên âm biến đổi -> dấu ở nguyên âm đầu
            arrayOf("thuys", "thúy"), // mở -> dấu ở nguyên âm đầu
            arrayOf("khoej", "khọe"), // "khoe" là âm tiết mở (oe) -> dấu ở nguyên âm đầu (o), giống "khỏe"
            arrayOf("hoais", "hoái"), // oai mở 3 nguyên âm -> dấu ở nguyên âm giữa
            arrayOf("ngoaif", "ngoài"),
            arrayOf("khoais", "khoái"),
            arrayOf("xoays", "xoáy"),
            arrayOf("vieetj", "việt"), // đóng, có ê (biến đổi) -> dấu trên ê

            // --- qu-/gi- glide bị bỏ qua khi tìm vị trí dấu ---
            arrayOf("quas", "quá"),
            arrayOf("gias", "giá"),

            // --- Chữ hoa: giữ nguyên casing khi thêm dấu/biến đổi ---
            arrayOf("As", "Á"),
            arrayOf("Ddep", "Đep"), // chỉ có D hoa đầu được convert, "ep" không đổi
            arrayOf("VIEETJ", "VIỆT"),

            // --- Từ nhiều âm tiết ghép trong 1 buffer (mô phỏng gõ liên tục) ---
            arrayOf("nguoiwf", "người")
        )
    }
}
