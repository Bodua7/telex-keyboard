package com.example.telexkeyboard

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.inputmethodservice.KeyboardView
import android.util.AttributeSet

// The framework's KeyboardView has no public XML attribute for making key
// labels bold (only size/color/background are exposed). The label Paint it
// draws with is kept in a private field ("mPaint" on every AOSP version
// this has been checked against), so this reaches in via reflection once,
// right after construction, and swaps that Paint's typeface to bold.
//
// Wrapped in try/catch on purpose: if some OEM build renamed or removed
// the field, we just silently fall back to the regular (non-bold) look
// instead of crashing the keyboard.
class BoldKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : KeyboardView(context, attrs) {

    init {
        try {
            val paintField = KeyboardView::class.java.getDeclaredField("mPaint")
            paintField.isAccessible = true
            (paintField.get(this) as? Paint)?.typeface = Typeface.DEFAULT_BOLD
        } catch (e: Exception) {
            // Fall back silently — see class comment above.
        }
    }
}
