package com.example.telexkeyboard

/**
 * Decides WHETHER each silent auto-fix feature should run, kept separate
 * from TelexIME (an InputMethodService, hard to unit-test directly) so the
 * on/off + precondition logic itself has real test coverage. TelexIME still
 * owns reading the actual editor text and calling EnglishWordList /
 * VietnameseDiacriticFixer — this object only answers "should we even try".
 */
object AutoFixPolicy {

    /**
     * True when the just-finished word is a candidate for the "restore
     * mangled English word" fix: Vietnamese Telex must be on, a word must
     * have actually been composed, the user hasn't turned this fix off, and
     * the raw text must be a recognized English word.
     */
    fun shouldFixEnglishWord(
        vietnameseOn: Boolean,
        composedLength: Int,
        rawWord: String,
        autoFixEnabled: Boolean
    ): Boolean {
        if (!vietnameseOn || composedLength <= 0 || rawWord.isEmpty() || !autoFixEnabled) return false
        return EnglishWordList.contains(rawWord)
    }

    /**
     * True when the sentence-level tone-mark fix should even be attempted.
     * (The actual fix-or-not decision for the sentence's content still
     * lives in VietnameseDiacriticFixer.fix — this only gates the two
     * preconditions TelexIME controls: Vietnamese mode and the user's
     * setting.)
     */
    fun shouldFixDiacritics(vietnameseOn: Boolean, autoFixEnabled: Boolean): Boolean =
        vietnameseOn && autoFixEnabled
}
