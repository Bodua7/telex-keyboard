package com.example.telexkeyboard

/**
 * Conservative, offline, whole-sentence tone-mark auto-fix.
 *
 * TelexEngine already places tone marks correctly for the vast majority
 * of words using standard open/closed-syllable rules (see its doc
 * comments), and already lets modifier keys land correctly regardless of
 * the order they were typed in relative to the letters they affect. What
 * it can't catch on its own is the rare case where the result still isn't
 * a real Vietnamese word — an irregular exception to the placement rule,
 * or a stray mis-keyed tone — because TelexEngine only ever looks at the
 * word being typed, one keystroke at a time, with no dictionary.
 *
 * This class runs once per FINISHED SENTENCE (see TelexIME calling it on
 * '.', '!', '?', or Enter) rather than per word, so it looks at the
 * sentence as a whole and only touches words that don't look right,
 * leaving already-correct text completely alone.
 *
 * Deliberately narrow scope: it only replaces a word when stripping tone
 * marks from it (see [TelexEngine.toneless]) matches exactly ONE word in
 * [VietnameseDictionary]. If two or more dictionary words share that same
 * skeleton (e.g. "ba"/"bà"/"bá"/"bả"/"bã"/"bạ" are all real, different
 * words), picking between them needs actual sentence *meaning* — this
 * offline engine has no language model to do that safely, so it leaves
 * genuinely ambiguous cases as typed rather than risk a confident wrong
 * "correction" (which would be worse than doing nothing). This mirrors
 * why the earlier English-word fix only fires on an exact word-list
 * match instead of guessing too.
 */
object VietnameseDiacriticFixer {

    private val wordRegex = Regex("\\p{L}+")

    /**
     * Returns a corrected copy of [sentence], or null if nothing needed
     * fixing (the common case — callers should skip the edit entirely).
     */
    fun fix(sentence: String): String? {
        var changed = false
        val result = wordRegex.replace(sentence) { match ->
            val fixedWord = fixWord(match.value)
            if (fixedWord != null) {
                changed = true
                fixedWord
            } else {
                match.value
            }
        }
        return if (changed) result else null
    }

    private fun fixWord(word: String): String? {
        // Single letters ("a", "đi" is fine but bare "a"/"i"...) and pure
        // ASCII/English-looking tokens are left alone — too little signal
        // to safely guess, and this isn't the English-word path anyway
        // (that's EnglishWordList, checked separately in TelexIME before
        // this ever runs).
        if (word.length < 2) return null
        if (VietnameseDictionary.contains(word)) return null // already valid, don't touch

        val skeleton = TelexEngine.toneless(word).lowercase()
        val candidates = VietnameseDictionary.byToneless(skeleton)
        if (candidates.size != 1) return null // none, or ambiguous — leave as typed

        return preserveCase(word, candidates.first())
    }

    private fun preserveCase(source: String, target: String): String = when {
        source.all { !it.isLetter() || it.isUpperCase() } -> target.uppercase()
        source.firstOrNull()?.isUpperCase() == true ->
            target.replaceFirstChar { it.uppercaseChar() }
        else -> target
    }
}
