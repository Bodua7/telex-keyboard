package com.example.telexkeyboard

/**
 * A curated list of common English words used to auto-restore a word that
 * Telex mangled while typing it inline with Vietnamese text — the same
 * "fix English word" idea Unikey/EVKey use, and the offline-friendly
 * equivalent of what Gboard/Samsung Keyboard do with a cloud language
 * model: gõ "was", "is", "as", "for"... xen giữa câu tiếng Việt sẽ KHÔNG
 * bị Telex biến thành "wás", "ís", "ás", "fỏ"...
 *
 * This is deliberately a plain offline word list rather than a statistical
 * model: no network access, nothing to download, fits the rest of this
 * project's single-file / minimal-dependency approach. It only needs to
 * cover words that Telex actually has a chance of mangling — i.e. words
 * containing a Telex trigger letter (a/e/o doubled, or w/s/f/r/x/j/d) —
 * since TelexIME only calls into this list when the transformed result
 * differs from what was typed.
 *
 * The list is intentionally biased toward:
 *  - very common short function words (is, as, was, for, or, of, on, in...)
 *  - everyday words that collide hard with Telex keys (wifi, sea, food,
 *    door, jazz, fox, six, wear, red, run...)
 *  - common tech/internet vocabulary a Vietnamese dev/user mixes into
 *    Vietnamese sentences constantly (wifi, app, save, share, file, link,
 *    email, code, test, debug, deploy, update, backup, login...)
 *
 * Extend this set over time as real false-mangles are noticed; it is not
 * meant to be an exhaustive English dictionary (that would start eating
 * legitimate Vietnamese-looking Telex sequences instead).
 */
object EnglishWordList {

    // Longest entry below, so callers can cheaply skip the lookup for
    // anything longer than this without touching the set at all.
    val MAX_LEN: Int = 12

    private val words: HashSet<String> = hashSetOf(
        // --- function words / pronouns / common short words ---
        "a", "i", "is", "as", "am", "an", "at", "be", "by", "do", "go",
        "he", "if", "in", "it", "me", "my", "no", "of", "on", "or", "so",
        "to", "up", "us", "we",
        "the", "and", "for", "was", "are", "but", "not", "you", "all",
        "can", "had", "her", "his", "one", "our", "out", "day", "get",
        "has", "him", "how", "man", "new", "now", "old", "see", "two",
        "way", "who", "boy", "did", "its", "let", "put", "say", "she",
        "too", "use", "yes", "yet", "any", "few", "off", "own", "per",
        "sir", "try", "war", "won", "ago", "air", "bit", "bad", "big",
        "cut", "eye", "far", "fun", "got", "job", "law", "lot", "low",
        "mix", "run", "sad", "sea", "set", "six", "sun", "top", "win",
        "yay",
        "will", "with", "have", "from", "they", "this", "that", "what",
        "when", "were", "your", "them", "than", "then", "some", "more",
        "most", "only", "also", "into", "over", "such", "very", "much",
        "many", "each", "just", "like", "well", "here", "come", "went",
        "want", "need", "give", "took", "made", "make", "look", "find",
        "know", "long", "part", "even", "back", "call", "work", "life",
        "hand", "high", "keep", "last", "left", "next", "open", "seem",
        "show", "side", "tell", "turn", "used", "week", "word", "year",
        "same", "case", "fact", "hard", "kind", "line", "mind", "move",
        "must", "name", "page", "play", "read", "real", "room", "stop",
        "sure", "take", "test", "wait", "walk", "wear", "week", "wide",
        "wife", "wish", "wood", "wool", "worn", "wove", "food", "fool",
        "fast", "fear", "feed", "feel", "feet", "fell", "felt", "fire",
        "fish", "fist", "five", "flag", "flat", "flow", "form", "fort",
        "four", "free", "from", "full", "fund",
        "door", "dose", "doer", "does", "dish", "dive", "dust",
        "jazz", "join", "joke", "joy",
        "wolf", "wow", "wax", "web", "wed",
        "red", "rest", "rise", "role", "rock", "rope", "rose", "rule",
        "safe", "said", "sale", "salt", "save", "scan", "seat", "seed",
        "self", "sell", "send", "sent", "shop", "shot", "shut", "sick",
        "sign", "site", "size", "skin", "slow", "snow", "soft", "soil",
        "sold", "sole", "some", "song", "soon", "sort", "soul", "spot",
        "star", "stay", "step", "stay", "such", "suit", "sure",
        "off",

        // --- days / months (frequently typed literally) ---
        "monday", "tuesday", "wednesday", "thursday", "friday",
        "saturday", "sunday", "january", "february", "march", "april",
        "may", "june", "july", "august", "september", "october",
        "november", "december",

        // --- tech / internet / dev vocabulary mixed into VN chat ---
        "wifi", "web", "app", "apps", "email", "gmail", "chat", "call",
        "code", "save", "share", "file", "files", "link", "group",
        "team", "test", "debug", "build", "deploy", "server", "client",
        "browser", "download", "upload", "update", "install", "backup",
        "login", "logout", "password", "username", "account", "profile",
        "setting", "settings", "feature", "bug", "fix", "patch",
        "version", "release", "commit", "push", "pull", "merge",
        "branch", "repo", "github", "google", "facebook", "zalo",
        "tiktok", "youtube", "wordpress", "database", "table", "row",
        "column", "query", "index", "cache", "token", "key", "value",
        "array", "object", "class", "function", "method", "variable",
        "string", "number", "boolean", "error", "warning", "log", "logs",
        "config", "domain", "hosting", "cloud", "docker", "python",
        "kotlin", "java", "html", "css", "json", "api", "sdk", "ui",
        "ux", "id", "url", "wifi", "bluetooth", "screenshot", "screen",
        "video", "audio", "photo", "image", "camera", "battery",
        "storage", "memory", "network", "signal", "device", "mobile",
        "laptop", "desktop", "keyboard", "mouse", "monitor", "printer",
        "router", "modem",

        // --- misc common words that hit Telex triggers hard ---
        "walking", "working", "reading", "writing", "sleeping",
        "shopping", "meeting", "training", "morning", "evening",
        "weekend", "holiday", "birthday", "office", "school", "student",
        "teacher", "friend", "family", "market", "coffee", "dinner",
        "lunch", "breakfast", "restaurant", "hotel", "airport", "ticket",
        "flight", "travel", "trip", "beach", "mountain", "river", "lake",
        "forest", "desert", "island", "world", "country", "city", "town",
        "street", "house", "home", "door", "window", "table", "chair",
        "phone", "money", "price", "sale", "discount", "order", "delivery"
    )

    fun contains(raw: String): Boolean {
        if (raw.isEmpty() || raw.length > MAX_LEN) return false
        return words.contains(raw.lowercase())
    }
}
