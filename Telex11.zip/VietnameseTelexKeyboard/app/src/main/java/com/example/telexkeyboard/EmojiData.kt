package com.example.telexkeyboard

/**
 * Plain data source for the keyboard's emoji panel. Pulled out of TelexIME
 * (which was carrying two ~50-item glyph lists inline, unrelated to any of
 * the IME logic around them) so that class reads as "how the keyboard
 * behaves" without the panel's raw content mixed in.
 */
object EmojiData {
    val emojiList: List<String> = listOf(
        "😀","😁","😂","🤣","😊","😍","😘","😜","🤔","😎",
        "😢","😭","😡","😱","🥳","😴","🤢","🤗","😇","🙄",
        "😉","😋","😏","😒","🙃","😅","😆","🥰","🥹","😤",
        "🤯","🥺","😬","🙂","😐","😔","😷","🤒","🥶","🥵",
        "😛","😝","🤪","🤭","🤫","🤐","😶","🫠","🫣","🫡",
        "😌","😪","🤤","😵","😲","🥴","😳","🤨","🧐","🙁",
        "👍","👎","👏","🙏","💪","🤝","✌️","🤞","👌","🙌",
        "👋","🤙","👊","✊","🤟","🫶","👀","💋","👐","🙇",
        "👆","👇","👈","👉","🤘","🖐️","🖖","🫰","💅","🦶",
        "❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","💯",
        "❣️","💕","💞","💗","💓","💖","♥️","💢","💤","💦",
        "🔥","⭐","✨","🎉","🎂","🎁","🎈","🏆","⚡","☀️",
        "🌙","☁️","🌧️","❄️","🌈","🍀","🌸","🌹","🍕","🍔",
        "🍟","🍜","🍚","🍦","☕","🍺","🍎","🍌","🍉","🥭",
        "🍇","🍓","🥝","🌽","🍤","🍣","🍱","🧋","🍿","🍩",
        "🐶","🐱","🐼","🐰","🐣","🦋","🐟","🐢","🚗","✈️",
        "🐯","🦁","🐸","🐷","🐔","🐴","🐝","🐙","🐳","🦄",
        "🚀","⏰","📱","💻","📷","🎵","🎮","📚","💰","🎓",
        "🎧","📺","🖊️","📝","📅","📌","🔍","🎯","🧠","💊",
        "🏠","🏢","🌍","💡","🔑","🔒","🔔","📍","🚩","🏁"
    )

    // Text/punctuation symbols, kept out of the emoji list — different
    // kind of thing (glyphs to insert into running text, not pictures),
    // and mixing them into the emoji list buried them under 200+ emoji.
    // Status/indicator glyphs (✅❌⚠️🆕...) live here too, not in
    // emojiList — they're the same "symbol/indicator" kind of thing as
    // the arrows and math signs already below, not a picture of an
    // object/animal/expression the way the rest of emojiList is.
    val symbolList: List<String> = listOf(
        "™️","©️","®️","§","¶","•","…","—","–","€",
        "£","¥","₫","¢","°","±","×","÷","√","≈",
        "≠","≤","≥","∞","π","←","→","↑","↓","«",
        "»","¡","¿","‘","’","“","”","„","‚","¦",
        "‰","№","∆","Ω","µ","∑","∏","∂","∫","≡",
        "⊕","⊗","∅","∈","∉","⊂","⊃","∪","∩","¬",
        "✅","❌","❓","❗","⚠️","🚫","♻️","🔄","🆗","🆕"
    )
}
