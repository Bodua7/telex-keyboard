package com.example.telexkeyboard

/**
 * A small, hand-picked list of common Vietnamese words, used to power
 * [VietnameseDiacriticFixer] (sentence-context tone-mark auto-fix).
 *
 * This is intentionally NOT a full dictionary or general spell-checker —
 * see VietnameseDiacriticFixer's doc comment for why the auto-fix only
 * ever acts when a word's un-toned skeleton matches exactly ONE entry
 * here. A bigger list would catch more real mistakes, but would also
 * start producing wrong "fixes" for legitimate words this list happens
 * not to contain; extend it gradually as real gaps are noticed rather
 * than importing a giant word list wholesale.
 */
object VietnameseDictionary {

    private val words: List<String> = listOf(
        // Đại từ / xưng hô
        "tôi", "bạn", "anh", "chị", "em", "mình", "chúng", "ta", "họ", "nó",
        "ai", "gì", "đâu", "sao", "nào", "khi", "bao",
        // Trợ động từ / động từ thông dụng
        "là", "có", "không", "được", "sẽ", "đã", "đang", "bị", "phải", "cần",
        "muốn", "thích", "yêu", "ghét", "biết", "hiểu", "nghĩ", "nhớ", "quên",
        "thấy", "nghe", "nhìn", "xem", "nói", "hỏi", "trả", "lời", "gọi",
        "kêu", "cười", "khóc", "đi", "đến", "về", "ra", "vào", "lên",
        "xuống", "qua", "lại", "làm", "ăn", "uống", "ngủ", "dậy", "chơi",
        "học", "dạy", "viết", "đọc", "mua", "bán", "cho", "lấy", "đưa",
        "gửi", "nhận", "mở", "đóng", "tắt", "bật", "chạy", "đứng", "ngồi",
        "nằm", "sống", "chết", "sinh", "lớn", "nhỏ",
        // Từ nối / phó từ
        "và", "hay", "hoặc", "nhưng", "mà", "vì", "nên", "nếu", "thì",
        "cũng", "chỉ", "còn", "vẫn", "rất", "quá", "lắm", "hơi", "khá",
        "này", "kia", "đó", "đây", "ấy", "những", "các", "mỗi", "mọi",
        "tất", "cả", "rồi", "chưa", "vừa", "mới", "sắp", "luôn", "thường",
        "ít", "nhiều",
        // Danh từ thông dụng
        "nhà", "cửa", "bàn", "ghế", "giường", "phòng", "sân", "vườn",
        "đường", "phố", "xe", "máy", "tàu", "thuyền", "xa", "gần", "trên",
        "dưới", "trong", "ngoài", "trước", "sau", "giữa", "bên", "cạnh",
        "trời", "đất", "nước", "lửa", "gió", "mưa", "nắng", "ngày", "đêm",
        "sáng", "trưa", "chiều", "tối", "giờ", "phút", "năm", "tháng",
        "tuần", "hôm", "mai", "nay", "xưa", "tuổi", "người", "con", "cái",
        "đứa", "trẻ", "già", "bố", "mẹ", "cha", "má", "ông", "bà", "cô",
        "chú", "bác", "dì", "cậu", "vợ", "chồng", "gia", "đình", "bạn",
        "bè", "thầy", "sếp", "khách", "tiền", "vàng", "bạc", "công",
        "việc", "chuyện", "vấn", "đề", "cách", "lý", "do", "kết", "quả",
        "thời", "gian", "cuộc", "sống", "đời", "thế", "giới", "quê",
        "hương", "thành", "làng", "xã", "huyện", "trường", "lớp", "bài",
        "sách", "vở", "bút", "giấy", "tính", "điện", "thoại", "mạng",
        "web", "email", "ảnh", "hình", "video", "nhạc", "phim", "món",
        "cơm", "phở", "bánh", "trà", "cà", "phê", "sữa", "rượu", "bia",
        "kẹo", "trái", "cây", "rau", "thịt", "cá", "trứng", "gạo", "muối",
        // Tính từ thông dụng
        "đẹp", "xấu", "tốt", "vui", "buồn", "giận", "sợ", "lo", "mệt",
        "khỏe", "yếu", "mạnh", "nóng", "lạnh", "ấm", "mát", "khô", "ướt",
        "sạch", "bẩn", "cũ", "nhanh", "chậm", "sớm", "muộn", "dễ", "khó",
        "đúng", "sai", "thật", "giả", "chắc", "dở", "ngon", "đắt", "rẻ",
        // Số đếm
        "một", "hai", "ba", "bốn", "sáu", "bảy", "tám", "chín", "mười",
        "trăm", "nghìn", "triệu", "tỷ", "đôi", "vài", "nửa", "phần",
        "toàn", "hết",
        // Chào hỏi / cảm thán
        "chào", "xin", "cảm", "ơn", "vâng", "dạ", "ừ", "ờ", "à", "ơi",
        "nhé", "nha", "ạ", "đấy", "vậy", "chứ", "nhỉ", "hử",
        // Từ để hỏi / phủ định
        "đừng", "chớ", "cấm", "cứ", "hãy",
        // Ghép âm tiết thường gõ sai thứ tự Telex / dễ lệch dấu
        "việt", "nam", "tiếng", "đường", "được", "nhiều", "khỏe", "mạnh"
    ).distinct()

    /** Case-insensitive membership check against the accented word list. */
    fun contains(word: String): Boolean {
        val lower = word.lowercase()
        return words.any { it.lowercase() == lower }
    }

    fun allWords(): List<String> = words

    // Built once, lazily: maps a lowercase toneless skeleton (see
    // TelexEngine.toneless) to every dictionary word that reduces to it,
    // e.g. "ba" -> ["ba", "bà", "bá", ...] if all of those happen to be in
    // [words]. VietnameseDiacriticFixer only auto-fixes when this list has
    // exactly one entry, so ambiguous skeletons are intentionally left
    // alone rather than guessed at.
    private val tonelessIndex: Map<String, List<String>> by lazy {
        words.groupBy { TelexEngine.toneless(it).lowercase() }
    }

    fun byToneless(skeleton: String): List<String> =
        tonelessIndex[skeleton.lowercase()] ?: emptyList()
}
