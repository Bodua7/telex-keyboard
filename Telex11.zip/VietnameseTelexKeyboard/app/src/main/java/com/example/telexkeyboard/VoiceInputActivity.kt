package com.example.telexkeyboard

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ResultReceiver
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast

private const val EXTRA_VOICE_RESULT_RECEIVER =
    "com.example.telexkeyboard.extra.VOICE_RESULT_RECEIVER"
private const val EXTRA_VOICE_TEXT =
    "com.example.telexkeyboard.extra.VOICE_TEXT"
private const val REQUEST_RECORD_AUDIO = 701
private const val REQUEST_SPEECH = 702
private const val RESULT_VOICE_ERROR = 1

/**
 * Activity trung gian cho InputMethodService.
 *
 * InputMethodService không có lifecycle Activity để nhận kết quả
 * startActivityForResult(), nên màn hình này mở giao diện nhận dạng giọng nói
 * của Android rồi trả văn bản về IME qua ResultReceiver.
 */
class VoiceInputActivity : Activity() {

    private var resultReceiver: ResultReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        resultReceiver = readResultReceiver(intent)

        // minSdk giờ là 23 (Marshmallow) trở lên, nơi runtime permission
        // cho RECORD_AUDIO luôn bắt buộc — bỏ rào SDK_INT >= M cũ, chỉ còn
        // giữ đúng phần kiểm tra quyền.
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO
            )
        } else {
            launchRecognizer()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_RECORD_AUDIO) return

        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            launchRecognizer()
            return
        }

        // shouldShowRequestPermissionRationale() trả về false trong đúng
        // hai trường hợp: chưa từng hỏi quyền này bao giờ (không áp dụng ở
        // đây, vì ta vừa mới hỏi xong), hoặc người dùng đã từ chối kèm
        // "Không hỏi lại"/bị chính sách thiết bị chặn — tức bị từ chối
        // vĩnh viễn. Với trường hợp đó, Toast không giúp được gì vì hệ
        // thống sẽ không bao giờ hiện lại hộp thoại xin quyền nữa — cần
        // dẫn thẳng người dùng sang màn Cài đặt ứng dụng để tự bật tay.
        if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            showPermanentlyDeniedDialog()
        } else {
            Toast.makeText(this, "Bạn chưa cấp quyền dùng micro", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun showPermanentlyDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Cần quyền micro")
            .setMessage(
                "Bạn đã từ chối quyền micro trước đó nên hệ thống sẽ không " +
                    "hỏi lại. Vào Cài đặt ứng dụng > Quyền để bật quyền " +
                    "Micro thủ công."
            )
            .setPositiveButton("Mở Cài đặt") { _, _ ->
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Để sau") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun launchRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Nói nội dung cần nhập")
        }

        try {
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "Thiết bị chưa có dịch vụ nhận dạng giọng nói",
                Toast.LENGTH_LONG
            ).show()
            finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun readResultReceiver(source: Intent): ResultReceiver? {
        return if (Build.VERSION.SDK_INT >= 33) {
            source.getParcelableExtra(EXTRA_VOICE_RESULT_RECEIVER, ResultReceiver::class.java)
        } else {
            source.getParcelableExtra(EXTRA_VOICE_RESULT_RECEIVER)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_SPEECH) return

        if (resultCode == RESULT_OK) {
            val text = data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!text.isNullOrEmpty()) {
                resultReceiver?.send(Activity.RESULT_OK, Bundle().apply {
                    putString(EXTRA_VOICE_TEXT, text)
                })
            }
        } else {
            resultReceiver?.send(RESULT_VOICE_ERROR, null)
        }
        finish()
    }
}

internal fun Intent.putVoiceResultReceiver(receiver: ResultReceiver) {
    putExtra(EXTRA_VOICE_RESULT_RECEIVER, receiver)
}

internal fun Bundle.voiceText(): String? = getString(EXTRA_VOICE_TEXT)