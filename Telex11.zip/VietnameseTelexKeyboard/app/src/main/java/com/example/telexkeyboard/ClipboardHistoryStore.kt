package com.example.telexkeyboard

import android.content.Context
import android.content.SharedPreferences

/** One row the clipboard panel renders: a section label, or a pinned/recent entry. */
sealed class ClipboardRow {
    data class Header(val title: String) : ClipboardRow()
    data class Item(val text: String, val pinned: Boolean) : ClipboardRow()
}

/**
 * Owns the clipboard panel's data: the in-memory "recent" history, the
 * persisted "pinned" list, and the rules for what goes in each. Pulled out
 * of TelexIME (which was otherwise also doing Telex transforms, toolbar
 * wiring, emoji grid, voice input, cursor movement...) so this piece can be
 * reasoned about — and unit-tested — on its own.
 */
class ClipboardHistoryStore {
    private val history = mutableListOf<String>()
    private val pinned = mutableListOf<String>()

    companion object {
        const val MAX_HISTORY = 30
        private const val SEP = "\u0001"

        // Heuristic for "don't add this to history": a short run of digits
        // (optionally grouped with spaces/dashes), which is the shape of
        // nearly every OTP / verification / 2FA code and not a shape normal
        // copied text takes. Deliberately narrow — only skips SHORT
        // all-digit strings — so it doesn't swallow real content like
        // copied paragraphs, URLs, or phone numbers written with
        // parentheses (which this regex doesn't match anyway).
        private val OTP_LIKE = Regex("^[0-9][0-9 -]{1,9}$")

        /**
         * True if [text] looks like a one-time code rather than something
         * worth keeping around in a clipboard history. Pure function so it
         * can be tested without any Android dependency.
         */
        fun looksSensitive(text: String): Boolean {
            val trimmed = text.trim()
            if (trimmed.length < 3 || trimmed.length > 10) return false
            return OTP_LIKE.matches(trimmed)
        }
    }

    /**
     * Loads pinned items from their dedicated SharedPreferences file (see
     * [TelexPrefs.clipboardOf]). Also migrates any pinned items left over
     * from before that split (when they lived in the main "telex_prefs"
     * file, which — unlike this one — is included in Android's automatic
     * backup) into the new file, then clears them from the old one so they
     * stop being backed up going forward.
     */
    fun load(context: Context) {
        migrateFromLegacyFileIfNeeded(context)
        val prefs = TelexPrefs.clipboardOf(context)
        pinned.clear()
        val stored = prefs.getString(TelexPrefs.KEY_CLIPBOARD_PINNED, null) ?: return
        if (stored.isNotEmpty()) pinned.addAll(stored.split(SEP))
    }

    private fun migrateFromLegacyFileIfNeeded(context: Context) {
        val newPrefs = TelexPrefs.clipboardOf(context)
        if (newPrefs.contains(TelexPrefs.KEY_CLIPBOARD_PINNED)) return // already migrated
        val legacyPrefs = TelexPrefs.of(context)
        val legacyValue = legacyPrefs.getString(TelexPrefs.KEY_CLIPBOARD_PINNED, null) ?: return
        newPrefs.edit().putString(TelexPrefs.KEY_CLIPBOARD_PINNED, legacyValue).apply()
        legacyPrefs.edit().remove(TelexPrefs.KEY_CLIPBOARD_PINNED).apply()
    }

    private fun persist(prefs: SharedPreferences) {
        prefs.edit().putString(TelexPrefs.KEY_CLIPBOARD_PINNED, pinned.joinToString(SEP)).apply()
    }

    /** Called whenever the system clipboard's primary clip changes. */
    fun onNewClip(text: String?) {
        val value = text?.takeIf { it.isNotBlank() } ?: return
        if (value in pinned) return
        if (looksSensitive(value)) return
        history.remove(value)
        history.add(0, value)
        while (history.size > MAX_HISTORY) history.removeAt(history.size - 1)
    }

    fun clearHistory() {
        history.clear()
    }

    fun isEmpty(): Boolean = history.isEmpty() && pinned.isEmpty()

    fun togglePin(text: String, currentlyPinned: Boolean, context: Context) {
        if (currentlyPinned) {
            pinned.remove(text)
        } else {
            pinned.remove(text)
            pinned.add(0, text)
            history.remove(text)
        }
        persist(TelexPrefs.clipboardOf(context))
    }

    fun delete(text: String, pinned_: Boolean, context: Context) {
        if (pinned_) {
            pinned.remove(text)
            persist(TelexPrefs.clipboardOf(context))
        } else {
            history.remove(text)
        }
    }

    /** Builds the flat row list the panel's ListView adapter renders. */
    fun rows(pinnedHeader: String, recentHeader: String, emptyLabel: String): List<ClipboardRow> {
        val rows = mutableListOf<ClipboardRow>()
        if (pinned.isNotEmpty()) {
            rows.add(ClipboardRow.Header(pinnedHeader))
            pinned.forEach { rows.add(ClipboardRow.Item(it, pinned = true)) }
        }
        if (history.isNotEmpty()) {
            // Only bother labeling "recent" as its own section once there's
            // a pinned section above it to distinguish it from — a lone
            // list of recent items doesn't need a header.
            if (pinned.isNotEmpty()) {
                rows.add(ClipboardRow.Header(recentHeader))
            }
            history.forEach { rows.add(ClipboardRow.Item(it, pinned = false)) }
        }
        if (rows.isEmpty()) {
            rows.add(ClipboardRow.Item(emptyLabel, pinned = false))
        }
        return rows
    }
}
