package com.example.telexkeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

// Transparent overlay drawn on top of KeyboardView, showing the pink
// swipe trail while gõ vuốt (glide typing) is in progress — matches the
// reference "type with a swipe" screenshot instead of the finger moving
// over the keys with no visual feedback. Purely cosmetic: never consumes
// touches itself (see onTouchEvent below), TelexIME still drives it by
// calling addPoint()/clearTrail()/fadeOutTrail() from handleGlideTouch().
class GlideTrailView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val points = mutableListOf<PointF>()
    private val density = resources.displayMetrics.density
    private val paint = Paint().apply {
        color = 0xFFFF3D7F.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 7f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }
    private var fadeAnimator: ValueAnimator? = null

    init {
        isClickable = false
        isFocusable = false
    }

    // Never intercepts touches — TelexIME reads raw touch events straight
    // from keyboardView's own OnTouchListener; this view only draws.
    override fun onTouchEvent(event: MotionEvent): Boolean = false

    fun addPoint(x: Float, y: Float) {
        points.add(PointF(x, y))
        invalidate()
    }

    fun clearTrail() {
        fadeAnimator?.cancel()
        points.clear()
        paint.alpha = 255
        invalidate()
    }

    // Called on a successful glide release: leaves the trail visible for a
    // beat, then fades it out, instead of snapping away instantly.
    fun fadeOutTrail() {
        fadeAnimator?.cancel()
        fadeAnimator = ValueAnimator.ofInt(255, 0).apply {
            duration = 220
            startDelay = 80
            addUpdateListener {
                paint.alpha = it.animatedValue as Int
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    points.clear()
                    invalidate()
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.size < 2) return
        val path = Path()
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) path.lineTo(points[i].x, points[i].y)
        canvas.drawPath(path, paint)
    }
}
