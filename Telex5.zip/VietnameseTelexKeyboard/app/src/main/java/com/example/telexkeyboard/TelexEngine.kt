package com.example.telexkeyboard

/**
 * Converts a raw sequence of Telex keystrokes (e.g. "vieejt" or "chaof")
 * into properly-accented Vietnamese text (e.g. "việt", "chào").
 *
 * The caller is expected to keep a per-word "raw buffer" of every key
 * typed since the last word boundary (space / punctuation / enter) and
 * call transform() again on the whole buffer after every keystroke,
 * replacing whatever was previously composed in the text field. This
 * mirrors how most desktop/mobile Telex engines (Unikey, EVKey, etc.)
 * work internally.
 */
object TelexEngine {

    // index: 0 = no tone, 1 = sắc, 2 = huyền, 3 = hỏi, 4 = ngã, 5 = nặng
    private val toneTable = mapOf(
        'a' to charArrayOf('a', 'á', 'à', 'ả', 'ã', 'ạ'),
        'ă' to charArrayOf('ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ'),
        'â' to charArrayOf('â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'),
        'e' to charArrayOf('e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ'),
        'ê' to charArrayOf('ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'),
        'i' to charArrayOf('i', 'í', 'ì', 'ỉ', 'ĩ', 'ị'),
        'o' to charArrayOf('o', 'ó', 'ò', 'ỏ', 'õ', 'ọ'),
        'ô' to charArrayOf('ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ'),
        'ơ' to charArrayOf('ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'),
        'u' to charArrayOf('u', 'ú', 'ù', 'ủ', 'ũ', 'ụ'),
        'ư' to charArrayOf('ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'),
        'y' to charArrayOf('y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ')
    )

    private val modifiedVowels = setOf('ă', 'â', 'ê', 'ô', 'ơ', 'ư')
    private val plainVowels = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val vowels = plainVowels + modifiedVowels

    // These three all work off the LOWERCASE form of the vowel — toneTable
    // only stores lowercase entries — and re-apply the original casing on
    // the way out. Without this, a capitalized vowel (e.g. Shift-typing the
    // first letter of "Ăn", "Được", "Ơi"...) would never receive its tone
    // mark, since a bare "for (arr) if (arr.contains(c))" lookup can never
    // match an uppercase char against a lowercase-only array.
    private fun baseOf(c: Char): Char {
        val lc = c.lowercaseChar()
        for ((base, arr) in toneTable) if (arr.contains(lc)) return base
        return lc
    }

    private fun toneOf(c: Char): Int {
        val lc = c.lowercaseChar()
        for (arr in toneTable.values) {
            val idx = arr.indexOf(lc)
            if (idx >= 0) return idx
        }
        return 0
    }

    private fun applyTone(c: Char, tone: Int): Char {
        val arr = toneTable[baseOf(c)] ?: return c
        val result = arr[tone]
        return if (c.isUpperCase()) result.uppercaseChar() else result
    }

    // Trailing run of letters at the end of [out] — this is always exactly
    // the word currently being composed, since the caller resets the raw
    // buffer (and therefore `out`) at every word boundary. Shared by the
    // tone-target search below and by the "smart"/retroactive modifier
    // searches (đ, â/ê/ô doubling, ă/ơ/ư horn), so that a modifier key
    // typed later in the word — not just immediately after the vowel it
    // affects — still lands on the right letter. This is standard behavior
    // for Telex engines like Unikey/EVKey: e.g. "khong" + "o" -> "không",
    // "thuong" + "w" -> "thương", "dem" + "d" -> "đem", typed well after
    // the character being modified.
    private fun syllableStart(out: StringBuilder): Int {
        var start = out.length
        while (start > 0 && out[start - 1].isLetter()) start--
        return start
    }

    fun transform(raw: String): String {
        val out = StringBuilder()

        // Tracks what the immediately preceding "w" keystroke did to `out`,
        // so that pressing "w" twice in a row can undo it and fall back to
        // a literal "w" — the standard Telex convention for typing words
        // that contain a real "w" (e.g. "wifi", "web"). A "uo" + w horn
        // touches TWO positions (both vowels of the diphthong), so this is
        // a list rather than a single index/char pair — undoing must
        // restore every position the last "w" touched, not just one of
        // them.
        val prevWEdits = mutableListOf<Pair<Int, Char>>()
        var prevWAppendIndex = -1

        for (i in raw.indices) {
            val ch = raw[i]
            val lower = ch.lowercaseChar()
            val isUpper = ch.isUpperCase()
            val prevWasW = i > 0 && raw[i - 1].lowercaseChar() == 'w'

            when (lower) {
                'd' -> {
                    val target = findDConvertTarget(out)
                    if (target >= 0) {
                        out.setCharAt(target, if (out[target].isUpperCase()) 'Đ' else 'đ')
                    } else {
                        out.append(ch)
                    }
                    prevWEdits.clear(); prevWAppendIndex = -1
                }

                'a', 'e', 'o' -> {
                    val newBase = when (lower) {
                        'a' -> 'â'
                        'e' -> 'ê'
                        else -> 'ô'
                    }
                    val target = findDoubleTarget(out, lower)
                    if (target >= 0) {
                        val arr = toneTable.getValue(newBase)
                        val replacement = arr[toneOf(out[target])]
                        out.setCharAt(
                            target,
                            if (out[target].isUpperCase()) replacement.uppercaseChar() else replacement
                        )
                    } else {
                        out.append(ch)
                    }
                    prevWEdits.clear(); prevWAppendIndex = -1
                }

                'w' -> {
                    if (prevWasW && (prevWEdits.isNotEmpty() || prevWAppendIndex >= 0)) {
                        // Second consecutive "w": undo whatever the previous
                        // w did (every position it touched), then insert a
                        // literal "w" for this keystroke.
                        if (prevWAppendIndex >= 0 && prevWAppendIndex == out.length - 1) {
                            out.deleteCharAt(prevWAppendIndex)
                        } else {
                            for ((idx, original) in prevWEdits) {
                                if (idx < out.length) out.setCharAt(idx, original)
                            }
                        }
                        out.append(if (isUpper) 'W' else 'w')
                        prevWEdits.clear(); prevWAppendIndex = -1
                    } else {
                        val pair = findHornPairTarget(out)
                        if (pair != null) {
                            // "uo" + w -> "ươ": the horn applies to BOTH
                            // vowels of the diphthong (e.g. "nuowc" or
                            // "nuocw" -> "nươc"), not just one of them.
                            val (uIdx, oIdx) = pair
                            val origU = out[uIdx]
                            val origO = out[oIdx]
                            // Preserve a tone mark that already landed on
                            // either vowel (e.g. tone typed before horn:
                            // "nuocsw") instead of silently dropping it.
                            val newU = toneTable.getValue('ư')[toneOf(origU)]
                            val newO = toneTable.getValue('ơ')[toneOf(origO)]
                            out.setCharAt(uIdx, if (origU.isUpperCase()) newU.uppercaseChar() else newU)
                            out.setCharAt(oIdx, if (origO.isUpperCase()) newO.uppercaseChar() else newO)
                            prevWEdits.clear()
                            prevWEdits.add(uIdx to origU)
                            prevWEdits.add(oIdx to origO)
                            prevWAppendIndex = -1
                        } else {
                            val single = findHornSingleTarget(out)
                            if (single != null) {
                                val (idx, newBase) = single
                                val original = out[idx]
                                val replacement = toneTable.getValue(newBase)[toneOf(original)]
                                out.setCharAt(
                                    idx,
                                    if (original.isUpperCase()) replacement.uppercaseChar() else replacement
                                )
                                prevWEdits.clear()
                                prevWEdits.add(idx to original)
                                prevWAppendIndex = -1
                            } else {
                                // "w" typed alone is a common shortcut for "ư"
                                out.append(if (isUpper) 'Ư' else 'ư')
                                prevWAppendIndex = out.length - 1
                                prevWEdits.clear()
                            }
                        }
                    }
                }

                's', 'f', 'r', 'x', 'j' -> {
                    val tone = when (lower) {
                        's' -> 1
                        'f' -> 2
                        'r' -> 3
                        'x' -> 4
                        else -> 5
                    }
                    val pos = findToneTarget(out)
                    if (pos >= 0) {
                        out.setCharAt(pos, applyTone(out[pos], tone))
                    } else {
                        out.append(ch)
                    }
                    prevWEdits.clear(); prevWAppendIndex = -1
                }

                'z' -> {
                    val pos = findToneTarget(out)
                    if (pos >= 0 && toneOf(out[pos]) != 0) {
                        out.setCharAt(pos, applyTone(out[pos], 0))
                    } else {
                        out.append(ch)
                    }
                    prevWEdits.clear(); prevWAppendIndex = -1
                }

                else -> {
                    out.append(ch)
                    prevWEdits.clear(); prevWAppendIndex = -1
                }
            }
        }

        return out.toString()
    }

    /**
     * Finds, within the current syllable, the most recent (rightmost)
     * occurrence of a vowel whose base is exactly [base] — never an
     * already-modified variant of it (typing "a" again should only ever
     * re-target a plain "a", never an "ă" or "â" that's already there).
     * Used for the "aa" -> "â", "ee" -> "ê", "oo" -> "ô" doubling keys, and
     * works even when other consonants were typed in between (e.g.
     * "khong" + "o" -> "không", "xuan" + "a" -> "xuân").
     */
    private fun findDoubleTarget(out: StringBuilder, base: Char): Int {
        val start = syllableStart(out)
        for (idx in out.length - 1 downTo start) {
            if (baseOf(out[idx]) == base) return idx
        }
        return -1
    }

    /**
     * Finds the first not-yet-converted "d"/"D" in the current syllable —
     * Vietnamese only ever has a single syllable-initial "d", so the first
     * (leftmost) match is always the right one — so that the second "d"
     * keystroke converts it to "đ" even when typed after the rest of the
     * word (e.g. "dem" + "d" -> "đem"), not only when doubled immediately.
     */
    private fun findDConvertTarget(out: StringBuilder): Int {
        val start = syllableStart(out)
        for (idx in start until out.length) {
            val c = out[idx]
            if (c.lowercaseChar() == 'd' && c != 'đ' && c != 'Đ') return idx
        }
        return -1
    }

    /**
     * Finds an adjacent, not-yet-modified "uo" vowel pair in the current
     * syllable so the horn key ("w") can apply to BOTH vowels of the
     * diphthong at once (e.g. "nuoc" -> "nươc", "thuong" -> "thương"),
     * even when it's typed after trailing consonants rather than right
     * next to the pair. The silent glide "u" that follows "q" is skipped
     * (e.g. "quo" + w -> "quơ", horn only on the o, not "qươ").
     */
    private fun findHornPairTarget(out: StringBuilder): Pair<Int, Int>? {
        val start = syllableStart(out)
        for (idx in out.length - 2 downTo start) {
            if (baseOf(out[idx]) == 'u' && baseOf(out[idx + 1]) == 'o') {
                val precededByQ = idx - 1 >= start && out[idx - 1].lowercaseChar() == 'q'
                if (!precededByQ) return idx to (idx + 1)
            }
        }
        return null
    }

    /**
     * Finds a single not-yet-modified a/o/u in the current syllable to
     * receive the horn (a -> ă, o -> ơ, u -> ư), searching from the end of
     * the syllable backwards so the closest candidate wins, and skipping a
     * "u" that's really the silent glide after "q".
     */
    private fun findHornSingleTarget(out: StringBuilder): Pair<Int, Char>? {
        val start = syllableStart(out)
        for (idx in out.length - 1 downTo start) {
            val base = baseOf(out[idx])
            val newBase = when (base) {
                'a' -> 'ă'
                'o' -> 'ơ'
                'u' -> 'ư'
                else -> null
            } ?: continue
            if (base == 'u') {
                val precededByQ = idx - 1 >= start && out[idx - 1].lowercaseChar() == 'q'
                if (precededByQ) continue
            }
            return idx to newBase
        }
        return null
    }

    /**
     * Finds the index inside [out] of the vowel that should carry the tone
     * mark, following standard Vietnamese tone-placement rules:
     *  1. A vowel that already has an inherent modifier (ă â ê ô ơ ư) wins.
     *  2. Otherwise, in a closed syllable (consonant after the vowel
     *     cluster) the tone goes on the last vowel of the cluster.
     *  3. In an open syllable (vowel cluster ends the word) the tone goes
     *     on the first vowel of the cluster (classic/dictionary style,
     *     e.g. "hòa", "thúy").
     * The glide u/i in "qu-"/"gi-" is ignored when other vowels exist.
     */
    private fun findToneTarget(out: StringBuilder): Int {
        if (out.isEmpty()) return -1

        val start = syllableStart(out)
        val syllable = out.substring(start)
        if (syllable.isEmpty()) return -1

        val positions = mutableListOf<Int>()
        for (k in syllable.indices) {
            if (vowels.contains(syllable[k].lowercaseChar())) positions.add(start + k)
        }
        if (positions.isEmpty()) return -1

        val lowerSyll = syllable.lowercase()
        if (positions.size > 1) {
            if ((lowerSyll.startsWith("qu") || lowerSyll.startsWith("gi")) &&
                positions[0] == start + 1
            ) {
                positions.removeAt(0)
            }
        }
        if (positions.isEmpty()) return -1
        if (positions.size == 1) return positions[0]

        // If more than one vowel already carries an inherent modifier, the
        // *last* one wins (this only really happens with "ươ", e.g.
        // "được", "nước", "trường" — the tone goes on the ơ, not the ư).
        val modifiedPositions = positions.filter { modifiedVowels.contains(out[it].lowercaseChar()) }
        if (modifiedPositions.isNotEmpty()) return modifiedPositions.last()

        val lastVowelPos = positions.last()
        val isClosed = lastVowelPos < out.length - 1

        // Open triphthong with no modified vowel (oai/oay/uay — "loài",
        // "hoài", "ngoài", "khoái", "xoáy"...): the tone belongs on the
        // middle vowel (the syllable nucleus), not the first one. The
        // first-vowel rule below is correct for open 2-vowel clusters
        // ("hòa", "thúy") but wrong for these 3-vowel ones.
        if (!isClosed && positions.size == 3) return positions[1]

        return if (isClosed) positions.last() else positions.first()
    }
}
