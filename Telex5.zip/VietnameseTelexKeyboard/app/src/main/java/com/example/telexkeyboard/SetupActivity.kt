package com.example.telexkeyboard

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var sizeButtons: List<Button>
    private val prefs by lazy { getSharedPreferences("telex_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(48, 96, 48, 48)

        val title = TextView(this)
        title.text = "Bàn Phím Telex"
        title.textSize = 22f

        statusText = TextView(this)
        statusText.textSize = 15f
        statusText.setPadding(0, 16, 0, 16)

        val desc = TextView(this)
        desc.text = "1. Bấm nút bên dưới để bật \"Bàn Phím Telex\" trong Cài đặt.\n\n" +
            "2. Khi soạn văn bản, chạm giữ biểu tượng chuyển bàn phím để chọn " +
            "\"Bàn Phím Telex\".\n\n" +
            "3. Quy tắc gõ: aa=â, aw=ă, ee=ê, oo=ô, ow=ơ, uw=ư, dd=đ, " +
            "s=sắc, f=huyền, r=hỏi, x=ngã, j=nặng, z=xóa dấu."
        desc.setPadding(0, 24, 0, 32)

        val enableBtn = Button(this)
        enableBtn.text = "Mở cài đặt bàn phím"
        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        val switchBtn = Button(this)
        switchBtn.text = "Chọn bàn phím đang gõ"
        switchBtn.setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        val sizeLabel = TextView(this)
        sizeLabel.text = "\nKích thước bàn phím:"
        sizeLabel.setPadding(0, 48, 0, 16)

        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL

        fun sizeButton(label: String, value: Int): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener {
                prefs.edit().putInt("keyboard_size", value).apply()
                refreshSizeSelection()
                Toast.makeText(
                    this,
                    "Đã lưu. Chuyển sang app khác rồi quay lại để thấy thay đổi.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            params.setMargins(8, 0, 8, 0)
            b.layoutParams = params
            b.tag = value
            return b
        }

        val btnSmall = sizeButton("Nhỏ", 0)
        val btnMedium = sizeButton("Vừa", 1)
        val btnLarge = sizeButton("Lớn", 2)
        sizeButtons = listOf(btnSmall, btnMedium, btnLarge)
        sizeRow.addView(btnSmall)
        sizeRow.addView(btnMedium)
        sizeRow.addView(btnLarge)

        layout.addView(title)
        layout.addView(statusText)
        layout.addView(desc)
        layout.addView(enableBtn)
        layout.addView(switchBtn)
        layout.addView(sizeLabel)
        layout.addView(sizeRow)
        setContentView(layout)
    }

    // onResume chạy lại mỗi khi quay về từ màn Cài đặt hệ thống hoặc từ
    // trình chọn bàn phím — nhờ vậy trạng thái hiển thị luôn khớp thực tế,
    // không bị "đứng hình" ở giá trị lúc mới mở màn hình.
    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSizeSelection()
    }

    private fun refreshStatus() {
        // ComponentName.flattenToShortString() sinh đúng định dạng id mà
        // InputMethodInfo dùng ("pkg/.ClassName"), an toàn hơn tự nối chuỗi.
        val myService = ComponentName(this, TelexIME::class.java).flattenToShortString()

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.id == myService }

        val defaultIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        val isDefault = defaultIme == myService

        statusText.text = when {
            isDefault -> "✓ Đã bật và đang là bàn phím đang dùng"
            enabled -> "✓ Đã bật — chạm giữ biểu tượng bàn phím để chọn dùng"
            else -> "✗ Chưa bật — bấm \"Mở cài đặt bàn phím\" bên dưới"
        }
        statusText.setTextColor(if (isDefault) Color.parseColor("#2E7D32") else if (enabled) Color.parseColor("#F9A825") else Color.parseColor("#C62828"))
    }

    private fun refreshSizeSelection() {
        val current = prefs.getInt("keyboard_size", 1)
        for (b in sizeButtons) {
            val selected = (b.tag as Int) == current
            b.alpha = if (selected) 1f else 0.5f
        }
    }
}
