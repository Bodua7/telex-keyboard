package com.example.telexkeyboard

import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

/**
 * Bộ test hồi quy cho TelexEngine.transform(). Chạy bằng:
 *   ./gradlew test
 * hoặc trong CI thêm bước:
 *   - run: ./gradlew test
 *
 * Mỗi case là một cặp (chuỗi Telex gõ vào, kết quả tiếng Việt mong đợi).
 * Khi sửa TelexEngine, chạy lại bộ này để chắc chắn không hồi quy các quy
 * tắc đã đúng trước đó.
 */
@RunWith(Parameterized::class)
class TelexEngineTest(
    private val input: String,
    private val expected: String
) {

    @Test
    fun transform_matchesExpected() {
        assertEquals(
            "transform(\"$input\") sai",
            expected,
            TelexEngine.transform(input)
        )
    }

    companion object {
        @JvmStatic
        @Parameterized.Parameters(name = "{0} -> {1}")
        fun cases(): List<Array<String>> = listOf(
            // --- Nguyên âm biến đổi cơ bản (doubling) ---
            arrayOf("aa", "â"),
            arrayOf("ee", "ê"),
            arrayOf("oo", "ô"),
            arrayOf("khoong", "không"),
            arrayOf("xuan", "xuân"), // â áp dụng lùi lại qua phụ âm đứng giữa

            // --- Móc (horn): a->ă, o->ơ, u->ư qua phím w ---
            arrayOf("aw", "ă"),
            arrayOf("ow", "ơ"),
            arrayOf("uw", "ư"),
            arrayOf("thuwong", "thương"), // uo + w -> ươ áp dụng cả 2 nguyên âm
            arrayOf("nuoc", "nuoc"),      // chưa gõ w thì chưa biến đổi
            arrayOf("nuowc", "nươc"),
            arrayOf("quow", "quơ"),       // u sau q là âm đệm câm, không nhận móc

            // --- w gõ đơn lẻ -> ư, và w gõ đôi để hủy (undo) ---
            arrayOf("w", "ư"),
            arrayOf("ww", "w"),           // gõ w hai lần liên tiếp -> literal "w"
            arrayOf("wifi", "ưifi"),      // "w" đơn ở đầu vẫn thành ư (đúng máy Telex chuẩn)

            // --- đ ---
            arrayOf("dd", "đ"),
            arrayOf("ddep", "đẹp"),
            arrayOf("dem" + "d", "đem"),  // d gõ trễ vẫn convert đúng chữ d đầu âm tiết

            // --- Dấu thanh: s/f/r/x/j ---
            arrayOf("as", "á"),
            arrayOf("af", "à"),
            arrayOf("ar", "ả"),
            arrayOf("ax", "ã"),
            arrayOf("aj", "ạ"),
            arrayOf("vieets", "viết"),
            arrayOf("chaof", "chào"),

            // --- z: xóa dấu đã gõ ---
            arrayOf("as" + "z", "a"),
            arrayOf("vieets" + "z", "viet"),

            // --- Vị trí dấu thanh: âm tiết đóng vs mở ---
            arrayOf("hoas", "hóa"),   // mở, không có nguyên âm biến đổi -> dấu ở nguyên âm đầu
            arrayOf("thuys", "thúy"), // mở -> dấu ở nguyên âm đầu
            arrayOf("khoej", "khoẹ" ),// đóng? "khoe" mở thật ra -> kiểm tra dưới
            arrayOf("hoais", "hoái"), // oai mở 3 nguyên âm -> dấu ở nguyên âm giữa
            arrayOf("ngoaif", "ngoài"),
            arrayOf("khoais", "khoái"),
            arrayOf("xoays", "xoáy"),
            arrayOf("vieetj", "việt"), // đóng, có ê (biến đổi) -> dấu trên ê

            // --- qu-/gi- glide bị bỏ qua khi tìm vị trí dấu ---
            arrayOf("quas", "quá"),
            arrayOf("gias", "giá"),

            // --- Chữ hoa: giữ nguyên casing khi thêm dấu/biến đổi ---
            arrayOf("Aas", "Á"),
            arrayOf("Ddep", "Đep"), // chỉ có D hoa đầu được convert, "ep" không đổi
            arrayOf("VIEETJ", "VIỆT"),

            // --- Từ nhiều âm tiết ghép trong 1 buffer (mô phỏng gõ liên tục) ---
            arrayOf("nguoiwf", "người")
        )
    }
}
