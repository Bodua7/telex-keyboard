# Bàn Phím Telex (Vietnamese Telex Android Keyboard)

Một bàn phím ảo Android (IME) với bố cục dạng QWERTY giống bàn phím PC,
gõ tiếng Việt theo kiểu **Telex** (giống Unikey/EVKey khi bật Telex trên máy tính).

## Cấu trúc dự án

```
VietnameseTelexKeyboard/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/telexkeyboard/
│       │   ├── TelexEngine.kt   # bộ xử lý quy tắc gõ Telex -> tiếng Việt
│       │   ├── TelexIME.kt      # InputMethodService + bàn phím
│       │   └── SetupActivity.kt # màn hình hướng dẫn bật bàn phím
│       └── res/
│           ├── xml/
│           │   ├── method.xml
│           │   ├── keyboard_qwerty.xml   # layout QWERTY chính
│           │   └── keyboard_symbols.xml  # layout số/ký hiệu (phím ?123)
│           ├── drawable/ic_launcher.xml
│           └── values/strings.xml
├── build.gradle
└── settings.gradle
```

## Cách build & cài đặt

1. Mở thư mục `VietnameseTelexKeyboard` bằng **Android Studio** (File → Open).
2. Đợi Gradle sync xong (cần kết nối mạng để tải Gradle/AGP/Kotlin lần đầu).
3. Cắm điện thoại (hoặc dùng máy ảo) và bấm **Run ▶**.
4. App sẽ mở màn hình hướng dẫn — bấm **"Mở cài đặt bàn phím"** rồi bật
   **"Bàn Phím Telex"** trong danh sách bàn phím của Android.
5. Vào một ô nhập văn bản bất kỳ (Tin nhắn, Ghi chú...), chạm giữ biểu
   tượng chuyển bàn phím (hoặc phím dấu cách khi có nhiều bàn phím) để
   chọn "Bàn Phím Telex".

## Quy tắc gõ Telex đã hỗ trợ

| Gõ | Ra | Gõ | Ra |
|----|----|----|----|
| aa | â  | dd | đ  |
| aw | ă  | s  | dấu sắc (á) |
| ee | ê  | f  | dấu huyền (à) |
| oo | ô  | r  | dấu hỏi (ả) |
| ow | ơ  | x  | dấu ngã (ã) |
| uw | ư  | j  | dấu nặng (ạ) |
| w  | ư (gõ riêng lẻ) | z | xóa dấu vừa đặt |

Ví dụ: `vieejt nam` → `việt nam`, `chaof` → `chào`, `ddeejp` → `đẹp`.

## Giới hạn hiện tại (v1)

- Việc đặt dấu thanh vào đúng nguyên âm trong các cụm 2–3 nguyên âm dùng
  quy tắc phổ biến (ưu tiên nguyên âm đã biến đổi như ê/ơ/ư; nếu không,
  âm tiết đóng → dấu ở nguyên âm cuối, âm tiết mở → dấu ở nguyên âm đầu).
  Đây là quy tắc chuẩn cho phần lớn trường hợp, nhưng vài từ hiếm có thể
  cần bạn gõ lại `z` rồi gõ dấu ở vị trí khác nếu sai.
- Chưa có gợi ý từ (word suggestion). Đây là hướng có thể mở rộng thêm sau.

## Nhấn giữ & vuốt phím

- **Nhấn giữ hàng số** (1-0): hiện popup ký hiệu tương ứng
  (`1→!`, `2→@`, `3→#`, `4→$`, `5→%`, `6→^`, `7→&`, `8→*`, `9→(`, `0→)`).
  Trượt ngón tay lên ô ký hiệu trong popup rồi thả ra để gõ ký hiệu đó.
- **Vuốt trái/phải** trên bàn phím: di chuyển con trỏ sang trái/phải.
- **Vuốt lên**: chuyển nhanh QWERTY ⇄ Ký hiệu (?123), không cần chạm nút.
- **Vuốt xuống**: ẩn bàn phím.
- **Nhấn giữ phím Xóa/Cách**: đã hỗ trợ sẵn (`isRepeatable`), tự lặp lại
  khi giữ.

## Gõ vuốt liên tục (glide typing)

Trên lớp QWERTY, thay vì gõ từng chữ, bạn có thể **chạm vào chữ cái đầu
rồi kéo ngón tay lướt qua các chữ cái tiếp theo của từ mà không nhấc tay**
(giống Gboard/SwiftKey) — ví dụ lướt qua `c → h → a → o` rồi thả ra để gõ
"chào".

- Cần lướt qua **ít nhất 3 phím chữ cái khác nhau** và di chuyển đủ xa
  (~1.5 lần bề rộng 1 phím) mới được tính là gõ vuốt; chạm/kéo ngắn vẫn
  gõ 1 ký tự bình thường như trước.
- Từ được chọn theo khoảng cách gần nhất (Levenshtein) giữa đường vuốt và
  danh sách từ trong `app/src/main/assets/words_vi.txt` (đã bỏ dấu, gộp
  chữ lặp liền kề) — chữ cái đầu luôn phải khớp.
- Đây là **từ điển khởi đầu** (~250 từ thông dụng) và **thuật toán so
  khớp đơn giản**, không phải mô hình dự đoán ngôn ngữ đầy đủ: không học
  theo thói quen gõ, không xét ngữ cảnh câu trước đó. Muốn thêm từ: chỉ
  cần thêm dòng mới vào `words_vi.txt`, không cần sửa code
  (`GlideTypingEngine.kt`).
- Không áp dụng cho lớp Ký hiệu (?123) — ở đó mọi thao tác vuốt/chạm vẫn
  gõ ký tự như bình thường.
- Bàn phím dùng `android.inputmethodservice.KeyboardView` (API cũ nhưng
  vẫn hoạt động tốt trên mọi phiên bản Android hiện hành).

## Mở rộng thêm

- Muốn giao diện đẹp hơn (theo Material 3, có preview phím nổi khi
  chạm...) thì viết lại `onCreateInputView()` bằng Jetpack Compose hoặc
  custom View thay vì `KeyboardView` cũ.
- Muốn gõ kiểu VNI thay vì Telex: chỉ cần viết thêm một `VniEngine.kt`
  tương tự và cho người dùng chọn kiểu gõ trong `SetupActivity`.
