package com.example.telexkeyboard

import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Plain-code UI (no layout XML), same approach as SetupActivity — this
// screen is simple enough (one scrolling block of text) that a layout
// file would be pure overhead. Text itself lives in
// res/raw/privacy_policy.txt, which is also the same content published
// as PRIVACY_POLICY.md at the repo root for Play Console's "privacy
// policy URL" field — keep the two in sync when editing either.
class PrivacyPolicyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = getString(R.string.privacy_policy_title)

        val policyText = resources.openRawResource(R.raw.privacy_policy)
            .bufferedReader()
            .use { it.readText() }

        val textView = TextView(this)
        textView.text = policyText
        textView.textSize = 14f
        textView.setPadding(48, 32, 48, 48)
        textView.setLineSpacing(4f, 1.1f)

        val scroll = ScrollView(this)
        scroll.addView(textView)
        setContentView(scroll)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
