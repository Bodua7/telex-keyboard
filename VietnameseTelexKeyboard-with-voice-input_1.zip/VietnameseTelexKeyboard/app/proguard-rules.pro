# R8/ProGuard rules for the release build (minifyEnabled true, see
# app/build.gradle). The default rules AGP mixes in
# (proguard-android-optimize.txt) already keep any class extending
# android.app.Service — which covers TelexIME transitively, since
# InputMethodService extends Service — and any class extending
# android.app.Activity, which covers SetupActivity and
# PrivacyPolicyActivity. The explicit rules below are kept anyway so
# renaming/refactoring these classes later can't silently break the
# system's ability to find them by the class name declared in
# AndroidManifest.xml.

# Input method service — instantiated by the system by class name from
# the manifest <service> entry, not by any code in this app, so R8 has
# no call site to see and would otherwise be free to rename/strip it.
-keep class com.example.telexkeyboard.TelexIME { *; }

# Launcher/settings activities, instantiated the same way.
-keep class com.example.telexkeyboard.SetupActivity { *; }
-keep class com.example.telexkeyboard.PrivacyPolicyActivity { *; }

# TelexEngine's public API is exercised from the instrumented/unit test
# source set (TelexEngineTest.kt), which isn't part of the release
# compile unit R8 sees — keep it from being stripped as "unused".
-keep class com.example.telexkeyboard.TelexEngine { *; }

# Standard Kotlin metadata some libraries introspect at runtime.
-keepattributes *Annotation*, InnerClasses, Signature, SourceFile, LineNumberTable
-keep class kotlin.Metadata { *; }

# Keep enum switch machinery (harmless if unused, cheap safety net).
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
