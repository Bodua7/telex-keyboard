# Bàn Phím Telex (Vietnamese Telex Android Keyboard)

Một bàn phím ảo Android (IME) với bố cục dạng QWERTY giống bàn phím PC,
gõ tiếng Việt theo kiểu **Telex** (giống Unikey/EVKey khi bật Telex trên máy tính).

## Cấu trúc dự án

```
VietnameseTelexKeyboard/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/telexkeyboard/
│       │   ├── TelexEngine.kt   # bộ xử lý quy tắc gõ Telex -> tiếng Việt
│       │   ├── TelexIME.kt      # InputMethodService + bàn phím
│       │   ├── VoiceInputActivity.kt # nhập bằng giọng nói tiếng Việt
│       │   └── SetupActivity.kt # màn hình hướng dẫn bật bàn phím
│       └── res/
│           ├── xml/
│           │   ├── method.xml
│           │   ├── keyboard_qwerty.xml   # layout QWERTY chính
│           │   └── keyboard_symbols.xml  # layout số/ký hiệu (phím ?123)
│           ├── mipmap-anydpi-v26/        # icon adaptive (API 26+)
│           ├── mipmap/ic_launcher.xml    # icon fallback (API 21-25)
│           └── values/strings.xml
├── app/proguard-rules.pro
├── PRIVACY_POLICY.md
├── build.gradle
└── settings.gradle
```

## Cách build & cài đặt

1. Mở thư mục `VietnameseTelexKeyboard` bằng **Android Studio** (File → Open).
2. Đợi Gradle sync xong (cần kết nối mạng để tải Gradle/AGP/Kotlin lần đầu).
3. Cắm điện thoại (hoặc dùng máy ảo) và bấm **Run ▶**.
4. App sẽ mở màn hình hướng dẫn — bấm **"Mở cài đặt bàn phím"** rồi bật
   **"Bàn Phím Telex"** trong danh sách bàn phím của Android.
5. Vào một ô nhập văn bản bất kỳ (Tin nhắn, Ghi chú...), chạm giữ biểu
   tượng chuyển bàn phím (hoặc phím dấu cách khi có nhiều bàn phím) để
   chọn "Bàn Phím Telex".
6. Chạm biểu tượng **micro** trên thanh công cụ, cấp quyền micro khi được
   hỏi, nói tiếng Việt rồi xác nhận kết quả để chèn vào ô nhập.

## Quy tắc gõ Telex đã hỗ trợ

| Gõ | Ra | Gõ | Ra |
|----|----|----|----|
| aa | â  | dd | đ  |
| aw | ă  | s  | dấu sắc (á) |
| ee | ê  | f  | dấu huyền (à) |
| oo | ô  | r  | dấu hỏi (ả) |
| ow | ơ  | x  | dấu ngã (ã) |
| uw | ư  | j  | dấu nặng (ạ) |
| w  | ư (gõ riêng lẻ) | z | xóa dấu vừa đặt |

Ví dụ: `vieejt nam` → `việt nam`, `chaof` → `chào`, `ddeejp` → `đẹp`.

## Giới hạn hiện tại (v1)

- Việc đặt dấu thanh vào đúng nguyên âm trong các cụm 2–3 nguyên âm dùng
  quy tắc phổ biến (ưu tiên nguyên âm đã biến đổi như ê/ơ/ư; nếu không,
  âm tiết đóng → dấu ở nguyên âm cuối, âm tiết mở → dấu ở nguyên âm đầu).
  Đây là quy tắc chuẩn cho phần lớn trường hợp, nhưng vài từ hiếm có thể
  cần bạn gõ lại `z` rồi gõ dấu ở vị trí khác nếu sai.
- Chưa có gợi ý từ (word suggestion). Đây là hướng có thể mở rộng thêm sau.

## Nhấn giữ & vuốt phím

- **Nhấn giữ hàng số** (1-0): hiện popup ký hiệu tương ứng
  (`1→!`, `2→@`, `3→#`, `4→$`, `5→%`, `6→^`, `7→&`, `8→*`, `9→(`, `0→)`).
  Trượt ngón tay lên ô ký hiệu trong popup rồi thả ra để gõ ký hiệu đó.
- **Vuốt trái/phải** trên bàn phím: di chuyển con trỏ sang trái/phải.
- **Vuốt lên**: chuyển nhanh QWERTY ⇄ Ký hiệu (?123), không cần chạm nút.
- **Vuốt xuống**: ẩn bàn phím.
- **Nhấn giữ phím Xóa/Cách**: đã hỗ trợ sẵn (`isRepeatable`), tự lặp lại
  khi giữ.

## Gõ vuốt liên tục (glide typing)

Trên lớp QWERTY, thay vì gõ từng chữ, bạn có thể **chạm vào chữ cái đầu
rồi kéo ngón tay lướt qua các chữ cái tiếp theo của từ mà không nhấc tay**
(giống Gboard/SwiftKey) — ví dụ lướt qua `c → h → a → o` rồi thả ra để gõ
"chào".

- Cần lướt qua **ít nhất 3 phím chữ cái khác nhau** và di chuyển đủ xa
  (~1.5 lần bề rộng 1 phím) mới được tính là gõ vuốt; chạm/kéo ngắn vẫn
  gõ 1 ký tự bình thường như trước.
- Từ được chọn theo khoảng cách gần nhất (Levenshtein) giữa đường vuốt và
  danh sách từ trong `app/src/main/assets/words_vi.txt` (đã bỏ dấu, gộp
  chữ lặp liền kề) — chữ cái đầu luôn phải khớp.
- Đây là **từ điển khởi đầu** (~250 từ thông dụng) và **thuật toán so
  khớp đơn giản**, không phải mô hình dự đoán ngôn ngữ đầy đủ: không học
  theo thói quen gõ, không xét ngữ cảnh câu trước đó. Muốn thêm từ: chỉ
  cần thêm dòng mới vào `words_vi.txt`, không cần sửa code
  (`GlideTypingEngine.kt`).
- Không áp dụng cho lớp Ký hiệu (?123) — ở đó mọi thao tác vuốt/chạm vẫn
  gõ ký tự như bình thường.
- Bàn phím dùng `android.inputmethodservice.KeyboardView` (API cũ nhưng
  vẫn hoạt động tốt trên mọi phiên bản Android hiện hành).

## Mở rộng thêm

- Muốn giao diện đẹp hơn (theo Material 3, có preview phím nổi khi
  chạm...) thì viết lại `onCreateInputView()` bằng Jetpack Compose hoặc
  custom View thay vì `KeyboardView` cũ.
- Muốn gõ kiểu VNI thay vì Telex: chỉ cần viết thêm một `VniEngine.kt`
  tương tự và cho người dùng chọn kiểu gõ trong `SetupActivity`.

## Phát hành bản release

- **Icon**: icon adaptive thật ở `app/src/main/res/mipmap-anydpi-v26/`
  (nền + biểu tượng chữ "đ" cách điệu) cho Android 8+, và bản vector gộp
  ở `app/src/main/res/mipmap/ic_launcher.xml` làm dự phòng cho Android
  5.0–7.1. Muốn đổi thiết kế: sửa
  `drawable/ic_launcher_background.xml` và
  `drawable/ic_launcher_foreground.xml`, rồi cập nhật lại bản gộp trong
  `mipmap/ic_launcher.xml` cho khớp.
- **versionCode / versionName**: khai báo trong `app/build.gradle`.
  Tăng `versionCode` thêm 1 ở MỌI bản build nộp lên Play Store (bắt
  buộc, phải tăng dần); `versionName` tuỳ bạn đặt sao cho người dùng dễ
  hiểu (bản này là `1.2`, có thêm nhập bằng giọng nói).
- **ProGuard/R8**: `buildTypes.release` đã bật `minifyEnabled true` +
  `shrinkResources true`, dùng rule ở `app/proguard-rules.pro`. Build
  release: `./gradlew assembleRelease` (hoặc `bundleRelease` cho AAB).
- **Ký ứng dụng (signing)**: dự án **không** kèm theo keystore (đây là
  bí mật, không nên đưa vào repo — mất keystore nghĩa là không thể phát
  hành bản cập nhật cho cùng một app trên Play Store nữa). Xem hướng
  dẫn tạo keystore + khai báo `signingConfig` ngay trong comment ở đầu
  `app/build.gradle`.
- **Chính sách quyền riêng tư**: `PRIVACY_POLICY.md` ở thư mục gốc —
  nội dung giống hệt màn hình "Chính sách quyền riêng tư" trong app
  (`PrivacyPolicyActivity`, đọc từ `res/raw/privacy_policy.txt`). Play
  Console yêu cầu một **URL công khai** cho chính sách này — host file
  `PRIVACY_POLICY.md` ở đâu đó công khai (GitHub Pages, Gist, trang web
  riêng...) rồi dán URL đó vào Play Console. Sửa nội dung ở cả hai chỗ
  nếu chính sách thay đổi (hai bản hiện đang giống hệt nhau).
