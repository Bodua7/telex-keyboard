# Chính sách quyền riêng tư — Bàn Phím Telex

Cập nhật lần cuối: 09/08/2026

## Tóm tắt

Bàn Phím Telex không xin quyền truy cập Internet (không có quyền
`INTERNET` trong AndroidManifest.xml). Nội dung bạn gõ và clipboard không
được ứng dụng gửi đi; ứng dụng không có máy chủ, analytics hay quảng cáo
riêng.

## Dữ liệu ứng dụng xử lý, và xử lý ở đâu

Tất cả dữ liệu bàn phím đều được xử lý trên thiết bị của bạn:

- **Nội dung đang gõ (bộ đệm Telex)**: chỉ tồn tại tạm thời trong bộ nhớ
  khi bạn đang gõ một từ, dùng để chuyển ký tự Telex (vd. "aa", "ow")
  thành tiếng Việt có dấu. Không được lưu lại, không được ghi log.
- **Lịch sử clipboard (phiên hiện tại)**: ứng dụng lắng nghe khi bạn sao
  chép văn bản để hiển thị trong bảng clipboard của bàn phím, giúp dán
  lại nhanh. Danh sách này chỉ tồn tại trong bộ nhớ khi ứng dụng bàn phím
  đang chạy và mất khi tiến trình bàn phím dừng.
- **Mục clipboard đã ghim**: nếu bạn chủ động ghim một mục, nội dung đó
  được lưu cục bộ trên máy cho tới khi bạn bỏ ghim, xoá, hoặc gỡ ứng dụng.
- **Tuỳ chọn cỡ bàn phím**: lựa chọn Nhỏ/Vừa/Lớn được lưu cục bộ để nhớ
  cho lần sau.
- **Nhập bằng giọng nói**: khi bạn chủ động bấm nút mic, ứng dụng xin
  quyền micro và mở giao diện nhận dạng giọng nói do Android cung cấp.
  Kết quả văn bản được chèn vào ô đang nhập. Việc xử lý âm thanh có thể
  do dịch vụ nhận dạng giọng nói bạn đã cài trên thiết bị thực hiện; dịch
  vụ đó có thể có chính sách riêng và có thể cần kết nối mạng.

## Quyền ứng dụng xin

- **Rung (VIBRATE)**: dùng cho phản hồi rung khi gõ phím, nếu bạn bật
  tính năng rung trên hệ thống.
- **Micro (RECORD_AUDIO)**: chỉ dùng sau khi bạn chủ động bấm nút mic để
  nhập bằng giọng nói. Ứng dụng không tự bật micro khi bạn đang gõ phím.

Ứng dụng không xin quyền Internet, danh bạ, vị trí, camera, hay bất kỳ
quyền nhạy cảm nào khác ngoài micro khi bạn dùng tính năng này.

## Vì sao một bàn phím cần được tin tưởng

Ứng dụng bàn phím về nguyên tắc có khả năng thấy mọi thứ bạn gõ. Việc
không xin quyền Internet giúp ứng dụng không thể tự gửi nội dung gõ hoặc
clipboard ra ngoài. Tính năng giọng nói là ngoại lệ theo lựa chọn của bạn
và có thể do dịch vụ nhận dạng của Android xử lý.

## Xoá dữ liệu của bạn

- Bỏ ghim/xoá từng mục clipboard đã ghim ngay trong bảng clipboard của
  bàn phím.
- "Xoá tất cả" trong bảng clipboard xoá lịch sử clipboard chưa ghim của
  phiên hiện tại.
- Gỡ cài đặt ứng dụng sẽ xoá toàn bộ dữ liệu cục bộ nói trên.

## Trẻ em

Ứng dụng không được thiết kế riêng cho trẻ em và không cố ý thu thập
thông tin từ trẻ em. Tính năng giọng nói chỉ được dùng sau thao tác bấm
mic của người dùng.

## Thay đổi chính sách này

Nếu chính sách thay đổi, ngày "Cập nhật lần cuối" ở đầu trang sẽ được
cập nhật và mô tả thay đổi sẽ có trong ghi chú phát hành.

## Liên hệ

Có câu hỏi về chính sách này, liên hệ: [điền email liên hệ của bạn ở đây]