package com.example.telexkeyboard

/**
 * Converts a raw sequence of Telex keystrokes (e.g. "vieejt" or "chaof")
 * into properly-accented Vietnamese text (e.g. "việt", "chào").
 *
 * The caller is expected to keep a per-word "raw buffer" of every key
 * typed since the last word boundary (space / punctuation / enter) and
 * call transform() again on the whole buffer after every keystroke,
 * replacing whatever was previously composed in the text field. This
 * mirrors how most desktop/mobile Telex engines (Unikey, EVKey, etc.)
 * work internally.
 */
object TelexEngine {

    // index: 0 = no tone, 1 = sắc, 2 = huyền, 3 = hỏi, 4 = ngã, 5 = nặng
    private val toneTable = mapOf(
        'a' to charArrayOf('a', 'á', 'à', 'ả', 'ã', 'ạ'),
        'ă' to charArrayOf('ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ'),
        'â' to charArrayOf('â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'),
        'e' to charArrayOf('e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ'),
        'ê' to charArrayOf('ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'),
        'i' to charArrayOf('i', 'í', 'ì', 'ỉ', 'ĩ', 'ị'),
        'o' to charArrayOf('o', 'ó', 'ò', 'ỏ', 'õ', 'ọ'),
        'ô' to charArrayOf('ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ'),
        'ơ' to charArrayOf('ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'),
        'u' to charArrayOf('u', 'ú', 'ù', 'ủ', 'ũ', 'ụ'),
        'ư' to charArrayOf('ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'),
        'y' to charArrayOf('y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ')
    )

    private val modifiedVowels = setOf('ă', 'â', 'ê', 'ô', 'ơ', 'ư')
    private val plainVowels = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val vowels = plainVowels + modifiedVowels

    private fun baseOf(c: Char): Char {
        for ((base, arr) in toneTable) if (arr.contains(c)) return base
        return c
    }

    private fun toneOf(c: Char): Int {
        for (arr in toneTable.values) {
            val idx = arr.indexOf(c)
            if (idx >= 0) return idx
        }
        return 0
    }

    private fun applyTone(c: Char, tone: Int): Char {
        val arr = toneTable[baseOf(c)] ?: return c
        return arr[tone]
    }

    fun transform(raw: String): String {
        val out = StringBuilder()

        // Tracks what the immediately preceding "w" keystroke did to `out`,
        // so that pressing "w" twice in a row can undo it and fall back to
        // a literal "w" — the standard Telex convention for typing words
        // that contain a real "w" (e.g. "wifi", "web").
        var prevWEditIndex = -1
        var prevWEditOriginal = ' '
        var prevWAppendIndex = -1

        for (i in raw.indices) {
            val ch = raw[i]
            val lower = ch.lowercaseChar()
            val isUpper = ch.isUpperCase()
            val prevWasW = i > 0 && raw[i - 1].lowercaseChar() == 'w'

            when (lower) {
                'd' -> {
                    val lastIdx = out.length - 1
                    if (lastIdx >= 0 && out[lastIdx].lowercaseChar() == 'd' &&
                        out[lastIdx] != 'đ' && out[lastIdx] != 'Đ'
                    ) {
                        out.setCharAt(lastIdx, if (out[lastIdx].isUpperCase()) 'Đ' else 'đ')
                    } else {
                        out.append(ch)
                    }
                    prevWEditIndex = -1; prevWAppendIndex = -1
                }

                'a', 'e', 'o' -> {
                    val lastIdx = out.length - 1
                    if (lastIdx >= 0 && out[lastIdx].lowercaseChar() == lower) {
                        val newBase = when (lower) {
                            'a' -> 'â'
                            'e' -> 'ê'
                            else -> 'ô'
                        }
                        out.setCharAt(
                            lastIdx,
                            if (out[lastIdx].isUpperCase()) newBase.uppercaseChar() else newBase
                        )
                    } else {
                        out.append(ch)
                    }
                    prevWEditIndex = -1; prevWAppendIndex = -1
                }

                'w' -> {
                    if (prevWasW && (prevWEditIndex >= 0 || prevWAppendIndex >= 0)) {
                        // Second consecutive "w": undo whatever the previous
                        // w did, then insert a literal "w" for this keystroke.
                        if (prevWAppendIndex >= 0 && prevWAppendIndex == out.length - 1) {
                            out.deleteCharAt(prevWAppendIndex)
                        } else if (prevWEditIndex >= 0 && prevWEditIndex < out.length) {
                            out.setCharAt(prevWEditIndex, prevWEditOriginal)
                        }
                        out.append(if (isUpper) 'W' else 'w')
                        prevWEditIndex = -1; prevWAppendIndex = -1
                    } else {
                        val lastIdx = out.length - 1
                        val lastBase = if (lastIdx >= 0) out[lastIdx].lowercaseChar() else ' '
                        val uIdx = lastIdx - 1
                        val precededByQ = uIdx - 1 >= 0 && out[uIdx - 1].lowercaseChar() == 'q'

                        if (lastBase == 'o' && lastIdx > 0 &&
                            out[uIdx].lowercaseChar() == 'u' && !precededByQ
                        ) {
                            // "uo" + w -> "ươ": the horn applies to BOTH
                            // vowels of the diphthong (e.g. "nuowc" -> "nươc"),
                            // not just the closer one — unless the "u" is the
                            // silent glide after "q" (e.g. "quow" -> "quơ").
                            out.setCharAt(uIdx, if (out[uIdx].isUpperCase()) 'Ư' else 'ư')
                            out.setCharAt(lastIdx, if (out[lastIdx].isUpperCase()) 'Ơ' else 'ơ')
                            prevWEditIndex = lastIdx
                            prevWEditOriginal = if (isUpper) 'O' else 'o'
                            prevWAppendIndex = -1
                        } else {
                            val newBase = when (lastBase) {
                                'a' -> 'ă'
                                'o' -> 'ơ'
                                'u' -> 'ư'
                                else -> null
                            }
                            if (newBase != null) {
                                val original = out[lastIdx]
                                out.setCharAt(
                                    lastIdx,
                                    if (out[lastIdx].isUpperCase()) newBase.uppercaseChar() else newBase
                                )
                                prevWEditIndex = lastIdx
                                prevWEditOriginal = original
                                prevWAppendIndex = -1
                            } else {
                                // "w" typed alone is a common shortcut for "ư"
                                out.append(if (isUpper) 'Ư' else 'ư')
                                prevWAppendIndex = out.length - 1
                                prevWEditIndex = -1
                            }
                        }
                    }
                }

                's', 'f', 'r', 'x', 'j' -> {
                    val tone = when (lower) {
                        's' -> 1
                        'f' -> 2
                        'r' -> 3
                        'x' -> 4
                        else -> 5
                    }
                    val pos = findToneTarget(out)
                    if (pos >= 0) {
                        out.setCharAt(pos, applyTone(out[pos], tone))
                    } else {
                        out.append(ch)
                    }
                    prevWEditIndex = -1; prevWAppendIndex = -1
                }

                'z' -> {
                    val pos = findToneTarget(out)
                    if (pos >= 0 && toneOf(out[pos]) != 0) {
                        out.setCharAt(pos, applyTone(out[pos], 0))
                    } else {
                        out.append(ch)
                    }
                    prevWEditIndex = -1; prevWAppendIndex = -1
                }

                else -> {
                    out.append(ch)
                    prevWEditIndex = -1; prevWAppendIndex = -1
                }
            }
        }

        return out.toString()
    }

    /**
     * Finds the index inside [out] of the vowel that should carry the tone
     * mark, following standard Vietnamese tone-placement rules:
     *  1. A vowel that already has an inherent modifier (ă â ê ô ơ ư) wins.
     *  2. Otherwise, in a closed syllable (consonant after the vowel
     *     cluster) the tone goes on the last vowel of the cluster.
     *  3. In an open syllable (vowel cluster ends the word) the tone goes
     *     on the first vowel of the cluster (classic/dictionary style,
     *     e.g. "hòa", "thúy").
     * The glide u/i in "qu-"/"gi-" is ignored when other vowels exist.
     */
    private fun findToneTarget(out: StringBuilder): Int {
        if (out.isEmpty()) return -1

        var start = out.length
        while (start > 0 && out[start - 1].isLetter()) start--
        val syllable = out.substring(start)
        if (syllable.isEmpty()) return -1

        val positions = mutableListOf<Int>()
        for (k in syllable.indices) {
            if (vowels.contains(syllable[k].lowercaseChar())) positions.add(start + k)
        }
        if (positions.isEmpty()) return -1

        val lowerSyll = syllable.lowercase()
        if (positions.size > 1) {
            if ((lowerSyll.startsWith("qu") || lowerSyll.startsWith("gi")) &&
                positions[0] == start + 1
            ) {
                positions.removeAt(0)
            }
        }
        if (positions.isEmpty()) return -1
        if (positions.size == 1) return positions[0]

        // If more than one vowel already carries an inherent modifier, the
        // *last* one wins (this only really happens with "ươ", e.g.
        // "được", "nước", "trường" — the tone goes on the ơ, not the ư).
        val modifiedPositions = positions.filter { modifiedVowels.contains(out[it].lowercaseChar()) }
        if (modifiedPositions.isNotEmpty()) return modifiedPositions.last()

        val lastVowelPos = positions.last()
        val isClosed = lastVowelPos < out.length - 1
        return if (isClosed) positions.last() else positions.first()
    }
}
