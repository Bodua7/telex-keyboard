package com.example.telexkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("telex_prefs", MODE_PRIVATE)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(48, 96, 48, 48)

        val title = TextView(this)
        title.text = "Bàn Phím Telex"
        title.textSize = 22f

        val desc = TextView(this)
        desc.text = "1. Bấm nút bên dưới để bật \"Bàn Phím Telex\" trong Cài đặt.\n\n" +
            "2. Khi soạn văn bản, chạm giữ biểu tượng chuyển bàn phím để chọn " +
            "\"Bàn Phím Telex\".\n\n" +
            "3. Quy tắc gõ: aa=â, aw=ă, ee=ê, oo=ô, ow=ơ, uw=ư, dd=đ, " +
            "s=sắc, f=huyền, r=hỏi, x=ngã, j=nặng, z=xóa dấu.\n\n" +
            "4. Trên bàn phím có thanh công cụ với biểu tượng 📋 (khay nhớ " +
            "clipboard), ⚙️ (cài đặt nhanh) và 🌐 (chuyển bàn phím khác)."
        desc.setPadding(0, 24, 0, 32)

        val enableBtn = Button(this)
        enableBtn.text = "Mở cài đặt bàn phím"
        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        val sizeLabel = TextView(this)
        sizeLabel.text = "\nKích thước bàn phím:"
        sizeLabel.setPadding(0, 48, 0, 16)

        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL

        fun sizeButton(label: String, value: Int): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener {
                prefs.edit().putInt("keyboard_size", value).apply()
                Toast.makeText(
                    this,
                    "Đã lưu. Chuyển sang app khác rồi quay lại để thấy thay đổi.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            params.setMargins(8, 0, 8, 0)
            b.layoutParams = params
            return b
        }

        sizeRow.addView(sizeButton("Nhỏ", 0))
        sizeRow.addView(sizeButton("Vừa", 1))
        sizeRow.addView(sizeButton("Lớn", 2))

        val clipLabel = TextView(this)
        clipLabel.text = "\nKhay nhớ (clipboard):"
        clipLabel.setPadding(0, 48, 0, 16)

        fun refreshClipToggle(btn: Button) {
            val on = prefs.getBoolean("clipboard_enabled", true)
            btn.text = if (on) "Đang lưu khay nhớ: Bật (bấm để tắt)" else "Đang lưu khay nhớ: Tắt (bấm để bật)"
        }

        val clipToggleBtn = Button(this)
        refreshClipToggle(clipToggleBtn)
        clipToggleBtn.setOnClickListener {
            val on = prefs.getBoolean("clipboard_enabled", true)
            prefs.edit().putBoolean("clipboard_enabled", !on).apply()
            refreshClipToggle(clipToggleBtn)
        }

        val clearClipBtn = Button(this)
        clearClipBtn.text = "Xóa lịch sử khay nhớ"
        clearClipBtn.setOnClickListener {
            prefs.edit().putString("clipboard_history", "[]").apply()
            Toast.makeText(this, "Đã xóa lịch sử khay nhớ.", Toast.LENGTH_SHORT).show()
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(enableBtn)
        layout.addView(sizeLabel)
        layout.addView(sizeRow)
        layout.addView(clipLabel)
        layout.addView(clipToggleBtn)
        layout.addView(clearClipBtn)
        setContentView(layout)
    }
}
