package com.example.telexkeyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class TelexIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    // Root container: toolbar strip + swappable keyboard/clipboard/settings area.
    private var rootView: LinearLayout? = null
    private var inputArea: FrameLayout? = null
    private var clipboardPanel: ScrollView? = null
    private var clipboardList: LinearLayout? = null
    private var settingsPanel: ScrollView? = null
    private var btnClipboard: TextView? = null
    private var btnSettings: TextView? = null
    private var btnToggleHistory: TextView? = null

    // Raw Telex keystrokes typed since the last word boundary (space,
    // punctuation, enter). Re-transformed into Vietnamese on every keystroke.
    private val rawBuffer = StringBuilder()

    // Length (in chars) of the Vietnamese text currently composed & sent
    // to the editor for rawBuffer, so we know how much to delete before
    // sending the updated version.
    private var composedLength = 0

    private var capsOn = false

    // Ctrl / Alt behave like one-shot modifiers (same idea as Shift above):
    // tap to arm, the next key is sent as a real KeyEvent combo (e.g. Ctrl+C),
    // then the modifier auto-clears.
    private var ctrlOn = false
    private var altOn = false

    // Clipboard / memory history.
    private lateinit var prefs: SharedPreferences
    private var clipboardManager: ClipboardManager? = null
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    companion object {
        const val KEYCODE_SHIFT = -12
        const val KEYCODE_CTRL = -10
        const val KEYCODE_ALT = -11
        const val PREFS_NAME = "telex_prefs"
        const val KEY_CLIP_HISTORY = "clipboard_history"
        const val KEY_CLIP_ENABLED = "clipboard_enabled"
        const val MAX_CLIP_HISTORY = 20
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        clipboardManager = getSystemService(CLIPBOARD_SERVICE) as? ClipboardManager
        clipListener = ClipboardManager.OnPrimaryClipChangedListener {
            captureCurrentClip()
        }
        clipboardManager?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        clipListener?.let { clipboardManager?.removePrimaryClipChangedListener(it) }
    }

    private fun captureCurrentClip() {
        if (!prefs.getBoolean(KEY_CLIP_ENABLED, true)) return
        val clip = clipboardManager?.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
        if (text.isEmpty()) return
        addClipItem(text)
    }

    // ---- Clipboard history storage (SharedPreferences, JSON array) ----

    private fun loadClipHistory(): MutableList<String> {
        val raw = prefs.getString(KEY_CLIP_HISTORY, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i -> arr.getString(i) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun saveClipHistory(items: List<String>) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        prefs.edit().putString(KEY_CLIP_HISTORY, arr.toString()).apply()
    }

    private fun addClipItem(text: String) {
        val items = loadClipHistory()
        items.remove(text)
        items.add(0, text)
        while (items.size > MAX_CLIP_HISTORY) items.removeAt(items.size - 1)
        saveClipHistory(items)
        refreshClipboardPanel()
    }

    private fun removeClipItem(text: String) {
        val items = loadClipHistory()
        items.remove(text)
        saveClipHistory(items)
        refreshClipboardPanel()
    }

    private fun clearClipHistory() {
        saveClipHistory(emptyList())
        refreshClipboardPanel()
    }

    // ---- Input view construction ----

    override fun onCreateInputView(): View {
        val container = layoutInflater.inflate(R.layout.keyboard_container, null) as LinearLayout
        rootView = container
        inputArea = container.findViewById(R.id.input_area)
        keyboardView = container.findViewById(R.id.keyboard_view)
        clipboardPanel = container.findViewById(R.id.clipboard_panel)
        clipboardList = container.findViewById(R.id.clipboard_list)
        settingsPanel = container.findViewById(R.id.settings_panel)
        btnClipboard = container.findViewById(R.id.btn_clipboard)
        btnSettings = container.findViewById(R.id.btn_settings)
        btnToggleHistory = container.findViewById(R.id.btn_toggle_clipboard_history)

        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = true

        setupToolbar(container)
        setupSettingsPanel(container)
        refreshClipboardPanel()
        showKeyboardPanel()

        return container
    }

    private fun setupToolbar(container: LinearLayout) {
        container.findViewById<TextView>(R.id.btn_clipboard).setOnClickListener {
            if (clipboardPanel?.visibility == View.VISIBLE) showKeyboardPanel() else showClipboardPanel()
        }
        container.findViewById<TextView>(R.id.btn_symbols).setOnClickListener {
            showKeyboardPanel()
            keyboardView.keyboard =
                if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
            setModifierKeyVisual(KEYCODE_SHIFT, capsOn, qwertyKeyboard)
            clearModifiers()
        }
        container.findViewById<TextView>(R.id.btn_settings).setOnClickListener {
            if (settingsPanel?.visibility == View.VISIBLE) showKeyboardPanel() else showSettingsPanel()
        }
        container.findViewById<TextView>(R.id.btn_switch_ime).setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        container.findViewById<TextView>(R.id.btn_more).setOnClickListener {
            Toast.makeText(
                this,
                "Quy tắc: aa=â, aw=ă, ee=ê, oo=ô, ow=ơ, uw=ư, dd=đ · s/f/r/x/j = sắc/huyền/hỏi/ngã/nặng · z = xóa dấu",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun showKeyboardPanel() {
        keyboardView.visibility = View.VISIBLE
        clipboardPanel?.visibility = View.GONE
        settingsPanel?.visibility = View.GONE
        btnClipboard?.isSelected = false
        btnSettings?.isSelected = false
    }

    private fun showClipboardPanel() {
        refreshClipboardPanel()
        keyboardView.visibility = View.GONE
        settingsPanel?.visibility = View.GONE
        clipboardPanel?.visibility = View.VISIBLE
        btnClipboard?.isSelected = true
        btnSettings?.isSelected = false
    }

    private fun showSettingsPanel() {
        keyboardView.visibility = View.GONE
        clipboardPanel?.visibility = View.GONE
        settingsPanel?.visibility = View.VISIBLE
        btnSettings?.isSelected = true
        btnClipboard?.isSelected = false
    }

    private fun refreshClipboardPanel() {
        val list = clipboardList ?: return
        list.removeAllViews()
        val items = loadClipHistory()
        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Chưa có nội dung nào trong khay nhớ.\nSao chép (copy) văn bản bất kỳ để lưu vào đây."
            empty.setTextColor(0xFFB0B8C1.toInt())
            empty.setPadding(16, 24, 16, 24)
            list.addView(empty)
            return
        }
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(4, 4, 4, 4)

            val text = TextView(this)
            text.text = if (item.length > 80) item.substring(0, 80) + "…" else item
            text.setTextColor(0xFFFFFFFF.toInt())
            text.setBackgroundResource(R.drawable.panel_button_background)
            text.setPadding(24, 20, 24, 20)
            text.maxLines = 2
            val textParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            textParams.setMargins(4, 4, 4, 4)
            text.layoutParams = textParams
            text.setOnClickListener {
                currentInputConnection?.commitText(item, 1)
                showKeyboardPanel()
            }

            val delete = TextView(this)
            delete.text = "✕"
            delete.setTextColor(0xFFFFFFFF.toInt())
            delete.setBackgroundResource(R.drawable.panel_button_background)
            delete.gravity = android.view.Gravity.CENTER
            val delParams = LinearLayout.LayoutParams(64, ViewGroup.LayoutParams.MATCH_PARENT)
            delParams.setMargins(4, 4, 4, 4)
            delete.layoutParams = delParams
            delete.setOnClickListener { removeClipItem(item) }

            row.addView(text)
            row.addView(delete)
            list.addView(row)
        }
    }

    private fun setupSettingsPanel(container: LinearLayout) {
        val sizeRow = container.findViewById<LinearLayout>(R.id.size_row)
        sizeRow.removeAllViews()

        fun sizeButton(label: String, value: Int): TextView {
            val b = TextView(this)
            b.text = label
            b.setTextColor(0xFFFFFFFF.toInt())
            b.gravity = android.view.Gravity.CENTER
            b.setBackgroundResource(R.drawable.panel_button_background)
            b.setPadding(8, 20, 8, 20)
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            params.setMargins(4, 0, 4, 0)
            b.layoutParams = params
            b.setOnClickListener {
                prefs.edit().putInt("keyboard_size", value).apply()
                loadKeyboards()
                keyboardView.keyboard =
                    if (keyboardView.keyboard === symbolsKeyboard) symbolsKeyboard else qwertyKeyboard
                Toast.makeText(this, "Đã đổi kích thước bàn phím.", Toast.LENGTH_SHORT).show()
            }
            return b
        }

        sizeRow.addView(sizeButton("Nhỏ", 0))
        sizeRow.addView(sizeButton("Vừa", 1))
        sizeRow.addView(sizeButton("Lớn", 2))

        fun refreshToggleLabel() {
            val on = prefs.getBoolean(KEY_CLIP_ENABLED, true)
            btnToggleHistory?.text = if (on) "Lưu khay nhớ: Bật" else "Lưu khay nhớ: Tắt"
        }
        refreshToggleLabel()

        container.findViewById<TextView>(R.id.btn_toggle_clipboard_history).setOnClickListener {
            val on = prefs.getBoolean(KEY_CLIP_ENABLED, true)
            prefs.edit().putBoolean(KEY_CLIP_ENABLED, !on).apply()
            refreshToggleLabel()
        }

        container.findViewById<TextView>(R.id.btn_clear_clipboard).setOnClickListener {
            clearClipHistory()
            Toast.makeText(this, "Đã xóa lịch sử khay nhớ.", Toast.LENGTH_SHORT).show()
        }

        container.findViewById<TextView>(R.id.btn_full_settings).setOnClickListener {
            val intent = Intent(this, SetupActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun loadKeyboards() {
        val size = prefs.getInt("keyboard_size", 1) // 0=nhỏ, 1=vừa, 2=lớn
        val qwertyRes = when (size) {
            0 -> R.xml.keyboard_qwerty_small
            2 -> R.xml.keyboard_qwerty_large
            else -> R.xml.keyboard_qwerty
        }
        val symbolsRes = when (size) {
            0 -> R.xml.keyboard_symbols_small
            2 -> R.xml.keyboard_symbols_large
            else -> R.xml.keyboard_symbols
        }
        qwertyKeyboard = Keyboard(this, qwertyRes)
        symbolsKeyboard = Keyboard(this, symbolsRes)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        clearModifiers()
        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        showKeyboardPanel()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetWord()
        clearModifiers()
    }

    // Rebuilds the input view (picking up landscape/portrait-specific
    // keyboard XML resources) whenever the device orientation or other
    // configuration changes, instead of keeping a stale, potentially
    // oversized layout that can overflow the screen in landscape.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isInputViewShown || rootView != null) {
            setInputView(onCreateInputView())
        }
    }

    private fun resetWord() {
        rawBuffer.setLength(0)
        composedLength = 0
    }

    private fun clearModifiers() {
        ctrlOn = false
        altOn = false
        setModifierKeyVisual(KEYCODE_CTRL, false)
        setModifierKeyVisual(KEYCODE_ALT, false)
    }

    // Shift is a one-shot modifier too: tap to arm, capitalizes exactly the
    // next letter, then auto-clears. Fully self-managed (state + visual)
    // instead of relying on the framework's built-in KEYCODE_SHIFT handling,
    // which could get out of sync with our own state and garble typing.
    private fun setShift(on: Boolean) {
        capsOn = on
        setModifierKeyVisual(KEYCODE_SHIFT, on, qwertyKeyboard)
    }

    // Highlights/un-highlights a key on a keyboard so the user can see the
    // modifier is armed. Defaults to whichever keyboard (qwerty or symbols)
    // is CURRENTLY visible in keyboardView -- previously this always looked
    // at qwertyKeyboard's keys, so toggling Ctrl/Alt while the symbols page
    // was showing never lit up (the symbols keyboard has its own separate
    // Ctrl/Alt Key objects with the same codes). Shift only exists on the
    // qwerty page, so its callers explicitly pass qwertyKeyboard.
    private fun setModifierKeyVisual(code: Int, on: Boolean, keyboard: Keyboard? = null) {
        val kb = keyboard ?: (if (::keyboardView.isInitialized) keyboardView.keyboard else null) ?: return
        kb.keys
            .filter { it.codes.isNotEmpty() && it.codes[0] == code }
            .forEach { it.on = on }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    // Maps a letter/digit to its Android KeyEvent code so Ctrl/Alt combos
    // (Ctrl+C, Ctrl+V, Ctrl+Z, Alt+Tab-style shortcuts, ...) can be sent
    // as real key events instead of going through Telex composition.
    private fun keyEventCodeFor(c: Char): Int? = when (c) {
        in 'a'..'z' -> KeyEvent.KEYCODE_A + (c - 'a')
        in '0'..'9' -> KeyEvent.KEYCODE_0 + (c - '0')
        else -> null
    }

    private fun currentMetaState(): Int {
        var meta = 0
        if (ctrlOn) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (altOn) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        return meta
    }

    private fun sendKeyCodeWithModifiers(keyCode: Int) {
        val ic = currentInputConnection ?: return
        val meta = currentMetaState()
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    private fun updateComposing(newComposed: String) {
        val ic = currentInputConnection ?: return
        if (composedLength > 0) {
            ic.deleteSurroundingText(composedLength, 0)
        }
        ic.commitText(newComposed, 1)
        composedLength = newComposed.length
    }

    // Sends Enter the way the target app expects it: if the editor declared
    // a specific action (Search / Send / Go / Done / Next ...) and hasn't
    // opted out via IME_FLAG_NO_ENTER_ACTION, trigger that action instead
    // of a raw newline key event. Previously this always sent a raw Enter
    // KeyEvent, which silently fails to submit search bars, chat compose
    // boxes, and login forms that rely on the editor-action callback.
    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        val noEnterFlag = (info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION
        if (info != null && action != null && action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED && noEnterFlag == 0
        ) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                if (rawBuffer.isNotEmpty()) {
                    rawBuffer.deleteCharAt(rawBuffer.length - 1)
                    if (rawBuffer.isEmpty()) {
                        updateComposing("")
                        resetWord()
                    } else {
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    }
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
                clearModifiers()
            }

            KEYCODE_SHIFT -> {
                setShift(!capsOn)
            }

            Keyboard.KEYCODE_MODE_CHANGE -> {
                keyboardView.keyboard =
                    if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
                // Symbols keyboard has no Shift key; resync the qwerty
                // Shift key's highlight for whenever we switch back to it.
                setModifierKeyVisual(KEYCODE_SHIFT, capsOn, qwertyKeyboard)
                clearModifiers()
            }

            KEYCODE_CTRL -> {
                ctrlOn = !ctrlOn
                setModifierKeyVisual(KEYCODE_CTRL, ctrlOn)
            }

            KEYCODE_ALT -> {
                altOn = !altOn
                setModifierKeyVisual(KEYCODE_ALT, altOn)
            }

            -4 -> { // Enter / Done
                resetWord()
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_ENTER)
                    clearModifiers()
                } else {
                    sendEnter()
                }
            }

            32 -> { // space = word boundary
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_SPACE)
                    clearModifiers()
                } else {
                    resetWord()
                    ic.commitText(" ", 1)
                }
            }

            else -> {
                var c = primaryCode.toChar()
                c = if (capsOn) c.uppercaseChar() else c.lowercaseChar()

                if (ctrlOn || altOn) {
                    // Ctrl/Alt + letter or digit = shortcut, not Telex text.
                    val keyCode = keyEventCodeFor(c.lowercaseChar())
                    if (keyCode != null) {
                        sendKeyCodeWithModifiers(keyCode)
                    }
                    resetWord()
                    clearModifiers()
                } else if (c.isLetter()) {
                    rawBuffer.append(c)
                    updateComposing(TelexEngine.transform(rawBuffer.toString()))
                } else {
                    // punctuation etc. = word boundary
                    resetWord()
                    ic.commitText(c.toString(), 1)
                }

                if (capsOn) {
                    setShift(false)
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
