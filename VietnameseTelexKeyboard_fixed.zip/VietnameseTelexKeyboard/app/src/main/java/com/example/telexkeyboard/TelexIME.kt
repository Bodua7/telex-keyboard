package com.example.telexkeyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class TelexIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    // Raw Telex keystrokes typed since the last word boundary (space,
    // punctuation, enter). Re-transformed into Vietnamese on every keystroke.
    private val rawBuffer = StringBuilder()

    // Length (in chars) of the Vietnamese text currently composed & sent
    // to the editor for rawBuffer, so we know how much to delete before
    // sending the updated version.
    private var composedLength = 0

    private var capsOn = false

    // Ctrl / Alt behave like one-shot modifiers (same idea as Shift above):
    // tap to arm, the next key is sent as a real KeyEvent combo (e.g. Ctrl+C),
    // then the modifier auto-clears.
    private var ctrlOn = false
    private var altOn = false

    companion object {
        const val KEYCODE_SHIFT = -12
        const val KEYCODE_CTRL = -10
        const val KEYCODE_ALT = -11
    }

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView
        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = true
        return keyboardView
    }

    private fun loadKeyboards() {
        val prefs = getSharedPreferences("telex_prefs", MODE_PRIVATE)
        val size = prefs.getInt("keyboard_size", 1) // 0=nhỏ, 1=vừa, 2=lớn
        val qwertyRes = when (size) {
            0 -> R.xml.keyboard_qwerty_small
            2 -> R.xml.keyboard_qwerty_large
            else -> R.xml.keyboard_qwerty
        }
        val symbolsRes = when (size) {
            0 -> R.xml.keyboard_symbols_small
            2 -> R.xml.keyboard_symbols_large
            else -> R.xml.keyboard_symbols
        }
        qwertyKeyboard = Keyboard(this, qwertyRes)
        symbolsKeyboard = Keyboard(this, symbolsRes)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        clearModifiers()
        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetWord()
        clearModifiers()
    }

    private fun resetWord() {
        rawBuffer.setLength(0)
        composedLength = 0
    }

    private fun clearModifiers() {
        ctrlOn = false
        altOn = false
        setModifierKeyVisual(KEYCODE_CTRL, false)
        setModifierKeyVisual(KEYCODE_ALT, false)
    }

    // Shift is a one-shot modifier too: tap to arm, capitalizes exactly the
    // next letter, then auto-clears. Fully self-managed (state + visual)
    // instead of relying on the framework's built-in KEYCODE_SHIFT handling,
    // which could get out of sync with our own state and garble typing.
    private fun setShift(on: Boolean) {
        capsOn = on
        setModifierKeyVisual(KEYCODE_SHIFT, on)
    }

    // Highlights/un-highlights the Ctrl or Alt key(s) on the currently loaded
    // keyboard so the user can see the modifier is armed.
    private fun setModifierKeyVisual(code: Int, on: Boolean) {
        if (!::qwertyKeyboard.isInitialized) return
        qwertyKeyboard.keys
            .filter { it.codes.isNotEmpty() && it.codes[0] == code }
            .forEach { it.on = on }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    // Maps a letter/digit to its Android KeyEvent code so Ctrl/Alt combos
    // (Ctrl+C, Ctrl+V, Ctrl+Z, Alt+Tab-style shortcuts, ...) can be sent
    // as real key events instead of going through Telex composition.
    private fun keyEventCodeFor(c: Char): Int? = when (c) {
        in 'a'..'z' -> KeyEvent.KEYCODE_A + (c - 'a')
        in '0'..'9' -> KeyEvent.KEYCODE_0 + (c - '0')
        else -> null
    }

    private fun currentMetaState(): Int {
        var meta = 0
        if (ctrlOn) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (altOn) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        return meta
    }

    private fun sendKeyCodeWithModifiers(keyCode: Int) {
        val ic = currentInputConnection ?: return
        val meta = currentMetaState()
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    private fun updateComposing(newComposed: String) {
        val ic = currentInputConnection ?: return
        if (composedLength > 0) {
            ic.deleteSurroundingText(composedLength, 0)
        }
        ic.commitText(newComposed, 1)
        composedLength = newComposed.length
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                if (rawBuffer.isNotEmpty()) {
                    rawBuffer.deleteCharAt(rawBuffer.length - 1)
                    if (rawBuffer.isEmpty()) {
                        updateComposing("")
                        resetWord()
                    } else {
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    }
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
                clearModifiers()
            }

            KEYCODE_SHIFT -> {
                setShift(!capsOn)
            }

            Keyboard.KEYCODE_MODE_CHANGE -> {
                keyboardView.keyboard =
                    if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
                // Symbols keyboard has no Shift key; resync the qwerty
                // Shift key's highlight for whenever we switch back to it.
                setModifierKeyVisual(KEYCODE_SHIFT, capsOn)
                clearModifiers()
            }

            KEYCODE_CTRL -> {
                ctrlOn = !ctrlOn
                setModifierKeyVisual(KEYCODE_CTRL, ctrlOn)
            }

            KEYCODE_ALT -> {
                altOn = !altOn
                setModifierKeyVisual(KEYCODE_ALT, altOn)
            }

            -4 -> { // Enter / Done
                resetWord()
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_ENTER)
                    clearModifiers()
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
            }

            32 -> { // space = word boundary
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_SPACE)
                    clearModifiers()
                } else {
                    resetWord()
                    ic.commitText(" ", 1)
                }
            }

            else -> {
                var c = primaryCode.toChar()
                c = if (capsOn) c.uppercaseChar() else c.lowercaseChar()

                if (ctrlOn || altOn) {
                    // Ctrl/Alt + letter or digit = shortcut, not Telex text.
                    val keyCode = keyEventCodeFor(c.lowercaseChar())
                    if (keyCode != null) {
                        sendKeyCodeWithModifiers(keyCode)
                    }
                    resetWord()
                    clearModifiers()
                } else if (c.isLetter()) {
                    rawBuffer.append(c)
                    updateComposing(TelexEngine.transform(rawBuffer.toString()))
                } else {
                    // punctuation etc. = word boundary
                    resetWord()
                    ic.commitText(c.toString(), 1)
                }

                if (capsOn) {
                    setShift(false)
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
