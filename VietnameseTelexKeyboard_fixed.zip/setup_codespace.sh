#!/usr/bin/env bash
# Chạy trong terminal của GitHub Codespaces (không cần máy tính).
# Cách dùng: cd VietnameseTelexKeyboard && bash setup_codespace.sh
set -e

echo "== 1/4 Cài JDK 17 =="
sudo apt-get update -y
sudo apt-get install -y openjdk-17-jdk unzip wget
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

echo "== 2/4 Tải Android SDK command-line tools =="
mkdir -p "$HOME/android-sdk/cmdline-tools"
cd "$HOME/android-sdk/cmdline-tools"
if [ ! -d latest ]; then
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O tools.zip
  unzip -q tools.zip
  mv cmdline-tools latest
  rm tools.zip
fi
export ANDROID_HOME="$HOME/android-sdk"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

echo "== 3/4 Cài SDK platform + build-tools (chấp nhận license tự động) =="
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo "== 4/4 Tải Gradle 8.5 và build APK =="
if [ ! -d "$HOME/gradle-8.5" ]; then
  wget -q https://services.gradle.org/distributions/gradle-8.5-bin.zip -O "$HOME/gradle.zip"
  unzip -q "$HOME/gradle.zip" -d "$HOME"
  rm "$HOME/gradle.zip"
fi
export PATH="$PATH:$HOME/gradle-8.5/bin"

cd "$(dirname "$0")"
gradle assembleDebug

echo ""
echo "======================================"
echo "XONG! File APK nằm ở đây:"
find . -name "app-debug.apk"
echo "Bấm chuột phải file đó trong Explorer bên trái > Download để tải về điện thoại."
echo "======================================"
