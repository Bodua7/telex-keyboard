package com.example.telexkeyboard

import android.content.ClipboardManager
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import kotlin.math.hypot
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ListView
import android.widget.TextView

class TelexIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    // Raw Telex keystrokes typed since the last word boundary (space,
    // punctuation, enter). Re-transformed into Vietnamese on every keystroke.
    private val rawBuffer = StringBuilder()

    // Length (in chars) of the Vietnamese text currently held in the editor's
    // composing region for rawBuffer. The editor owns replacement of this
    // region; do not manually delete it before each update.
    private var composedLength = 0

    private var capsOn = false

    // Double-tapping Shift within DOUBLE_TAP_MS turns on a persistent Caps
    // Lock instead of the normal one-shot capitalize-next-letter behavior.
    // Tapping Shift again while Caps Lock is on turns it back off.
    private var capsLock = false
    private var lastShiftTapTime = 0L

    companion object {
        const val KEYCODE_SHIFT = -12
        const val KEYCODE_CTRL = -10
        const val KEYCODE_ALT = -11
        const val KEYCODE_LANG_TOGGLE = -20
        const val DOUBLE_TAP_MS = 400L

        // Số phím chữ cái khác nhau tối thiểu / khoảng cách di chuyển tối
        // thiểu để một cú chạm+kéo được coi là gõ vuốt thay vì chỉ chạm 1
        // phím bình thường (ngón tay hơi run khi nhấn cũng tạo chuyển
        // động nhỏ, không nên tính là vuốt).
        const val MIN_GLIDE_KEYS = 3
        const val MIN_GLIDE_DISTANCE_KEY_WIDTHS = 1.5f
    }

    // Ctrl / Alt behave like one-shot modifiers (same idea as Shift above):
    // tap to arm, the next key is sent as a real KeyEvent combo (e.g. Ctrl+C),
    // then the modifier auto-clears.
    private var ctrlOn = false
    private var altOn = false

    // Vietnamese Telex mode is on by default. Every letter key routes
    // through TelexEngine.transform(), which means ordinary English text
    // gets mangled — s/f/r/x/j/w/d and doubled a/e/o are all Telex
    // triggers and appear constantly in English words (e.g. "fox" ->
    // "fõ", "over" -> "ỏve"). The VN/EN key lets the user turn Telex off
    // entirely to type plain English, and back on for Vietnamese.
    private var vietnameseOn = true

    // Last selection reported by the editor, used to detect edits we did
    // NOT cause ourselves (paste, tapping to move the cursor, selecting
    // text, autocorrect from the host app, etc.) while a Telex word is
    // still in progress (composedLength > 0). Without this check, typing
    // the next letter after one of those external changes would call
    // deleteSurroundingText(composedLength, 0) against the NEW cursor
    // position and delete unrelated text the user just pasted/selected.
    private var lastKnownSelStart = -1
    private var lastKnownSelEnd = -1

    // Toolbar + panel-switching (emoji / clipboard), added alongside the
    // existing QWERTY/Symbols KeyboardView. All three panels live inside
    // panelContainer and are swapped via visibility, so the toolbar row
    // above them is always reachable no matter which one is showing.
    private lateinit var panelContainer: FrameLayout
    private lateinit var emojiPanel: View
    private lateinit var clipboardPanel: View
    private lateinit var emojiGrid: GridLayout
    private lateinit var clipboardListView: ListView
    private var emojiGridBuilt = false

    // Android has no public API to read the SYSTEM clipboard's own
    // history — only the current clip. So we track our own session
    // history by listening for clipboard changes for as long as this IME
    // process is alive (cleared on process death, same as most clipboard
    // managers' "recent" list would be for an app that isn't itself the
    // clipboard owner).
    // Gõ vuốt liên tục (glide typing): trong khi ngón tay còn chạm màn
    // hình, ghi lại thứ tự CÁC PHÍM CHỮ CÁI KHÁC NHAU đã đi qua (không lặp
    // ký tự liền kề, vd lướt qua c-h-a-o -> "chao"). Nếu khi nhấc tay ra
    // đường đi đủ dài & đủ nhiều phím, coi đây là một cử chỉ vuốt-gõ thay
    // vì một lần chạm phím bình thường, và chèn thẳng từ khớp nhất từ
    // GlideTypingEngine thay vì để KeyboardView gõ ký tự đơn dưới ngón tay
    // lúc thả ra.
    private val glidePath = StringBuilder()
    private var glideLastKeyChar: Char? = null
    private var glideTotalDistance = 0f
    private var glideLastX = 0f
    private var glideLastY = 0f

    private val clipboardHistory = mutableListOf<String>()
    private var clipboardManager: ClipboardManager? = null
    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager?.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString()
            if (!text.isNullOrBlank()) {
                clipboardHistory.remove(text)
                clipboardHistory.add(0, text)
                while (clipboardHistory.size > 15) clipboardHistory.removeAt(clipboardHistory.size - 1)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        clipboardManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipboardListener)
        GlideTypingEngine.load(this)
    }

    override fun onDestroy() {
        clipboardManager?.removePrimaryClipChangedListener(clipboardListener)
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.ime_container, null)

        keyboardView = root.findViewById(R.id.keyboard_view)
        panelContainer = root.findViewById(R.id.panel_container)
        emojiPanel = root.findViewById(R.id.emoji_panel)
        clipboardPanel = root.findViewById(R.id.clipboard_panel)
        emojiGrid = root.findViewById(R.id.emoji_grid)
        clipboardListView = root.findViewById(R.id.clipboard_list)

        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = true
        updateLangKeyVisual()
        // Luôn trả về false ở đây trừ lúc cần "nuốt" sự kiện ACTION_UP kết
        // thúc một cử chỉ vuốt-gõ thật sự -- nhờ vậy việc gõ từng phím
        // bình thường của KeyboardView không bị ảnh hưởng chút nào, ta chỉ
        // quan sát song song rồi can thiệp đúng lúc cần.
        keyboardView.setOnTouchListener { _, event -> handleGlideTouch(event) }

        root.findViewById<View>(R.id.btn_emoji).setOnClickListener {
            if (emojiPanel.visibility == View.VISIBLE) showKeyboardPanel() else showEmojiPanel()
        }
        root.findViewById<View>(R.id.btn_clipboard).setOnClickListener {
            if (clipboardPanel.visibility == View.VISIBLE) showKeyboardPanel() else showClipboardPanel()
        }
        root.findViewById<View>(R.id.btn_settings).setOnClickListener {
            val intent = Intent(this, SetupActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        root.findViewById<View>(R.id.emoji_back).setOnClickListener { showKeyboardPanel() }
        root.findViewById<View>(R.id.emoji_delete).setOnClickListener {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
        root.findViewById<View>(R.id.clipboard_back).setOnClickListener { showKeyboardPanel() }

        return root
    }

    private fun showKeyboardPanel() {
        keyboardView.visibility = View.VISIBLE
        emojiPanel.visibility = View.GONE
        clipboardPanel.visibility = View.GONE
    }

    private fun showEmojiPanel() {
        if (!emojiGridBuilt) buildEmojiGrid()
        keyboardView.visibility = View.GONE
        clipboardPanel.visibility = View.GONE
        emojiPanel.visibility = View.VISIBLE
    }

    private fun showClipboardPanel() {
        refreshClipboardList()
        keyboardView.visibility = View.GONE
        emojiPanel.visibility = View.GONE
        clipboardPanel.visibility = View.VISIBLE
    }

    // A flat, single-page grid of common emoji — no category tabs, kept
    // simple. Built once lazily on first open, not on every keystroke.
    private fun buildEmojiGrid() {
        val emojis = listOf(
            "😀","😁","😂","🤣","😊","😍","😘","😜","🤔","😎",
            "😢","😭","😡","😱","🥳","😴","🤢","🤗","😇","🙄",
            "👍","👎","👏","🙏","💪","🤝","✌️","🤞","👌","🙌",
            "❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","💯",
            "🔥","⭐","✨","🎉","🎂","🎁","🎈","🏆","⚡","☀️",
            "🌙","☁️","🌧️","❄️","🌈","🍀","🌸","🌹","🍕","🍔",
            "🍟","🍜","🍚","🍦","☕","🍺","🍎","🍌","🍉","🥭",
            "🐶","🐱","🐼","🐰","🐣","🦋","🐟","🐢","🚗","✈️",
            "🚀","⏰","📱","💻","📷","🎵","🎮","📚","💰","🎓",
            "🏠","🏢","🌍","💡","🔑","🔒","✅","❌","❓","❗"
        )
        val density = resources.displayMetrics.density
        val cellSize = (44 * density).toInt()
        for (e in emojis) {
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 22f
            tv.gravity = android.view.Gravity.CENTER
            val params = GridLayout.LayoutParams()
            params.width = cellSize
            params.height = cellSize
            tv.layoutParams = params
            tv.setOnClickListener { currentInputConnection?.commitText(e, 1) }
            emojiGrid.addView(tv)
        }
        emojiGridBuilt = true
    }

    private fun refreshClipboardList() {
        val items = if (clipboardHistory.isEmpty())
            listOf(getString(R.string.clipboard_empty)) else clipboardHistory
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        clipboardListView.adapter = adapter
        clipboardListView.setOnItemClickListener { _, _, position, _ ->
            if (clipboardHistory.isNotEmpty()) {
                currentInputConnection?.commitText(clipboardHistory[position], 1)
            }
        }
    }

    private fun loadKeyboards() {
        val prefs = getSharedPreferences("telex_prefs", MODE_PRIVATE)
        val size = prefs.getInt("keyboard_size", 1) // 0=nhỏ, 1=vừa, 2=lớn
        val qwertyRes = when (size) {
            0 -> R.xml.keyboard_qwerty_small
            2 -> R.xml.keyboard_qwerty_large
            else -> R.xml.keyboard_qwerty
        }
        val symbolsRes = when (size) {
            0 -> R.xml.keyboard_symbols_small
            2 -> R.xml.keyboard_symbols_large
            else -> R.xml.keyboard_symbols
        }
        qwertyKeyboard = Keyboard(this, qwertyRes)
        symbolsKeyboard = Keyboard(this, symbolsRes)
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        clearModifiers()
        resetShiftState()
        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        updateLangKeyVisual()
        if (::panelContainer.isInitialized) showKeyboardPanel()
        // Fresh input session: we don't know the editor's cursor position
        // yet (that arrives via the next onUpdateSelection callback), so
        // clear tracking rather than compare against stale values from a
        // previous field.
        lastKnownSelStart = -1
        lastKnownSelEnd = -1
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetWord()
        clearModifiers()
        resetShiftState()
    }

    private fun resetWord() {
        rawBuffer.setLength(0)
        composedLength = 0
    }

    // Called by the framework whenever the editor's selection/cursor
    // changes for ANY reason — our own edits, but also paste, tapping to
    // move the cursor, long-press selection, or the host app editing text
    // itself. If we're mid-word (composedLength > 0) and the change didn't
    // start from where we last left the cursor, it wasn't caused by us —
    // discard the stale Telex buffer so the next keystroke doesn't delete
    // the wrong text. We only ever touch our own tracking state here, never
    // the editor's text.
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)

        if (composedLength > 0 && lastKnownSelStart >= 0) {
            val expected = oldSelStart == lastKnownSelStart && oldSelEnd == lastKnownSelEnd
            val stillCollapsed = newSelStart == newSelEnd
            if (!expected || !stillCollapsed) {
                // External change (paste / cursor tap / selection / host
                // edit) landed while a Telex word was in progress. Drop the
                // buffer without issuing any delete — the text on screen is
                // left exactly as the external change made it.
                resetWord()
            }
        }
        lastKnownSelStart = newSelStart
        lastKnownSelEnd = newSelEnd
    }

    // Ctrl/Alt only. Cleared on backspace, Enter/Space-with-modifier, and
    // switching keyboards — a pending Ctrl/Alt combo shouldn't linger past
    // any of those. Deliberately does NOT touch Shift/Caps Lock: those
    // should survive a backspace or a QWERTY<->Symbols switch, and are only
    // reset by resetShiftState() at the start/end of an input session.
    private fun clearModifiers() {
        ctrlOn = false
        altOn = false
        setModifierKeyVisual(KEYCODE_CTRL, false)
        setModifierKeyVisual(KEYCODE_ALT, false)
    }

    private fun resetShiftState() {
        capsLock = false
        lastShiftTapTime = 0L
        setShift(false)
    }

    // Shift is normally a one-shot modifier: tap to arm, capitalizes exactly
    // the next letter, then auto-clears. Double-tapping it within
    // DOUBLE_TAP_MS instead turns on a persistent Caps Lock (tap once more
    // to release it) — see the KEYCODE_SHIFT branch in onKey(). Fully
    // self-managed (state + visual) instead of relying on the framework's
    // built-in KEYCODE_SHIFT handling, which could get out of sync with our
    // own state and garble typing.
    private fun setShift(on: Boolean) {
        capsOn = on
        setModifierKeyVisual(KEYCODE_SHIFT, on)
    }

    // Highlights/un-highlights the Ctrl/Alt/Shift key(s) matching `code` —
    // checked against BOTH keyboards (not just the one currently shown),
    // since Ctrl/Alt exist on both the QWERTY and Symbols layouts. Without
    // this, toggling Ctrl while on the Symbols keyboard would arm it
    // correctly internally but never actually light up the key.
    private fun setModifierKeyVisual(code: Int, on: Boolean) {
        listOf(
            if (::qwertyKeyboard.isInitialized) qwertyKeyboard else null,
            if (::symbolsKeyboard.isInitialized) symbolsKeyboard else null
        ).forEach { kb ->
            kb?.keys
                ?.filter { it.codes.isNotEmpty() && it.codes[0] == code }
                ?.forEach { it.on = on }
        }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    // Updates the VN/EN key's label (and lights it up while in EN mode) on
    // both keyboards. Needs to be re-applied after every loadKeyboards()
    // call, since that recreates the Keyboard objects from the XML (which
    // always start with the default "VN" label).
    private fun updateLangKeyVisual() {
        val label = if (vietnameseOn) "VN" else "EN"
        listOf(
            if (::qwertyKeyboard.isInitialized) qwertyKeyboard else null,
            if (::symbolsKeyboard.isInitialized) symbolsKeyboard else null
        ).forEach { kb ->
            kb?.keys
                ?.filter { it.codes.isNotEmpty() && it.codes[0] == KEYCODE_LANG_TOGGLE }
                ?.forEach {
                    it.label = label
                    it.on = !vietnameseOn
                }
        }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    // Maps a letter/digit to its Android KeyEvent code so Ctrl/Alt combos
    // (Ctrl+C, Ctrl+V, Ctrl+Z, Alt+Tab-style shortcuts, ...) can be sent
    // as real key events instead of going through Telex composition.
    private fun keyEventCodeFor(c: Char): Int? = when (c) {
        in 'a'..'z' -> KeyEvent.KEYCODE_A + (c - 'a')
        in '0'..'9' -> KeyEvent.KEYCODE_0 + (c - '0')
        else -> null
    }

    private fun currentMetaState(): Int {
        var meta = 0
        if (ctrlOn) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (altOn) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        return meta
    }

    private fun sendKeyCodeWithModifiers(keyCode: Int) {
        val ic = currentInputConnection ?: return
        val meta = currentMetaState()
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    private fun updateComposing(newComposed: String) {
        val ic = currentInputConnection ?: return
        // Telex needs to replace the current word repeatedly as each key is
        // typed. Using commitText here made every intermediate result a
        // separate committed edit. Android could then report the selection
        // change before the next key arrived, causing onUpdateSelection() to
        // discard rawBuffer. The next letter was consequently committed
        // literally, which made the keyboard appear to output raw strings
        // such as "tienges" instead of converting them.
        //
        // setComposingText is the IME contract for exactly this operation:
        // replace the existing composing region in place and keep it active
        // until the word boundary.
        ic.setComposingText(newComposed, 1)
        composedLength = newComposed.length
    }

    private fun finishCurrentWord() {
        val ic = currentInputConnection
        resetWord()
        ic?.finishComposingText()
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                if (rawBuffer.isNotEmpty()) {
                    rawBuffer.deleteCharAt(rawBuffer.length - 1)
                    if (rawBuffer.isEmpty()) {
                        updateComposing("")
                        resetWord()
                    } else {
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    }
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
                clearModifiers()
            }

            KEYCODE_SHIFT -> {
                val now = System.currentTimeMillis()
                when {
                    capsLock -> {
                        // Any tap while Caps Lock is on releases it.
                        capsLock = false
                        setShift(false)
                    }
                    now - lastShiftTapTime < DOUBLE_TAP_MS -> {
                        // Double-tap -> Caps Lock on (stays on across words
                        // until Shift is tapped again).
                        capsLock = true
                        setShift(true)
                    }
                    else -> {
                        // Single tap -> one-shot arm/disarm for just the
                        // next letter.
                        setShift(!capsOn)
                    }
                }
                lastShiftTapTime = now
            }

            Keyboard.KEYCODE_MODE_CHANGE -> {
                keyboardView.keyboard =
                    if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
                // Symbols keyboard has no Shift key; resync the qwerty
                // Shift key's highlight for whenever we switch back to it.
                setModifierKeyVisual(KEYCODE_SHIFT, capsOn)
                clearModifiers()
            }

            KEYCODE_CTRL -> {
                ctrlOn = !ctrlOn
                setModifierKeyVisual(KEYCODE_CTRL, ctrlOn)
            }

            KEYCODE_ALT -> {
                altOn = !altOn
                setModifierKeyVisual(KEYCODE_ALT, altOn)
            }

            KEYCODE_LANG_TOGGLE -> {
                finishCurrentWord()
                vietnameseOn = !vietnameseOn
                updateLangKeyVisual()
            }

            -4 -> { // Enter / Done
                finishCurrentWord()
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_ENTER)
                    clearModifiers()
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
            }

            32 -> { // space = word boundary
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_SPACE)
                    clearModifiers()
                } else {
                    finishCurrentWord()
                    ic.commitText(" ", 1)
                }
            }

            else -> {
                var c = primaryCode.toChar()
                c = if (capsOn) c.uppercaseChar() else c.lowercaseChar()

                if (ctrlOn || altOn) {
                    // Ctrl/Alt + letter or digit = shortcut, not Telex text.
                    val keyCode = keyEventCodeFor(c.lowercaseChar())
                    if (keyCode != null) {
                        sendKeyCodeWithModifiers(keyCode)
                    } else {
                        // No shortcut mapping for this key (e.g. Ctrl + a
                        // symbol like "/") — fall back to committing the
                        // character literally instead of silently eating it.
                        ic.commitText(c.toString(), 1)
                    }
                    resetWord()
                    clearModifiers()
                } else if (c.isLetter()) {
                    if (vietnameseOn) {
                        rawBuffer.append(c)
                        val raw = rawBuffer.toString()
                        // Keep standard Telex as the first choice. If the
                        // user placed a tone/modifier key in a phone-friendly
                        // but non-standard position, use only a confident
                        // dictionary match as a tolerant fallback.
                        val converted = TelexEngine.transform(raw)
                        val tolerant = GlideTypingEngine.tolerantTelexMatch(raw)
                        updateComposing(tolerant ?: converted)
                    } else {
                        // EN mode: type the letter literally, no Telex
                        // transformation, no composing buffer to manage.
                        ic.commitText(c.toString(), 1)
                    }
                } else {
                    // punctuation etc. = word boundary
                    finishCurrentWord()
                    ic.commitText(c.toString(), 1)
                }

                // Caps Lock stays on across letters/words; the one-shot
                // arm (from a single Shift tap) clears after this one letter.
                if (capsOn && !capsLock) {
                    setShift(false)
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}

    // Swipe gestures across the keyboard surface (detected by KeyboardView
    // itself; we only need to react here). A Telex word in progress is
    // reset first for left/right since moving the cursor invalidates the
    // raw buffer -- onUpdateSelection() would catch this too, but doing it
    // up front keeps behavior obvious and avoids a stray delete race.
    override fun swipeLeft() = moveCursor(KeyEvent.KEYCODE_DPAD_LEFT)
    override fun swipeRight() = moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT)

    // Vuốt xuống: ẩn bàn phím, giống thao tác quen thuộc trên hầu hết
    // bàn phím ảo khác.
    override fun swipeDown() {
        resetWord()
        requestHideSelf(0)
    }

    // Vuốt lên: chuyển nhanh QWERTY <-> Ký hiệu (?123), tương đương chạm
    // nút "?123"/"ABC" nhưng không cần rời tay khỏi vùng gõ.
    override fun swipeUp() {
        if (!::keyboardView.isInitialized) return
        keyboardView.keyboard =
            if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
        setModifierKeyVisual(KEYCODE_SHIFT, capsOn)
        clearModifiers()
    }

    private fun moveCursor(keyCode: Int) {
        finishCurrentWord()
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    private fun handleGlideTouch(event: MotionEvent): Boolean {
        // Gõ vuốt chỉ áp dụng cho lớp QWERTY (so khớp từ điển tiếng Việt);
        // trên lớp Ký hiệu, mọi chuyển động chỉ nên gõ ký tự bình thường.
        if (!::qwertyKeyboard.isInitialized || keyboardView.keyboard !== qwertyKeyboard) {
            return false
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                glidePath.setLength(0)
                glideLastKeyChar = null
                glideTotalDistance = 0f
                glideLastX = event.x
                glideLastY = event.y
                letterKeyAt(event.x, event.y)?.let {
                    glidePath.append(it)
                    glideLastKeyChar = it
                }
            }

            MotionEvent.ACTION_MOVE -> {
                glideTotalDistance += hypot(event.x - glideLastX, event.y - glideLastY)
                glideLastX = event.x
                glideLastY = event.y
                val c = letterKeyAt(event.x, event.y)
                if (c != null && c != glideLastKeyChar) {
                    glidePath.append(c)
                    glideLastKeyChar = c
                }
            }

            MotionEvent.ACTION_UP -> {
                val keyWidth = qwertyKeyboard.keys
                    .firstOrNull { it.codes.isNotEmpty() && it.codes[0] in 97..122 }
                    ?.width ?: 0
                val isGlide = glidePath.length >= MIN_GLIDE_KEYS &&
                    glideTotalDistance > keyWidth * MIN_GLIDE_DISTANCE_KEY_WIDTHS
                if (isGlide) {
                    val match = GlideTypingEngine.bestMatch(glidePath.toString())
                    // Nuốt sự kiện thả tay này để KeyboardView không gõ
                    // thêm 1 ký tự đơn dưới ngón tay lúc thả ra; gửi
                    // ACTION_CANCEL để nó tự dọn trạng thái phím đang giữ.
                    val cancelEvent = MotionEvent.obtain(event)
                    cancelEvent.action = MotionEvent.ACTION_CANCEL
                    keyboardView.onTouchEvent(cancelEvent)
                    cancelEvent.recycle()
                    if (match != null) commitGlideWord(match)
                    glidePath.setLength(0)
                    glideLastKeyChar = null
                    return true
                }
                glidePath.setLength(0)
                glideLastKeyChar = null
            }

            MotionEvent.ACTION_CANCEL -> {
                glidePath.setLength(0)
                glideLastKeyChar = null
            }
        }
        return false
    }

    private fun letterKeyAt(x: Float, y: Float): Char? {
        val key = qwertyKeyboard.keys.firstOrNull { it.isInside(x.toInt(), y.toInt()) } ?: return null
        val code = key.codes.firstOrNull() ?: return null
        return if (code in 97..122) code.toChar() else null
    }

    private fun commitGlideWord(word: String) {
        resetWord()
        val ic = currentInputConnection ?: return
        val display = if (capsOn) word.replaceFirstChar { it.uppercaseChar() } else word
        ic.commitText("$display ", 1)
        if (capsOn && !capsLock) setShift(false)
    }
}
