package com.example.telexkeyboard

import android.content.Context
import java.text.Normalizer
import kotlin.math.abs

// Từ điển gõ vuốt liên tục (glide typing): nạp danh sách từ tiếng Việt từ
// assets/words_vi.txt, rồi so khớp đường vuốt (chuỗi các phím chữ cái mà
// ngón tay đã đi qua, không dấu, không lặp ký tự liền kề) với "hình dạng"
// gần nhất trong từ điển để suy ra từ có dấu đúng.
//
// Đây là bản khởi đầu đơn giản (khớp bằng khoảng cách Levenshtein trên
// chuỗi đã bỏ dấu), không phải mô hình dự đoán ngôn ngữ đầy đủ như
// Gboard/SwiftKey — không học từ thói quen gõ, không xét ngữ cảnh câu.
// Muốn thêm từ: chỉ cần thêm dòng mới vào assets/words_vi.txt, không cần
// sửa code.
object GlideTypingEngine {

    private var words: List<String> = emptyList()
    private var shapeKeys: List<String> = emptyList()
    private var telexKeys: List<String> = emptyList()
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        val list = mutableListOf<String>()
        try {
            context.assets.open("words_vi.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { raw ->
                    val w = raw.trim()
                    if (w.isNotEmpty()) list.add(w)
                }
            }
        } catch (e: Exception) {
            // Thiếu file từ điển: gõ vuốt sẽ không tìm được từ khớp nào,
            // nhưng bàn phím vẫn hoạt động bình thường ở chế độ gõ Telex.
        }
        words = list
        shapeKeys = list.map { shapeKey(it) }
        telexKeys = list.map { telexKey(it) }
        loaded = true
    }

    // Bỏ dấu, viết thường, gộp các chữ cái liền kề giống nhau thành một --
    // cùng "hình dạng" mà bộ theo dõi đường vuốt tạo ra từ thao tác ngón
    // tay, để so khớp công bằng giữa từ điển và đường đi thực tế.
    fun shapeKey(word: String): String {
        val stripped = stripDiacritics(word.lowercase())
        val sb = StringBuilder()
        for (c in stripped) {
            if (sb.isEmpty() || sb.last() != c) sb.append(c)
        }
        return sb.toString()
    }

    /**
     * Returns the canonical Telex spelling of an already-accented Vietnamese
     * word. Tone keys are placed at the end, which is the form people usually
     * intend even when a phone keyboard makes them type the modifier letters
     * in a different position:
     *
     *   tiếng -> tieengs
     *   nhiều -> nhieeuf
     *   kiểu  -> kieeur
     */
    fun telexKey(word: String): String {
        val letters = StringBuilder()
        var tone: Char? = null

        for (c in word) {
            if (c == 'đ' || c == 'Đ') {
                letters.append(if (c.isUpperCase()) "DD" else "dd")
                continue
            }

            val decomposed = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
            val base = decomposed.firstOrNull() ?: continue
            val isUpper = c.isUpperCase()
            val lowerBase = base.lowercaseChar()
            if (lowerBase !in setOf('a', 'e', 'i', 'o', 'u', 'y')) {
                letters.append(c)
                continue
            }

            var modifier: String? = null
            for (mark in decomposed.drop(1)) {
                when (mark.code) {
                    0x0306, 0x031B -> modifier = "w" // breve / horn
                    0x0302 -> modifier = lowerBase.toString() // circumflex
                    0x0301 -> tone = 's' // acute
                    0x0300 -> tone = 'f' // grave
                    0x0309 -> tone = 'r' // hook above
                    0x0303 -> tone = 'x' // tilde
                    0x0323 -> tone = 'j' // dot below
                }
            }

            val outputBase = if (isUpper) lowerBase.uppercaseChar() else lowerBase
            letters.append(outputBase)
            when (modifier) {
                "w" -> letters.append(if (isUpper) 'W' else 'w')
                lowerBase.toString() -> letters.append(outputBase)
            }
        }

        if (tone != null) letters.append(tone)
        return letters.toString()
    }

    /**
     * Finds a high-confidence dictionary word for a Telex string whose
     * modifier keys were typed in a non-standard position. This is deliberately
     * conservative: it only runs when the input ends in a tone key and allows
     * at most two edits. That prevents ordinary English words from becoming
     * Vietnamese suggestions while still accepting inputs such as:
     *
     *   lamws   -> lắm
     *   tienges -> tiếng
     *   vietej  -> việt
     *   kieuer  -> kiểu
     */
    fun tolerantTelexMatch(path: String): String? {
        if (!loaded || path.length < 4 || path.last().lowercaseChar() !in "sfrxj") {
            return null
        }

        var bestIdx = -1
        var bestDistance = Int.MAX_VALUE

        for (i in telexKeys.indices) {
            val key = telexKeys[i]
            if (key.isEmpty() || key.first().lowercaseChar() != path.first().lowercaseChar()) {
                continue
            }
            // The final key carries the user's intended tone. Requiring the
            // dictionary candidate to carry the same tone removes ambiguous
            // matches such as "vietej" => việc/viện/việt before comparing
            // their spellings.
            if (key.last().lowercaseChar() != path.last().lowercaseChar()) {
                continue
            }
            val distance = damerauLevenshtein(path.lowercase(), key.lowercase())
            if (distance < bestDistance) {
                bestDistance = distance
                bestIdx = i
            }
        }

        // Two edits is enough for the misplaced/repeated modifiers in the
        // reference examples. The matching tone and first letter above keep
        // this fallback conservative enough not to rewrite ordinary English.
        val maxDistance = if (path.length <= 5) 1 else 2
        return if (bestIdx >= 0 && bestDistance <= maxDistance) words[bestIdx] else null
    }

    private fun stripDiacritics(s: String): String {
        val normalized = Normalizer.normalize(s, Normalizer.Form.NFD)
        val noMarks = normalized.replace(Regex("\\p{Mn}+"), "")
        return noMarks.replace('đ', 'd').replace('Đ', 'D')
    }

    // Trả về từ có dấu khớp nhất với đường vuốt `path`, hoặc null nếu
    // không có ứng viên đủ gần (khác chữ đầu, hoặc quá lệch hình dạng) --
    // thà không gợi ý còn hơn chèn nhầm một từ ngẫu nhiên.
    fun bestMatch(path: String): String? {
        if (path.length < 2 || words.isEmpty()) return null
        var bestIdx = -1
        var bestScore = Int.MAX_VALUE
        for (i in words.indices) {
            val key = shapeKeys[i]
            if (key.isEmpty() || key[0] != path[0]) continue
            val dist = levenshtein(path, key)
            val score = dist * 2 + abs(key.length - path.length)
            if (score < bestScore) {
                bestScore = score
                bestIdx = i
            }
        }
        if (bestIdx < 0) return null
        val maxAllowed = (path.length / 2) + 2
        return if (bestScore / 2 <= maxAllowed) words[bestIdx] else null
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[a.length][b.length]
    }

    // Damerau-Levenshtein treats an adjacent transposition as one edit. This
    // is the common failure shape in the reference input:
    // "lamws" is "lawms" with the w/m pair swapped.
    private fun damerauLevenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j

        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                )
                if (
                    i > 1 &&
                    j > 1 &&
                    a[i - 1] == b[j - 2] &&
                    a[i - 2] == b[j - 1]
                ) {
                    dp[i][j] = minOf(dp[i][j], dp[i - 2][j - 2] + 1)
                }
            }
        }
        return dp[a.length][b.length]
    }
}
