# Chính sách quyền riêng tư — Bàn Phím Telex

Cập nhật lần cuối: 09/08/2026

## Tóm tắt

Bàn Phím Telex hoạt động **hoàn toàn ngoại tuyến**. Ứng dụng không xin
quyền truy cập Internet (không có quyền `INTERNET` trong
AndroidManifest.xml), nên về mặt kỹ thuật ứng dụng **không thể** gửi bất
kỳ dữ liệu nào — bao gồm nội dung bạn gõ, clipboard, hay bất cứ thứ gì
khác — ra khỏi thiết bị của bạn. Không có máy chủ, không có analytics,
không có quảng cáo, không có bên thứ ba nào nhận được dữ liệu từ ứng
dụng này.

## Dữ liệu ứng dụng xử lý, và xử lý ở đâu

Tất cả đều nằm trên thiết bị của bạn:

- **Nội dung đang gõ (bộ đệm Telex)**: chỉ tồn tại tạm thời trong bộ nhớ
  khi bạn đang gõ một từ, dùng để chuyển ký tự Telex (vd. "aa", "ow")
  thành tiếng Việt có dấu. Không được lưu lại, không được ghi log.
- **Lịch sử clipboard (phiên hiện tại)**: ứng dụng lắng nghe khi bạn sao
  chép văn bản để hiển thị trong bảng clipboard của bàn phím, giúp dán
  lại nhanh. Danh sách này chỉ tồn tại trong bộ nhớ khi ứng dụng bàn
  phím đang chạy và **mất hoàn toàn khi tiến trình bàn phím dừng** (ví
  dụ khi hệ thống giải phóng bộ nhớ, hoặc khởi động lại máy).
- **Mục clipboard đã ghim**: nếu bạn chủ động ghim một mục, nội dung đó
  được lưu cục bộ trên máy (SharedPreferences riêng của ứng dụng) để
  còn đó sau khi khởi động lại, cho tới khi bạn bỏ ghim, xoá, hoặc gỡ
  ứng dụng.
- **Tuỳ chọn cỡ bàn phím**: lựa chọn Nhỏ/Vừa/Lớn bạn chọn trong màn hình
  Cài đặt, lưu cục bộ để nhớ cho lần sau.

Không mục nào trong số trên rời khỏi thiết bị của bạn.

## Quyền ứng dụng xin

- **Rung (VIBRATE)**: dùng cho phản hồi rung khi gõ phím (nếu bạn bật
  tính năng này trên hệ thống). Không liên quan tới dữ liệu cá nhân.

Ứng dụng **không xin** quyền Internet, danh bạ, vị trí, micro, camera,
hay bất kỳ quyền nhạy cảm nào khác.

## Vì sao một bàn phím cần được tin tưởng

Ứng dụng bàn phím về nguyên tắc có khả năng thấy mọi thứ bạn gõ, nên
việc không xin quyền Internet là yếu tố quan trọng nhất ở đây: nó khiến
việc gửi dữ liệu ra ngoài là bất khả thi về mặt kỹ thuật, không chỉ là
một lời hứa trong chính sách này.

## Xoá dữ liệu của bạn

- Bỏ ghim/xoá từng mục clipboard đã ghim ngay trong bảng clipboard của
  bàn phím.
- "Xoá tất cả" trong bảng clipboard xoá lịch sử clipboard chưa ghim của
  phiên hiện tại.
- Gỡ cài đặt ứng dụng sẽ xoá toàn bộ dữ liệu cục bộ nói trên (mục đã
  ghim, tuỳ chọn cỡ bàn phím).

## Trẻ em

Ứng dụng không được thiết kế riêng cho trẻ em và không cố ý thu thập
thông tin từ trẻ em — vì ứng dụng không thu thập hay truyền bất kỳ
thông tin nào ra ngoài thiết bị, không có gì để thu thập từ bất kỳ đối
tượng người dùng nào.

## Thay đổi chính sách này

Nếu chính sách thay đổi (ví dụ nếu một bản cập nhật trong tương lai
thêm tính năng cần Internet), ngày "Cập nhật lần cuối" ở đầu trang sẽ
được cập nhật và mô tả thay đổi sẽ có trong ghi chú phát hành.

## Liên hệ

Có câu hỏi về chính sách này, liên hệ: [điền email liên hệ của bạn ở đây]
