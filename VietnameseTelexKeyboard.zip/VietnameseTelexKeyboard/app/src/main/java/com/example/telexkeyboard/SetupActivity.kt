package com.example.telexkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(48, 96, 48, 48)

        val title = TextView(this)
        title.text = "Bàn Phím Telex"
        title.textSize = 22f

        val desc = TextView(this)
        desc.text = "1. Bấm nút bên dưới để bật \"Bàn Phím Telex\" trong Cài đặt.\n\n" +
            "2. Khi soạn văn bản ở bất kỳ ứng dụng nào, chạm giữ vào biểu " +
            "tượng chuyển bàn phím (hoặc phím dấu cách) để chọn \"Bàn Phím Telex\".\n\n" +
            "3. Gõ theo kiểu Telex quen thuộc: aa=â, aw=ă, ee=ê, oo=ô, ow=ơ, " +
            "uw=ư, dd=đ, và các phím dấu: s=sắc, f=huyền, r=hỏi, x=ngã, j=nặng, z=xóa dấu."
        desc.setPadding(0, 24, 0, 48)

        val enableBtn = Button(this)
        enableBtn.text = "Mở cài đặt bàn phím"
        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(enableBtn)
        setContentView(layout)
    }
}
