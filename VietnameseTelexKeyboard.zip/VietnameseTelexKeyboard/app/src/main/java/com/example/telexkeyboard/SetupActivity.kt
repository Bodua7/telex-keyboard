package com.example.telexkeyboard

import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.inputmethodservice.Keyboard
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var sizeButtons: List<Button>
    private lateinit var customSizeRow: LinearLayout
    private lateinit var customSizeSeekBar: SeekBar
    private lateinit var customSizeValueLabel: TextView
    private lateinit var textSizeSeekBar: SeekBar
    private lateinit var textSizeValueLabel: TextView
    private lateinit var previewKeyboardView: BoldKeyboardView
    private val prefs by lazy { TelexPrefs.of(this) }

    // Khoảng cho phép chọn chiều cao mỗi hàng phím ở chế độ tùy chỉnh.
    // 28dp thấp hơn cả cỡ "Nhỏ" (34dp) một chút, 72dp cao hơn cả cỡ "Lớn"
    // (54dp) khá nhiều — đủ rộng để người dùng thực sự tùy biến thay vì
    // chỉ lặp lại 3 mốc có sẵn.
    private val customSizeMinDp = 28
    private val customSizeMaxDp = 72

    // Khoảng cho phép chọn cỡ chữ. 26sp là giá trị mặc định gốc (khớp
    // android:keyTextSize cũ trong ime_container.xml).
    private val textSizeMinSp = 14
    private val textSizeMaxSp = 34

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(48, 96, 48, 48)

        val title = TextView(this)
        title.text = "Bàn Phím Telex"
        title.textSize = 22f

        statusText = TextView(this)
        statusText.textSize = 15f
        statusText.setPadding(0, 16, 0, 16)

        val desc = TextView(this)
        desc.text = "1. Bấm nút bên dưới để bật \"Bàn Phím Telex\" trong Cài đặt.\n\n" +
            "2. Khi soạn văn bản, chạm giữ biểu tượng chuyển bàn phím để chọn " +
            "\"Bàn Phím Telex\".\n\n" +
            "3. Quy tắc gõ: aa=â, aw=ă, ee=ê, oo=ô, ow=ơ, uw=ư, dd=đ, " +
            "s=sắc, f=huyền, r=hỏi, x=ngã, j=nặng, z=xóa dấu."
        desc.setPadding(0, 24, 0, 32)

        val enableBtn = Button(this)
        enableBtn.text = "Mở cài đặt bàn phím"
        enableBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        val switchBtn = Button(this)
        switchBtn.text = "Chọn bàn phím đang gõ"
        switchBtn.setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        val sizeLabel = TextView(this)
        sizeLabel.text = "\nKích thước bàn phím:"
        sizeLabel.setPadding(0, 48, 0, 16)

        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL

        fun sizeButton(label: String, value: Int): Button {
            val b = Button(this)
            b.text = label
            b.setOnClickListener {
                prefs.edit().putInt(TelexPrefs.KEY_KEYBOARD_SIZE, value).apply()
                refreshSizeSelection()
                refreshPreview()
                Toast.makeText(
                    this,
                    "Đã lưu — xem trước bên dưới. Mở lại bàn phím Telex để áp dụng lúc gõ.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            params.setMargins(8, 0, 8, 0)
            b.layoutParams = params
            b.tag = value
            return b
        }

        val btnSmall = sizeButton("Nhỏ", 0)
        val btnMedium = sizeButton("Vừa", 1)
        val btnLarge = sizeButton("Lớn", 2)
        val btnCustom = sizeButton("Tùy chỉnh", 3)
        sizeButtons = listOf(btnSmall, btnMedium, btnLarge, btnCustom)
        sizeRow.addView(btnSmall)
        sizeRow.addView(btnMedium)
        sizeRow.addView(btnLarge)
        sizeRow.addView(btnCustom)

        // Thanh kéo chọn chiều cao — chỉ hiển thị khi đang chọn "Tùy
        // chỉnh" (refreshSizeSelection() ẩn/hiện). Kéo xong lưu ngay lập
        // tức (giống các nút cỡ khác) chứ không cần nút "Lưu" riêng.
        customSizeRow = LinearLayout(this)
        customSizeRow.orientation = LinearLayout.VERTICAL
        customSizeRow.setPadding(0, 24, 0, 0)

        customSizeValueLabel = TextView(this)
        customSizeValueLabel.textSize = 14f

        customSizeSeekBar = SeekBar(this)
        customSizeSeekBar.max = customSizeMaxDp - customSizeMinDp
        customSizeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val dp = customSizeMinDp + progress
                customSizeValueLabel.text = "Chiều cao mỗi hàng phím: ${dp}dp"
                if (fromUser) {
                    prefs.edit().putInt(TelexPrefs.KEY_KEYBOARD_CUSTOM_HEIGHT_DP, dp).apply()
                    refreshPreview()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                Toast.makeText(
                    this@SetupActivity,
                    "Đã lưu — xem trước bên dưới. Mở lại bàn phím Telex để áp dụng lúc gõ.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        customSizeRow.addView(customSizeValueLabel)
        customSizeRow.addView(customSizeSeekBar)

        // Preview sống động: một BoldKeyboardView độc lập (không phải bàn
        // phím thật đang gõ) phản ánh NGAY cả 2 cài đặt cỡ bàn phím + cỡ
        // chữ mỗi khi người dùng đổi preset hoặc kéo 1 trong 2 thanh trượt.
        // 3 Toast phía trên/dưới đã cập nhật lại để phân biệt rõ: XEM
        // TRƯỚC thấy ngay tại đây, còn ÁP DỤNG lúc gõ thật vẫn cần mở lại
        // bàn phím Telex (IME chạy trong process/InputMethodService riêng,
        // không tự refresh theo Activity này).
        val previewLabel = TextView(this)
        previewLabel.text = "\nXem trước:"
        previewLabel.setPadding(0, 48, 0, 16)

        previewKeyboardView = layoutInflater.inflate(R.layout.keyboard_preview, null) as BoldKeyboardView
        previewKeyboardView.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        // View này chỉ để xem, không nhận gõ thật — không gán
        // setOnKeyboardActionListener (không có input connection nào để
        // gửi phím tới) và không bật isPreviewEnabled (popup phím nổi khi
        // nhấn). Chặn hẳn sự kiện chạm ở đây để người dùng không lỡ tay
        // "gõ vào" một view không làm gì cả, đồng thời tránh chạm vào
        // nhánh code nội bộ của KeyboardView vốn được viết cho trường hợp
        // luôn có listener thật.
        previewKeyboardView.setOnTouchListener { _, _ -> true }

        // Cỡ chữ trên phím — độc lập với kích thước bàn phím ở trên (một
        // bên đổi chiều cao hàng phím, một bên đổi cỡ chữ hiển thị), nên
        // luôn hiển thị (không ẩn theo preset nào) và có thanh kéo riêng.
        val textSizeLabel = TextView(this)
        textSizeLabel.text = "\nCỡ chữ bàn phím:"
        textSizeLabel.setPadding(0, 48, 0, 16)

        textSizeValueLabel = TextView(this)
        textSizeValueLabel.textSize = 14f

        textSizeSeekBar = SeekBar(this)
        textSizeSeekBar.max = textSizeMaxSp - textSizeMinSp
        textSizeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val sp = textSizeMinSp + progress
                textSizeValueLabel.text = "Cỡ chữ: ${sp}sp"
                if (fromUser) {
                    prefs.edit().putInt(TelexPrefs.KEY_KEYBOARD_TEXT_SIZE_SP, sp).apply()
                    refreshPreview()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                Toast.makeText(
                    this@SetupActivity,
                    "Đã lưu — xem trước bên dưới. Mở lại bàn phím Telex để áp dụng lúc gõ.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        val autoFixLabel = TextView(this)
        autoFixLabel.text = "\nTự động sửa:"
        autoFixLabel.setPadding(0, 48, 0, 16)

        // Cả 2 công tắc mặc định BẬT (true) để giữ hành vi hiện tại cho
        // người dùng cũ — chỉ ai gặp phải trường hợp sửa sai mới cần vào
        // đây tắt đi. Dùng chung TelexPrefs (file + tên khoá) với
        // keyboard_size ở trên; TelexIME đọc lại 2 cờ này qua
        // AutoFixPolicy mỗi lần cần dùng.
        fun autoFixSwitch(label: String, prefKey: String): Switch {
            val s = Switch(this)
            s.text = label
            s.isChecked = prefs.getBoolean(prefKey, true)
            s.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
                prefs.edit().putBoolean(prefKey, checked).apply()
            }
            return s
        }

        val englishFixSwitch = autoFixSwitch("Tự nhận từ tiếng Anh", TelexPrefs.KEY_AUTO_FIX_ENGLISH)
        val diacriticFixSwitch = autoFixSwitch("Tự sửa dấu câu tiếng Việt", TelexPrefs.KEY_AUTO_FIX_DIACRITICS)

        // Text-style link rather than a filled Button — it's a low-priority
        // action compared to enabling/switching the keyboard above, and
        // shouldn't visually compete with those for attention.
        val privacyLink = TextView(this)
        privacyLink.text = getString(R.string.privacy_policy_button)
        privacyLink.textSize = 14f
        privacyLink.setTextColor(Color.parseColor("#4A90D9"))
        privacyLink.setPadding(0, 64, 0, 0)
        privacyLink.setOnClickListener {
            startActivity(Intent(this, PrivacyPolicyActivity::class.java))
        }

        layout.addView(title)
        layout.addView(statusText)
        layout.addView(desc)
        layout.addView(enableBtn)
        layout.addView(switchBtn)
        layout.addView(sizeLabel)
        layout.addView(sizeRow)
        layout.addView(customSizeRow)
        layout.addView(previewLabel)
        layout.addView(previewKeyboardView)
        layout.addView(textSizeLabel)
        layout.addView(textSizeValueLabel)
        layout.addView(textSizeSeekBar)
        layout.addView(autoFixLabel)
        layout.addView(englishFixSwitch)
        layout.addView(diacriticFixSwitch)
        layout.addView(privacyLink)
        setContentView(layout)
    }

    // onResume chạy lại mỗi khi quay về từ màn Cài đặt hệ thống hoặc từ
    // trình chọn bàn phím — nhờ vậy trạng thái hiển thị luôn khớp thực tế,
    // không bị "đứng hình" ở giá trị lúc mới mở màn hình.
    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSizeSelection()
        refreshTextSizeSelection()
        refreshPreview()
    }

    private fun refreshStatus() {
        // ComponentName.flattenToShortString() sinh đúng định dạng id mà
        // InputMethodInfo dùng ("pkg/.ClassName"), an toàn hơn tự nối chuỗi.
        val myService = ComponentName(this, TelexIME::class.java).flattenToShortString()

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.id == myService }

        val defaultIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        val isDefault = defaultIme == myService

        statusText.text = when {
            isDefault -> "✓ Đã bật và đang là bàn phím đang dùng"
            enabled -> "✓ Đã bật — chạm giữ biểu tượng bàn phím để chọn dùng"
            else -> "✗ Chưa bật — bấm \"Mở cài đặt bàn phím\" bên dưới"
        }
        statusText.setTextColor(if (isDefault) Color.parseColor("#2E7D32") else if (enabled) Color.parseColor("#F9A825") else Color.parseColor("#C62828"))
    }

    private fun refreshSizeSelection() {
        val current = prefs.getInt(TelexPrefs.KEY_KEYBOARD_SIZE, 1)
        for (b in sizeButtons) {
            val selected = (b.tag as Int) == current
            b.alpha = if (selected) 1f else 0.5f
        }

        val isCustom = current == 3
        customSizeRow.visibility = if (isCustom) LinearLayout.VISIBLE else LinearLayout.GONE
        if (isCustom) {
            val dp = prefs.getInt(TelexPrefs.KEY_KEYBOARD_CUSTOM_HEIGHT_DP, 44)
                .coerceIn(customSizeMinDp, customSizeMaxDp)
            customSizeSeekBar.progress = dp - customSizeMinDp
            customSizeValueLabel.text = "Chiều cao mỗi hàng phím: ${dp}dp"
        }
    }

    private fun refreshTextSizeSelection() {
        val sp = prefs.getInt(TelexPrefs.KEY_KEYBOARD_TEXT_SIZE_SP, 26)
            .coerceIn(textSizeMinSp, textSizeMaxSp)
        textSizeSeekBar.progress = sp - textSizeMinSp
        textSizeValueLabel.text = "Cỡ chữ: ${sp}sp"
    }

    // Dựng lại Keyboard cho previewKeyboardView theo ĐÚNG cài đặt hiện
    // tại (preset + chiều cao tùy chỉnh nếu có + cỡ chữ) — dùng lại
    // KeyboardSizing (cùng object mà TelexIME.loadKeyboards() dùng) nên
    // preview không bao giờ lệch với bàn phím thật. Dựng Keyboard MỚI mỗi
    // lần thay vì chỉnh Keyboard cũ vì Keyboard không có API "reset lại
    // như lúc mới parse XML" — resize lặp nhiều lần trên cùng 1 object sẽ
    // cộng dồn sai số, nên luôn khởi tạo lại từ XML gốc rồi scale 1 lần.
    private fun refreshPreview() {
        val size = prefs.getInt(TelexPrefs.KEY_KEYBOARD_SIZE, 1)
        val kb = Keyboard(this, KeyboardSizing.qwertyRes(size))
        if (size == 3) {
            val dp = prefs.getInt(TelexPrefs.KEY_KEYBOARD_CUSTOM_HEIGHT_DP, 44)
                .coerceIn(customSizeMinDp, customSizeMaxDp)
            val scale = dp.toFloat() / 44f
            KeyboardSizing.scaleKeyboardHeight(kb, scale)
        }
        previewKeyboardView.keyboard = kb

        val sp = prefs.getInt(TelexPrefs.KEY_KEYBOARD_TEXT_SIZE_SP, 26)
            .coerceIn(textSizeMinSp, textSizeMaxSp)
        val px = sp * resources.displayMetrics.scaledDensity
        previewKeyboardView.applyCustomTextSize(px)
    }
}
