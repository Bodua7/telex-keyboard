package com.example.telexkeyboard

/**
 * Converts a raw sequence of Telex keystrokes (e.g. "vieejt" or "chaof")
 * into properly-accented Vietnamese text (e.g. "việt", "chào").
 *
 * The caller is expected to keep a per-word "raw buffer" of every key
 * typed since the last word boundary (space / punctuation / enter) and
 * call transform() again on the whole buffer after every keystroke,
 * replacing whatever was previously composed in the text field. This
 * mirrors how most desktop/mobile Telex engines (Unikey, EVKey, etc.)
 * work internally.
 */
object TelexEngine {

    // index: 0 = no tone, 1 = sắc, 2 = huyền, 3 = hỏi, 4 = ngã, 5 = nặng
    private val toneTable = mapOf(
        'a' to charArrayOf('a', 'á', 'à', 'ả', 'ã', 'ạ'),
        'ă' to charArrayOf('ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ'),
        'â' to charArrayOf('â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ'),
        'e' to charArrayOf('e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ'),
        'ê' to charArrayOf('ê', 'ế', 'ề', 'ể', 'ễ', 'ệ'),
        'i' to charArrayOf('i', 'í', 'ì', 'ỉ', 'ĩ', 'ị'),
        'o' to charArrayOf('o', 'ó', 'ò', 'ỏ', 'õ', 'ọ'),
        'ô' to charArrayOf('ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ'),
        'ơ' to charArrayOf('ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ'),
        'u' to charArrayOf('u', 'ú', 'ù', 'ủ', 'ũ', 'ụ'),
        'ư' to charArrayOf('ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự'),
        'y' to charArrayOf('y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ')
    )

    private val modifiedVowels = setOf('ă', 'â', 'ê', 'ô', 'ơ', 'ư')
    private val plainVowels = setOf('a', 'e', 'i', 'o', 'u', 'y')
    private val vowels = plainVowels + modifiedVowels

    private fun baseOf(c: Char): Char {
        for ((base, arr) in toneTable) if (arr.contains(c)) return base
        return c
    }

    private fun toneOf(c: Char): Int {
        for (arr in toneTable.values) {
            val idx = arr.indexOf(c)
            if (idx >= 0) return idx
        }
        return 0
    }

    private fun applyTone(c: Char, tone: Int): Char {
        val arr = toneTable[baseOf(c)] ?: return c
        return arr[tone]
    }

    fun transform(raw: String): String {
        val out = StringBuilder()

        for (ch in raw) {
            val lower = ch.lowercaseChar()
            val isUpper = ch.isUpperCase()

            when (lower) {
                'd' -> {
                    val lastIdx = out.length - 1
                    if (lastIdx >= 0 && out[lastIdx].lowercaseChar() == 'd' &&
                        out[lastIdx] != 'đ' && out[lastIdx] != 'Đ'
                    ) {
                        out.setCharAt(lastIdx, if (out[lastIdx].isUpperCase()) 'Đ' else 'đ')
                    } else {
                        out.append(ch)
                    }
                }

                'a', 'e', 'o' -> {
                    val lastIdx = out.length - 1
                    if (lastIdx >= 0 && out[lastIdx].lowercaseChar() == lower) {
                        val newBase = when (lower) {
                            'a' -> 'â'
                            'e' -> 'ê'
                            else -> 'ô'
                        }
                        out.setCharAt(
                            lastIdx,
                            if (out[lastIdx].isUpperCase()) newBase.uppercaseChar() else newBase
                        )
                    } else {
                        out.append(ch)
                    }
                }

                'w' -> {
                    val lastIdx = out.length - 1
                    val lastBase = if (lastIdx >= 0) out[lastIdx].lowercaseChar() else ' '
                    val newBase = when (lastBase) {
                        'a' -> 'ă'
                        'o' -> 'ơ'
                        'u' -> 'ư'
                        else -> null
                    }
                    if (newBase != null) {
                        out.setCharAt(
                            lastIdx,
                            if (out[lastIdx].isUpperCase()) newBase.uppercaseChar() else newBase
                        )
                    } else {
                        // "w" typed alone is a common shortcut for "ư"
                        out.append(if (isUpper) 'Ư' else 'ư')
                    }
                }

                's', 'f', 'r', 'x', 'j' -> {
                    val tone = when (lower) {
                        's' -> 1
                        'f' -> 2
                        'r' -> 3
                        'x' -> 4
                        else -> 5
                    }
                    val pos = findToneTarget(out)
                    if (pos >= 0) {
                        out.setCharAt(pos, applyTone(out[pos], tone))
                    } else {
                        out.append(ch)
                    }
                }

                'z' -> {
                    val pos = findToneTarget(out)
                    if (pos >= 0 && toneOf(out[pos]) != 0) {
                        out.setCharAt(pos, applyTone(out[pos], 0))
                    } else {
                        out.append(ch)
                    }
                }

                else -> out.append(ch)
            }
        }

        return out.toString()
    }

    /**
     * Finds the index inside [out] of the vowel that should carry the tone
     * mark, following standard Vietnamese tone-placement rules:
     *  1. A vowel that already has an inherent modifier (ă â ê ô ơ ư) wins.
     *  2. Otherwise, in a closed syllable (consonant after the vowel
     *     cluster) the tone goes on the last vowel of the cluster.
     *  3. In an open syllable (vowel cluster ends the word) the tone goes
     *     on the first vowel of the cluster (classic/dictionary style,
     *     e.g. "hòa", "thúy").
     * The glide u/i in "qu-"/"gi-" is ignored when other vowels exist.
     */
    private fun findToneTarget(out: StringBuilder): Int {
        if (out.isEmpty()) return -1

        var start = out.length
        while (start > 0 && out[start - 1].isLetter()) start--
        val syllable = out.substring(start)
        if (syllable.isEmpty()) return -1

        val positions = mutableListOf<Int>()
        for (k in syllable.indices) {
            if (vowels.contains(syllable[k].lowercaseChar())) positions.add(start + k)
        }
        if (positions.isEmpty()) return -1

        val lowerSyll = syllable.lowercase()
        if (positions.size > 1) {
            if ((lowerSyll.startsWith("qu") || lowerSyll.startsWith("gi")) &&
                positions[0] == start + 1
            ) {
                positions.removeAt(0)
            }
        }
        if (positions.isEmpty()) return -1
        if (positions.size == 1) return positions[0]

        for (p in positions) {
            if (modifiedVowels.contains(out[p].lowercaseChar())) return p
        }

        val lastVowelPos = positions.last()
        val isClosed = lastVowelPos < out.length - 1
        return if (isClosed) positions.last() else positions.first()
    }
}
