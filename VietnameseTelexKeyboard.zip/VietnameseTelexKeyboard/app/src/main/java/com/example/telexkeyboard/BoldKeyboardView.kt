package com.example.telexkeyboard

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.inputmethodservice.KeyboardView
import android.util.AttributeSet

// The framework's KeyboardView has no public XML attribute for making key
// labels bold (only size/color/background are exposed). The label Paint it
// draws with is kept in a private field ("mPaint" on every AOSP version
// this has been checked against), so this reaches in via reflection once,
// right after construction, and swaps that Paint's typeface to bold.
//
// Wrapped in try/catch on purpose: if some OEM build renamed or removed
// the field, we just silently fall back to the regular (non-bold) look
// instead of crashing the keyboard.
class BoldKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : KeyboardView(context, attrs) {

    init {
        try {
            val paintField = KeyboardView::class.java.getDeclaredField("mPaint")
            paintField.isAccessible = true
            (paintField.get(this) as? Paint)?.typeface = Typeface.DEFAULT_BOLD
        } catch (e: Exception) {
            // Fall back silently — see class comment above.
        }
    }

    // Same rationale as the bold-typeface reflection above: KeyboardView
    // has no public setter for key text size, only a one-time XML
    // attribute (android:keyTextSize/labelTextSize) read in the
    // constructor into private int fields. onBufferDraw() re-reads those
    // fields on every key redraw (rather than caching a size on the
    // Paint), so overwriting the fields directly — instead of e.g.
    // calling paint.setTextSize() — is what actually sticks across
    // redraws. Called from TelexIME whenever the user's custom text-size
    // preference needs to be (re)applied to this view instance.
    //
    // [labelSizePx] keeps the original design's ratio between the two
    // (16sp label / 26sp key = ~0.615) unless the caller overrides it, so
    // multi-character key labels (e.g. "Ctrl", "⇧123") scale together
    // with the main letters instead of looking mismatched.
    fun applyCustomTextSize(keySizePx: Float, labelSizePx: Float = keySizePx * (16f / 26f)) {
        try {
            setPrivateSizeField("mKeyTextSize", keySizePx)
            setPrivateSizeField("mLabelTextSize", labelSizePx)
            invalidateAllKeys()
        } catch (e: Exception) {
            // Fall back silently — leaves whatever size was already in
            // effect (either the XML default or a previously-applied
            // custom size) rather than crashing the keyboard.
        }
    }

    private fun setPrivateSizeField(name: String, px: Float) {
        val field = KeyboardView::class.java.getDeclaredField(name)
        field.isAccessible = true
        // The framework field's exact type (int vs float) isn't part of
        // the public API and could differ across AOSP versions/OEMs, so
        // this checks at runtime instead of assuming one or the other.
        if (field.type == Int::class.javaPrimitiveType) {
            field.setInt(this, px.toInt())
        } else {
            field.setFloat(this, px)
        }
    }
}
