package com.example.telexkeyboard

import android.content.ClipboardManager
import android.content.Intent
import android.app.Activity
import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.os.ResultReceiver
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class TelexIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    // Second symbols page (currency, math, quotation/punctuation extras,
    // arrows...) — reached via the "1/2" / "2/2" toggle key on the
    // symbols keyboard, since one page was too cramped to fit everything
    // people actually need.
    private lateinit var symbolsKeyboard2: Keyboard

    // Raw Telex keystrokes typed since the last word boundary (space,
    // punctuation, enter). Re-transformed into Vietnamese on every keystroke.
    private val rawBuffer = StringBuilder()

    // Length (in chars) of the Vietnamese text currently composed & sent
    // to the editor for rawBuffer, so we know how much to delete before
    // sending the updated version.
    private var composedLength = 0

    private var capsOn = false

    // Double-tapping Shift within DOUBLE_TAP_MS turns on a persistent Caps
    // Lock instead of the normal one-shot capitalize-next-letter behavior.
    // Tapping Shift again while Caps Lock is on turns it back off.
    private var capsLock = false
    private var lastShiftTapTime = 0L

    companion object {
        const val KEYCODE_SHIFT = -12
        // Dedicated Caps Lock key, placed to the left of "a" like a
        // physical keyboard — a direct on/off toggle for the same
        // capsLock state that double-tapping Shift already sets, so the
        // user doesn't have to remember the double-tap gesture.
        const val KEYCODE_CAPSLOCK = -13
        const val KEYCODE_CTRL = -10
        const val KEYCODE_ALT = -11
        const val KEYCODE_LANG_TOGGLE = -20
        const val KEYCODE_SYMBOLS_PAGE = -21
        const val DOUBLE_TAP_MS = 400L
        const val REPEAT_INITIAL_DELAY_MS = 400L
        const val REPEAT_INTERVAL_MS = 50L
        // How far back (chars) maybeFixSentence() looks for the start of
        // the sentence that just ended. Generous enough for a long
        // sentence without pulling in the whole message on every '.'.
        const val SENTENCE_SCAN_WINDOW = 300
    }

    // Ctrl / Alt behave like one-shot modifiers (same idea as Shift above):
    // tap to arm, the next key is sent as a real KeyEvent combo (e.g. Ctrl+C),
    // then the modifier auto-clears.
    private var ctrlOn = false
    private var altOn = false

    // Vietnamese Telex mode is on by default. Every letter key routes
    // through TelexEngine.transform(), which means ordinary English text
    // gets mangled — s/f/r/x/j/w/d and doubled a/e/o are all Telex
    // triggers and appear constantly in English words (e.g. "fox" ->
    // "fõ", "over" -> "ỏve"). The VN/EN key lets the user turn Telex off
    // entirely to type plain English, and back on for Vietnamese.
    private var vietnameseOn = true

    // Last selection reported by the editor, used to detect edits we did
    // NOT cause ourselves (paste, tapping to move the cursor, selecting
    // text, autocorrect from the host app, etc.) while a Telex word is
    // still in progress (composedLength > 0). Without this check, typing
    // the next letter after one of those external changes would call
    // deleteSurroundingText(composedLength, 0) against the NEW cursor
    // position and delete unrelated text the user just pasted/selected.
    private var lastKnownSelStart = -1
    private var lastKnownSelEnd = -1

    // Toolbar + panel-switching (emoji / clipboard), added alongside the
    // existing QWERTY/Symbols KeyboardView. All three panels live inside
    // panelContainer and are swapped via visibility, so the toolbar row
    // above them is always reachable no matter which one is showing.
    private lateinit var panelContainer: FrameLayout
    private lateinit var emojiPanel: View
    private lateinit var clipboardPanel: View
    private lateinit var emojiGrid: GridLayout
    private lateinit var clipboardListView: ListView
    private var emojiGridBuilt = false

    // Emoji panel now has two tabs — Emoji and Symbol — instead of one
    // mixed grid. showingSymbolTab tracks which set buildEmojiGrid() should
    // draw; emojiGridBuilt is reset (not just left true) on every tab
    // switch too, since the grid contents differ per tab.
    private lateinit var tabEmoji: TextView
    private lateinit var tabSymbol: TextView
    private var showingSymbolTab = false

    // Ctrl/Alt/VN toggle buttons live in the top toolbar now (instead of
    // eating up space in the bottom keyboard row on every layout), so the
    // bottom row can give comma/space/period/enter comfortable widths.
    // See toggleCtrl()/toggleAlt()/toggleVietnamese() for the shared logic
    // and setModifierKeyVisual()/updateLangKeyVisual() for how these mirror
    // their on/off state.
    private lateinit var btnCtrl: TextView
    private lateinit var btnAlt: TextView
    private lateinit var btnVn: TextView

    // Arrow-key pad in the toolbar: moves the real text cursor in the
    // editor. Separate from the arrow *glyphs* on the symbols page
    // (keyboard_symbols2.xml), which just insert "←"/"→"/"↑"/"↓" as
    // literal characters. Held together with Handler-based repeat so a
    // long press moves continuously instead of one step per tap.
    private lateinit var btnArrowLeft: TextView
    private lateinit var btnArrowUp: TextView
    private lateinit var btnArrowDown: TextView
    private lateinit var btnArrowRight: TextView
    private val repeatHandler = Handler(Looper.getMainLooper())

    private val voiceResultReceiver = object : ResultReceiver(Handler(Looper.getMainLooper())) {
        override fun onReceiveResult(resultCode: Int, resultData: Bundle?) {
            if (resultCode != Activity.RESULT_OK) return
            val text = resultData?.voiceText()?.trim().orEmpty()
            if (text.isEmpty()) return
            currentInputConnection?.commitText(text, 1)
            lastKnownSelStart = -1
            lastKnownSelEnd = -1
        }
    }

    // Android has no public API to read the SYSTEM clipboard's own
    // history — only the current clip. So we track our own session
    // history by listening for clipboard changes for as long as this IME
    // process is alive (cleared on process death, same as most clipboard
    // managers' "recent" list would be for an app that isn't itself the
    // clipboard owner). All the bookkeeping (recent list, pinned list,
    // OTP-like filtering, persistence) lives in ClipboardHistoryStore —
    // this class just wires it to the system clipboard and the panel UI.
    private val clipboardStore = ClipboardHistoryStore()
    private var clipboardManager: ClipboardManager? = null
    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager?.primaryClip
        if (clip != null && clip.itemCount > 0) {
            clipboardStore.onNewClip(clip.getItemAt(0).coerceToText(this)?.toString())
        }
    }

    override fun onCreate() {
        super.onCreate()
        clipboardManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager?.addPrimaryClipChangedListener(clipboardListener)
        clipboardStore.load(this)
    }

    override fun onDestroy() {
        clipboardManager?.removePrimaryClipChangedListener(clipboardListener)
        repeatHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // Mặc định InputMethodService tự bật chế độ "fullscreen" (extract view)
    // khi màn hình ngang trên điện thoại — một ô soạn thảo lớn chiếm phần
    // trên cùng, đè lên nội dung app phía sau. Hầu như mọi bàn phím tùy
    // biến đều tắt hẳn cơ chế này vì nó gây rối, che mất context của app
    // đang gõ mà không mang lại lợi ích tương xứng trên màn hình bàn phím
    // đã đủ gọn của app này.
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.ime_container, null)
        // inflate() với root=null bỏ qua layout_width/height khai báo trên
        // thẻ gốc của ime_container.xml, khiến root không có LayoutParams.
        // Khi InputMethodService add view này vào FrameLayout nội bộ của
        // nó, FrameLayout sẽ tự gán mặc định MATCH_PARENT x MATCH_PARENT
        // cho view con không có params -> cửa sổ bàn phím bị kéo full màn
        // hình. Đặt lại params tường minh ở đây để giữ đúng wrap_content.
        root.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        keyboardView = root.findViewById(R.id.keyboard_view)
        panelContainer = root.findViewById(R.id.panel_container)
        emojiPanel = root.findViewById(R.id.emoji_panel)
        clipboardPanel = root.findViewById(R.id.clipboard_panel)
        emojiGrid = root.findViewById(R.id.emoji_grid)
        clipboardListView = root.findViewById(R.id.clipboard_list)
        btnCtrl = root.findViewById(R.id.btn_ctrl)
        btnAlt = root.findViewById(R.id.btn_alt)
        btnVn = root.findViewById(R.id.btn_vn)
        btnArrowLeft = root.findViewById(R.id.btn_arrow_left)
        btnArrowUp = root.findViewById(R.id.btn_arrow_up)
        btnArrowDown = root.findViewById(R.id.btn_arrow_down)
        btnArrowRight = root.findViewById(R.id.btn_arrow_right)
        tabEmoji = root.findViewById(R.id.tab_emoji)
        tabSymbol = root.findViewById(R.id.tab_symbol)
        // Trạng thái "đang chọn" mặc định của tab Emoji được set ở đây thay
        // vì android:selected="true" trong XML — AAPT2 trên một số phiên
        // bản/kênh phân phối SDK bị lỗi không resolve được thuộc tính này
        // dù nó hoàn toàn hợp lệ, gây lỗi build khó hiểu. Set bằng code an
        // toàn tuyệt đối và cho kết quả hiển thị giống hệt.
        tabEmoji.isSelected = true

        // onCreateInputView() re-inflates a FRESH (empty) emoji_grid every
        // time the input view is recreated (switching apps/fields, screen
        // rotation, etc), but emojiGridBuilt lives on the longer-lived
        // TelexIME instance and would otherwise still read true from a
        // previous inflation — leaving this new grid permanently empty.
        // Force a rebuild against the new view every time.
        emojiGridBuilt = false
        showingSymbolTab = false

        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = true
        applyTextSizePref()
        updateLangKeyVisual()
        updateEnterKeyVisual()
        // loadKeyboards() just recreated qwertyKeyboard from XML (all-
        // lowercase labels); if Caps Lock was already on before this
        // input view got recreated (e.g. screen rotation), re-apply
        // uppercase labels to the new Keyboard object.
        updateLetterKeyLabels()

        root.findViewById<View>(R.id.btn_emoji).setOnClickListener {
            if (emojiPanel.visibility == View.VISIBLE) showKeyboardPanel() else showEmojiPanel()
        }
        root.findViewById<View>(R.id.btn_clipboard).setOnClickListener {
            if (clipboardPanel.visibility == View.VISIBLE) showKeyboardPanel() else showClipboardPanel()
        }
        root.findViewById<View>(R.id.btn_voice).setOnClickListener {
            startVoiceInput()
        }
        root.findViewById<View>(R.id.btn_settings).setOnClickListener {
            val intent = Intent(this, SetupActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        btnCtrl.setOnClickListener { toggleCtrl() }
        btnAlt.setOnClickListener { toggleAlt() }
        btnVn.setOnClickListener { toggleVietnamese() }
        setupRepeatingPress(btnArrowLeft) { sendCursorKey(KeyEvent.KEYCODE_DPAD_LEFT) }
        setupRepeatingPress(btnArrowUp) { sendCursorKey(KeyEvent.KEYCODE_DPAD_UP) }
        setupRepeatingPress(btnArrowDown) { sendCursorKey(KeyEvent.KEYCODE_DPAD_DOWN) }
        setupRepeatingPress(btnArrowRight) { sendCursorKey(KeyEvent.KEYCODE_DPAD_RIGHT) }
        tabEmoji.setOnClickListener { switchEmojiTab(toSymbol = false) }
        tabSymbol.setOnClickListener { switchEmojiTab(toSymbol = true) }
        root.findViewById<View>(R.id.emoji_back).setOnClickListener { showKeyboardPanel() }
        root.findViewById<View>(R.id.emoji_delete).setOnClickListener {
            deleteOneCharacterBeforeCursor()
        }
        root.findViewById<View>(R.id.clipboard_back).setOnClickListener { showKeyboardPanel() }
        root.findViewById<View>(R.id.clipboard_clear_all).setOnClickListener {
            // Clears the unpinned history only — pins are a deliberate
            // keep, so a blanket "clear all" shouldn't take them out too.
            clipboardStore.clearHistory()
            refreshClipboardList()
        }

        return root
    }

    private fun startVoiceInput() {
        if (currentInputConnection == null) return
        resetWord()
        try {
            val intent = Intent(this, VoiceInputActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putVoiceResultReceiver(voiceResultReceiver)
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(
                this,
                "Không thể mở nhập bằng giọng nói",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun showKeyboardPanel() {
        keyboardView.visibility = View.VISIBLE
        emojiPanel.visibility = View.GONE
        clipboardPanel.visibility = View.GONE
    }

    private fun showEmojiPanel() {
        // Rời bàn phím chữ nghĩa là từ đang gõ dở (nếu có) được xem như đã
        // chốt xong — xoá state rawBuffer/composedLength để không bị lệch
        // với nội dung thật trong ô nhập khi quay lại gõ tiếp sau này.
        resetWord()
        if (!emojiGridBuilt) buildEmojiGrid()
        keyboardView.visibility = View.GONE
        clipboardPanel.visibility = View.GONE
        emojiPanel.visibility = View.VISIBLE
    }

    private fun showClipboardPanel() {
        resetWord()
        refreshClipboardList()
        keyboardView.visibility = View.GONE
        emojiPanel.visibility = View.GONE
        clipboardPanel.visibility = View.VISIBLE
    }

    // A flat, single-page grid of common emoji — no category tabs, kept
    // simple. Built once lazily on first open, not on every keystroke
    // (rebuilt again if the underlying view was recreated — see the
    // emojiGridBuilt reset in onCreateInputView()).
    private fun switchEmojiTab(toSymbol: Boolean) {
        if (showingSymbolTab == toSymbol) return
        showingSymbolTab = toSymbol
        tabEmoji.isSelected = !toSymbol
        tabSymbol.isSelected = toSymbol
        buildEmojiGrid()
    }

    private fun buildEmojiGrid() {
        // Defensive double-check alongside the emojiGridBuilt flag: if a
        // stale/duplicate build ever slipped through, clear leftover
        // children first rather than stacking a second copy on top.
        emojiGrid.removeAllViews()
        val items = if (showingSymbolTab) EmojiData.symbolList else EmojiData.emojiList
        val density = resources.displayMetrics.density
        // Compute the column count/cell size from the actual screen width
        // instead of a fixed 44dp guess — a fixed size left a gap of dead
        // space on the right on wider screens (only 8 columns' worth of
        // cells got used). One extra column (9 instead of 8) soaks up
        // that space and keeps rows edge-to-edge on any screen size.
        val horizontalPaddingPx = (4 * density * 2).toInt()
        val gridWidthPx = resources.displayMetrics.widthPixels - horizontalPaddingPx
        val columns = 9
        val cellSize = gridWidthPx / columns
        emojiGrid.columnCount = columns
        for (e in items) {
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 22f
            tv.gravity = android.view.Gravity.CENTER
            val params = GridLayout.LayoutParams()
            params.width = cellSize
            params.height = cellSize
            tv.layoutParams = params
            tv.setOnClickListener { currentInputConnection?.commitText(e, 1) }
            emojiGrid.addView(tv)
        }
        emojiGridBuilt = true
    }

    private var clipboardRows: List<ClipboardRow> = emptyList()

    private fun refreshClipboardList() {
        clipboardRows = clipboardStore.rows(
            pinnedHeader = getString(R.string.clipboard_pinned_section),
            recentHeader = getString(R.string.clipboard_recent_section),
            emptyLabel = getString(R.string.clipboard_empty)
        )
        clipboardListView.adapter = ClipboardAdapter()
    }

    private fun togglePin(text: String, currentlyPinned: Boolean) {
        clipboardStore.togglePin(text, currentlyPinned, this)
        refreshClipboardList()
    }

    private fun deleteClipboardEntry(text: String, pinned: Boolean) {
        clipboardStore.delete(text, pinned, this)
        refreshClipboardList()
    }

    // Plain BaseAdapter (not ArrayAdapter) since each row needs its own
    // pin-toggle and delete buttons wired to that row's specific entry,
    // not just a label to display.
    private inner class ClipboardAdapter : BaseAdapter() {
        override fun getCount() = clipboardRows.size
        override fun getItem(position: Int) = clipboardRows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) =
            if (clipboardRows[position] is ClipboardRow.Header) 0 else 1
        override fun isEnabled(position: Int) = clipboardRows[position] is ClipboardRow.Item

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return when (val row = clipboardRows[position]) {
                is ClipboardRow.Header -> {
                    val view = convertView
                        ?: LayoutInflater.from(this@TelexIME)
                            .inflate(R.layout.clipboard_section_header, parent, false)
                    (view as TextView).text = row.title
                    view
                }
                is ClipboardRow.Item -> {
                    val view = convertView
                        ?: LayoutInflater.from(this@TelexIME)
                            .inflate(R.layout.clipboard_item, parent, false)
                    val textView = view.findViewById<TextView>(R.id.item_text)
                    val pinButton = view.findViewById<ImageButton>(R.id.item_pin)
                    val deleteButton = view.findViewById<ImageButton>(R.id.item_delete)

                    val isPlaceholder = clipboardStore.isEmpty()
                    textView.text = row.text
                    pinButton.setImageResource(
                        if (row.pinned) R.drawable.ic_pin_filled else R.drawable.ic_pin_outline
                    )
                    pinButton.visibility = if (isPlaceholder) View.GONE else View.VISIBLE
                    deleteButton.visibility = if (isPlaceholder) View.GONE else View.VISIBLE
                    pinButton.setOnClickListener { togglePin(row.text, row.pinned) }
                    deleteButton.setOnClickListener { deleteClipboardEntry(row.text, row.pinned) }
                    view.setOnClickListener {
                        if (!isPlaceholder) currentInputConnection?.commitText(row.text, 1)
                    }
                    view
                }
            }
        }
    }

    // Đọc lại cỡ chữ tùy chọn từ SharedPreferences và áp vào keyboardView
    // hiện tại — gọi mỗi lần input view được tạo/mở lại (giống cách
    // loadKeyboards() được gọi lại) để thay đổi trong màn Cài đặt có hiệu
    // lực ngay ở lần mở bàn phím tiếp theo, không cần khởi động lại app.
    private fun applyTextSizePref() {
        val sp = TelexPrefs.of(this).getInt(TelexPrefs.KEY_KEYBOARD_TEXT_SIZE_SP, 26)
        val px = sp * resources.displayMetrics.scaledDensity
        (keyboardView as? BoldKeyboardView)?.applyCustomTextSize(px)
    }

    private fun loadKeyboards() {
        val prefs = TelexPrefs.of(this)
        val size = prefs.getInt(TelexPrefs.KEY_KEYBOARD_SIZE, 1) // 0=nhỏ, 1=vừa, 2=lớn, 3=tùy chỉnh
        // Chế độ "tùy chỉnh" dùng bộ layout cỡ vừa (44dp) làm khung tỉ lệ
        // gốc, rồi scaleKeyboardHeight() bên dưới scale toàn bộ keyboard
        // (giữ nguyên bề rộng màn hình) theo đúng chiều cao mỗi hàng phím
        // mà người dùng chọn bằng SeekBar trong SetupActivity — cho phép
        // mọi giá trị liên tục thay vì chỉ 3 mốc cố định nhỏ/vừa/lớn.
        val qwertyRes = when (size) {
            0 -> R.xml.keyboard_qwerty_small
            2 -> R.xml.keyboard_qwerty_large
            else -> R.xml.keyboard_qwerty
        }
        val symbolsRes = when (size) {
            0 -> R.xml.keyboard_symbols_small
            2 -> R.xml.keyboard_symbols_large
            else -> R.xml.keyboard_symbols
        }
        val symbols2Res = when (size) {
            0 -> R.xml.keyboard_symbols2_small
            2 -> R.xml.keyboard_symbols2_large
            else -> R.xml.keyboard_symbols2
        }
        qwertyKeyboard = Keyboard(this, qwertyRes)
        symbolsKeyboard = Keyboard(this, symbolsRes)
        symbolsKeyboard2 = Keyboard(this, symbols2Res)

        if (size == 3) {
            // Tính hệ số tỉ lệ dựa trên chiều cao 1 hàng phím ở layout gốc
            // (44dp, cỡ "vừa") so với giá trị dp người dùng chọn, rồi áp
            // hệ số đó lên TOÀN BỘ chiều cao bàn phím (không chỉ 1 hàng)
            // qua scaleKeyboardHeight() bên dưới — KHÔNG dùng
            // Keyboard.resize() vì android.inputmethodservice.Keyboard
            // (bản AOSP thật, không phải một fork bàn phím custom nào)
            // không có method công khai đó; gọi nhầm nó gây lỗi biên dịch
            // "Unresolved reference: resize", đúng như CI báo.
            try {
                // coerceIn khớp customSizeMinDp/MaxDp (28..72) bên
                // SetupActivity — phòng trường hợp giá trị đã lưu từ trước
                // rơi ra ngoài khoảng cho phép hiện tại (vd. sau này đổi
                // range), tránh áp hệ số scale không kiểm soát.
                val customDp = prefs.getInt(TelexPrefs.KEY_KEYBOARD_CUSTOM_HEIGHT_DP, 44)
                    .coerceIn(28, 72)
                val scale = customDp.toFloat() / 44f
                for (kb in listOf(qwertyKeyboard, symbolsKeyboard, symbolsKeyboard2)) {
                    scaleKeyboardHeight(kb, scale)
                }
            } catch (e: Exception) {
                // Giữ nguyên cỡ "vừa" đã tải ở trên nếu scale lỗi.
            }
        }
    }

    // android.inputmethodservice.Keyboard không có setter công khai cho
    // chiều cao/tọa độ phím, nên tự làm thủ công những gì resize() (không
    // tồn tại trong lớp này) đáng lẽ phải làm:
    // 1) Dịch y và height của TỪNG phím (Keyboard.Key.x/y/width/height là
    //    field public) theo scale — chỉ đổi chiều DỌC (y, height), giữ
    //    nguyên x/width vì tính năng này chỉ chỉnh "chiều cao mỗi hàng
    //    phím", không đổi bề rộng.
    // 2) Ghi lại tổng chiều cao vào field riêng tư mTotalHeight — không có
    //    setter công khai, nhưng KeyboardView.onMeasure() đọc getHeight()
    //    (tức mTotalHeight) để quyết định chiều cao cả view, nên nếu không
    //    cập nhật field này thì các phím đã bị dịch xuống theo scale sẽ bị
    //    view cắt cụt hoặc để trống khoảng thừa.
    // Bọc try/catch quanh phần reflection riêng: nếu một bản OEM đổi tên
    // field, các phím vẫn đã được scale đúng ở bước 1 (nhìn gần đúng), chỉ
    // có báo cáo getHeight() là không khớp tuyệt đối — không crash.
    private fun scaleKeyboardHeight(kb: Keyboard, scale: Float) {
        val newHeight = (kb.height * scale).toInt().coerceAtLeast(1)
        for (key in kb.keys) {
            key.y = (key.y * scale).toInt()
            key.height = (key.height * scale).toInt().coerceAtLeast(1)
        }
        try {
            val field = Keyboard::class.java.getDeclaredField("mTotalHeight")
            field.isAccessible = true
            field.setInt(kb, newHeight)
        } catch (e: Exception) {
            // Xem comment ở trên: các phím đã scale, chỉ getHeight() lệch.
        }
    }

    // EditorInfo của phiên nhập hiện tại — dùng để phím Enter biết nên gửi
    // "hành động" của ô nhập (Tìm/Gửi/Tiếp/Xong...) hay chỉ là xuống dòng
    // thường. Lưu lại ở đây vì onKey() không nhận được EditorInfo trực
    // tiếp từ framework.
    private var currentEditorInfo: EditorInfo? = null

    // Cờ viết hoa tự động mà ô nhập khai báo qua EditorInfo.inputType
    // (CAP_SENTENCES/CAP_WORDS/CAP_CHARACTERS) — chỉ áp dụng cho
    // TYPE_CLASS_TEXT, vì các lớp khác (số, điện thoại, ngày giờ...)
    // không có khái niệm viết hoa.
    private var autoCapFlags: Int = 0

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentEditorInfo = info
        autoCapFlags = if (info != null &&
            (info.inputType and EditorInfo.TYPE_MASK_CLASS) == EditorInfo.TYPE_CLASS_TEXT
        ) {
            info.inputType and (
                EditorInfo.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                    EditorInfo.TYPE_TEXT_FLAG_CAP_WORDS or
                    EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES
                )
        } else 0
        // Fix cứng ở cấp Window: một số thiết bị/emulator không tôn trọng
        // wrap_content mà mInputFrame của framework đặt cho input view,
        // khiến cả cửa sổ IME bị kéo full màn hình (khoảng đen phía dưới
        // bàn phím). Ép lại layout + gravity mỗi lần bàn phím được mở, bất
        // kể nguyên nhân gốc từ đâu.
        window?.window?.apply {
            setGravity(android.view.Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        resetWord()
        clearModifiers()
        resetShiftState()
        loadKeyboards()
        keyboardView.keyboard = qwertyKeyboard
        updateLangKeyVisual()
        updateEnterKeyVisual()
        applyTextSizePref()
        applyInitialAutoCapitalization()
        if (::panelContainer.isInitialized) showKeyboardPanel()
        // Fresh input session: we don't know the editor's cursor position
        // yet (that arrives via the next onUpdateSelection callback), so
        // clear tracking rather than compare against stale values from a
        // previous field.
        lastKnownSelStart = -1
        lastKnownSelEnd = -1
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetWord()
        clearModifiers()
        resetShiftState()
        repeatHandler.removeCallbacksAndMessages(null)
    }

    private fun resetWord() {
        rawBuffer.setLength(0)
        composedLength = 0
    }

    // Called at a REAL word boundary (space / Enter / punctuation just
    // typed right after a word), before resetWord() wipes the buffers.
    //
    // Vietnamese Telex mode being on means every letter already went
    // through TelexEngine.transform() live, so an English word typed
    // inline (e.g. "is", "as", "was", "wifi") may currently be sitting in
    // the editor mangled ("í", "ás", "wás", "wifi" -> "wìfi" etc.) — the
    // exact problem the Gboard/Samsung comparison calls out. Rather than
    // requiring the user to flip the VN/EN key for every stray English
    // word (the only option this app had before), check the word that
    // just finished against EnglishWordList: if it's a recognized English
    // word AND Telex actually changed it, silently replace the mangled
    // text with what was literally typed. Runs once per word, entirely
    // offline, no change to the live per-keystroke rendering.
    private fun finalizeWordBoundary(ic: InputConnection) {
        val autoFixEnabled = TelexPrefs.of(this).getBoolean(TelexPrefs.KEY_AUTO_FIX_ENGLISH, true)
        val raw = rawBuffer.toString()
        if (AutoFixPolicy.shouldFixEnglishWord(vietnameseOn, composedLength, raw, autoFixEnabled)) {
            val transformed = TelexEngine.transform(raw)
            if (transformed != raw) {
                ic.deleteSurroundingText(composedLength, 0)
                ic.commitText(raw, 1)
            }
        }
        resetWord()
    }

    // Chars that end a Vietnamese sentence — used to decide when it's
    // worth re-scanning the whole sentence for VietnameseDiacriticFixer,
    // not just the one word that just finished.
    private val sentenceEnders = charArrayOf('.', '!', '?')

    /**
     * Re-reads the sentence that just ended straight from the editor (not
     * from our own per-word buffers, which only ever track the CURRENT
     * word) and runs [VietnameseDiacriticFixer] over it. Only ever
     * replaces text when a fix was actually found — see that class for
     * how conservative it is about when to act.
     */
    private fun maybeFixSentence(ic: InputConnection) {
        val autoFixEnabled = TelexPrefs.of(this).getBoolean(TelexPrefs.KEY_AUTO_FIX_DIACRITICS, true)
        if (!AutoFixPolicy.shouldFixDiacritics(vietnameseOn, autoFixEnabled)) return
        val before = ic.getTextBeforeCursor(SENTENCE_SCAN_WINDOW, 0)?.toString() ?: return

        // Sentence start = right after the previous sentence-ender (or
        // newline) inside the scanned window. If none is found AND the
        // window is full (there could be more un-scanned text before it),
        // bail out rather than guess — better to skip a fix than risk
        // touching a word from an earlier, already-settled sentence that
        // just happens to share a skeleton with one dictionary word.
        var start = 0
        var foundBoundary = false
        for (idx in before.length - 1 downTo 0) {
            val ch = before[idx]
            if (ch in sentenceEnders || ch == '\n') {
                start = idx + 1
                foundBoundary = true
                break
            }
        }
        if (!foundBoundary && before.length >= SENTENCE_SCAN_WINDOW) return
        val sentence = before.substring(start)
        if (sentence.isBlank()) return

        val fixed = VietnameseDiacriticFixer.fix(sentence) ?: return
        ic.deleteSurroundingText(sentence.length, 0)
        ic.commitText(fixed, 1)
    }

    /**
     * Single entry point for every real word boundary (space, punctuation,
     * Enter). Always finalizes the word that just ended (English-word
     * fix); additionally re-scans the whole sentence for tone-mark fixes
     * when [isSentenceEnd] is true, so that pass only runs once per
     * sentence instead of after every single word.
     */
    private fun handleWordBoundary(
        ic: InputConnection,
        isSentenceEnd: Boolean
    ) {
        finalizeWordBoundary(ic)
        if (isSentenceEnd) maybeFixSentence(ic)
    }

    // Called by the framework whenever the editor's selection/cursor
    // changes for ANY reason — our own edits, but also paste, tapping to
    // move the cursor, long-press selection, or the host app editing text
    // itself. If we're mid-word (composedLength > 0) and the change didn't
    // start from where we last left the cursor, it wasn't caused by us —
    // discard the stale Telex buffer so the next keystroke doesn't delete
    // the wrong text. We only ever touch our own tracking state here, never
    // the editor's text.
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)

        if (composedLength > 0 && lastKnownSelStart >= 0) {
            val expected = oldSelStart == lastKnownSelStart && oldSelEnd == lastKnownSelEnd
            val stillCollapsed = newSelStart == newSelEnd
            if (!expected || !stillCollapsed) {
                // External change (paste / cursor tap / selection / host
                // edit) landed while a Telex word was in progress. Drop the
                // buffer without issuing any delete — the text on screen is
                // left exactly as the external change made it.
                resetWord()
            }
        }
        lastKnownSelStart = newSelStart
        lastKnownSelEnd = newSelEnd
    }

    // Ctrl/Alt only. Cleared on backspace, Enter/Space-with-modifier, and
    // switching keyboards — a pending Ctrl/Alt combo shouldn't linger past
    // any of those. Deliberately does NOT touch Shift/Caps Lock: those
    // should survive a backspace or a QWERTY<->Symbols switch, and are only
    // reset by resetShiftState() at the start/end of an input session.
    private fun clearModifiers() {
        ctrlOn = false
        altOn = false
        setModifierKeyVisual(KEYCODE_CTRL, false)
        setModifierKeyVisual(KEYCODE_ALT, false)
    }

    // Shared by the toolbar Ctrl/Alt/VN buttons (their onClick) and, for
    // backward compatibility, by onKey() below in case a key with these
    // codes ever appears on a keyboard layout again.
    private fun toggleCtrl() {
        ctrlOn = !ctrlOn
        setModifierKeyVisual(KEYCODE_CTRL, ctrlOn)
    }

    private fun toggleAlt() {
        altOn = !altOn
        setModifierKeyVisual(KEYCODE_ALT, altOn)
    }

    private fun toggleVietnamese() {
        resetWord()
        vietnameseOn = !vietnameseOn
        updateLangKeyVisual()
    }

    private fun resetShiftState() {
        lastShiftTapTime = 0L
        setCapsLock(false)
    }

    // Shift is normally a one-shot modifier: tap to arm, capitalizes exactly
    // the next letter, then auto-clears. Double-tapping it within
    // DOUBLE_TAP_MS instead turns on a persistent Caps Lock (tap once more
    // to release it) — see the KEYCODE_SHIFT branch in onKey(). Fully
    // self-managed (state + visual) instead of relying on the framework's
    // built-in KEYCODE_SHIFT handling, which could get out of sync with our
    // own state and garble typing.
    private fun setShift(on: Boolean) {
        capsOn = on
        setModifierKeyVisual(KEYCODE_SHIFT, on)
        updateLetterKeyLabels()
    }

    // Swaps every a-z key's label between lower/upper case to match
    // capsOn, so the keyboard itself shows what will actually be typed
    // (not just the Shift key lighting up) — covers one-shot Shift,
    // double-tap/dedicated Caps Lock, and auto-capitalization alike,
    // since they all flow through setShift() above. Only the QWERTY
    // layer has letter keys, so the Symbols keyboards are untouched.
    // Derives the letter from each key's code (always the lowercase
    // ASCII value, per the layout XML) rather than its current label,
    // so this is safe to call repeatedly without compounding case.
    private fun updateLetterKeyLabels() {
        if (!::qwertyKeyboard.isInitialized) return
        qwertyKeyboard.keys
            .filter { it.codes.isNotEmpty() && it.codes[0] in 97..122 } // 'a'..'z'
            .forEach { key ->
                val base = key.codes[0].toChar()
                key.label = if (capsOn) base.uppercaseChar().toString() else base.toString()
            }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    // Turns the persistent Caps Lock state on/off — shared by the
    // dedicated Caps Lock key, the Shift double-tap gesture, and
    // CAP_CHARACTERS auto-capitalization, so all three stay in sync and
    // the Caps Lock key itself always lights up correctly regardless of
    // which of them engaged it.
    private fun setCapsLock(on: Boolean) {
        capsLock = on
        setShift(on)
        setModifierKeyVisual(KEYCODE_CAPSLOCK, on)
    }

    // Highlights/un-highlights the Ctrl/Alt/Shift key(s) matching `code` —
    // checked against BOTH keyboards (not just the one currently shown),
    // since Ctrl/Alt exist on both the QWERTY and Symbols layouts. Without
    // this, toggling Ctrl while on the Symbols keyboard would arm it
    // correctly internally but never actually light up the key.
    private fun setModifierKeyVisual(code: Int, on: Boolean) {
        listOf(
            if (::qwertyKeyboard.isInitialized) qwertyKeyboard else null,
            if (::symbolsKeyboard.isInitialized) symbolsKeyboard else null,
            if (::symbolsKeyboard2.isInitialized) symbolsKeyboard2 else null
        ).forEach { kb ->
            kb?.keys
                ?.filter { it.codes.isNotEmpty() && it.codes[0] == code }
                ?.forEach { it.on = on }
        }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()

        // Ctrl/Alt now live only in the toolbar (no longer as keys on the
        // keyboards themselves) — light up the matching toolbar button.
        when (code) {
            KEYCODE_CTRL -> if (::btnCtrl.isInitialized) btnCtrl.isSelected = on
            KEYCODE_ALT -> if (::btnAlt.isInitialized) btnAlt.isSelected = on
        }
    }

    // Updates the VN/EN key's label (and lights it up while in EN mode) on
    // both keyboards. Needs to be re-applied after every loadKeyboards()
    // call, since that recreates the Keyboard objects from the XML (which
    // always start with the default "VN" label).
    private fun updateLangKeyVisual() {
        val label = if (vietnameseOn) "VN" else "EN"
        listOf(
            if (::qwertyKeyboard.isInitialized) qwertyKeyboard else null,
            if (::symbolsKeyboard.isInitialized) symbolsKeyboard else null,
            if (::symbolsKeyboard2.isInitialized) symbolsKeyboard2 else null
        ).forEach { kb ->
            kb?.keys
                ?.filter { it.codes.isNotEmpty() && it.codes[0] == KEYCODE_LANG_TOGGLE }
                ?.forEach {
                    it.label = label
                    it.on = !vietnameseOn
                }
        }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()

        // VN/EN now lives only in the toolbar — update its label/highlight.
        if (::btnVn.isInitialized) {
            btnVn.text = label
            btnVn.isSelected = !vietnameseOn
        }
    }

    // Nhãn phím Enter đổi theo "hành động" mà ô nhập khai báo qua
    // EditorInfo.imeOptions (Tìm/Gửi/Tiếp/Xong/Đi...), giống hầu hết bàn
    // phím khác — vừa cho người dùng biết bấm Enter sẽ làm gì, vừa nhất
    // quán với nhánh xử lý thật trong onKey() bên dưới (performEditorAction
    // thay vì gửi phím Enter thô khi ô nhập có khai báo hành động cụ thể).
    private fun updateEnterKeyVisual() {
        val label = enterKeyLabel()
        listOf(
            if (::qwertyKeyboard.isInitialized) qwertyKeyboard else null,
            if (::symbolsKeyboard.isInitialized) symbolsKeyboard else null,
            if (::symbolsKeyboard2.isInitialized) symbolsKeyboard2 else null
        ).forEach { kb ->
            kb?.keys
                ?.filter { it.codes.isNotEmpty() && it.codes[0] == -4 }
                ?.forEach { it.label = label }
        }
        if (::keyboardView.isInitialized) keyboardView.invalidateAllKeys()
    }

    private fun enterKeyLabel(): String {
        val info = currentEditorInfo ?: return "⏎"
        if (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0) return "⏎"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEARCH -> "Tìm"
            EditorInfo.IME_ACTION_SEND -> "Gửi"
            EditorInfo.IME_ACTION_GO -> "Đi"
            EditorInfo.IME_ACTION_NEXT -> "Tiếp"
            EditorInfo.IME_ACTION_DONE -> "Xong"
            else -> "⏎"
        }
    }

    // Được gọi từ nhánh Enter trong onKey(). Nếu ô nhập khai báo một hành
    // động cụ thể (Tìm/Gửi/Tiếp/Xong/Đi) và không đặt cờ NO_ENTER_ACTION,
    // gọi thẳng performEditorAction() thay vì gửi KeyEvent Enter thô —
    // nhiều app (form tìm kiếm, khung chat gửi tin, các trường "Tiếp
    // theo" nối nhau) chỉ lắng nghe callback hành động này chứ không xử
    // lý phím Enter vật lý, nên gửi Enter thô sẽ chỉ xuống dòng thay vì
    // thật sự tìm/gửi/xong như người dùng mong đợi.
    private fun sendEnter(ic: InputConnection) {
        val info = currentEditorInfo
        val noEnterFlag = info != null && info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val hasRealAction = action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        if (hasRealAction && !noEnterFlag) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    // Được gọi ngay khi bắt đầu phiên nhập mới (onStartInputView), sau khi
    // đã reset Shift. Với CAP_CHARACTERS (vd. ô nhập biển số xe, mã code)
    // bật Caps Lock cho cả phiên; với CAP_WORDS/CAP_SENTENCES chỉ bật
    // Shift một lần cho ký tự đầu tiên nếu con trỏ đang ở đầu ô nhập
    // trống (không bật nếu đang sửa tiếp văn bản có sẵn).
    private fun applyInitialAutoCapitalization() {
        if (autoCapFlags == 0) return
        if (autoCapFlags and EditorInfo.TYPE_TEXT_FLAG_CAP_CHARACTERS != 0) {
            setCapsLock(true)
            return
        }
        val before = currentInputConnection?.getTextBeforeCursor(1, 0)
        if (before.isNullOrEmpty()) setShift(true)
    }

    // Được gọi sau khi commit dấu cách hoặc Enter (ranh giới từ/câu) trong
    // onKey(). CAP_WORDS luôn bật Shift cho từ kế tiếp; CAP_SENTENCES chỉ
    // bật khi từ vừa kết thúc là cuối câu (đứng ngay sau dấu . ! ? hoặc
    // đang ở đầu ô nhập). Không làm gì nếu Caps Lock đang bật thủ công
    // (CAP_CHARACTERS hoặc người dùng tự double-tap Shift) — không ghi
    // đè lựa chọn của người dùng.
    private fun maybeAutoCapitalizeAfterBoundary() {
        if (autoCapFlags == 0 || capsLock) return
        if (autoCapFlags and EditorInfo.TYPE_TEXT_FLAG_CAP_WORDS != 0) {
            setShift(true)
            return
        }
        if (autoCapFlags and EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES != 0) {
            val before = currentInputConnection?.getTextBeforeCursor(4, 0)?.toString().orEmpty()
            val trimmed = before.trimEnd()
            if (trimmed.isEmpty() || trimmed.last() in charArrayOf('.', '!', '?')) {
                setShift(true)
            }
        }
    }

    // Maps a letter/digit to its Android KeyEvent code so Ctrl/Alt combos
    // (Ctrl+C, Ctrl+V, Ctrl+Z, Alt+Tab-style shortcuts, ...) can be sent
    // as real key events instead of going through Telex composition.
    private fun keyEventCodeFor(c: Char): Int? = when (c) {
        in 'a'..'z' -> KeyEvent.KEYCODE_A + (c - 'a')
        in '0'..'9' -> KeyEvent.KEYCODE_0 + (c - '0')
        else -> null
    }

    private fun currentMetaState(): Int {
        var meta = 0
        if (ctrlOn) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (altOn) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        return meta
    }

    private fun sendKeyCodeWithModifiers(keyCode: Int) {
        val ic = currentInputConnection ?: return
        val meta = currentMetaState()
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
    }

    // Arrow-pad cursor movement. Sent as real DPAD KeyEvents (not
    // InputConnection.setSelection) because that's what lets standard
    // Android EditTexts apply their own built-in behavior for free:
    // Ctrl+Left/Right jumps by word and Shift+arrow would extend a
    // selection, exactly like a physical keyboard's arrow keys. Custom
    // text widgets that don't handle DPAD key events won't move, but that
    // matches the existing Ctrl+C/V-style shortcuts elsewhere in this
    // file, which rely on the same mechanism.
    private fun sendCursorKey(keyCode: Int) {
        val ic = currentInputConnection ?: return
        // Moving the cursor away ends whatever Telex word was mid-compose;
        // same "just stop tracking, don't touch the committed text" logic
        // as the external-cursor-move case in onUpdateSelection().
        resetWord()
        val ctrlWasOn = ctrlOn
        val meta = currentMetaState()
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, keyCode, 0, meta))
        ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, keyCode, 0, meta))
        // Ctrl is a one-shot modifier everywhere else in this app (arms
        // for exactly one following key, then clears) — keep arrow keys
        // consistent with that instead of leaving it stuck on.
        if (ctrlWasOn) clearModifiers()
    }

    // Shared by the 4 arrow buttons: fire once immediately on press, then
    // keep firing on a timer for as long as the finger stays down, same
    // feel as the keyboard's own isRepeatable backspace key. Plain
    // toolbar Views have no built-in repeat support, so it's done by hand
    // with a Handler here.
    private fun setupRepeatingPress(view: View, action: () -> Unit) {
        val repeatRunnable = object : Runnable {
            override fun run() {
                action()
                repeatHandler.postDelayed(this, REPEAT_INTERVAL_MS)
            }
        }
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    action()
                    repeatHandler.postDelayed(repeatRunnable, REPEAT_INITIAL_DELAY_MS)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    repeatHandler.removeCallbacks(repeatRunnable)
                }
            }
            true
        }
    }

    // deleteSurroundingText(1, 0) xoá đúng 1 code unit UTF-16, không phải 1
    // ký tự hiển thị. Với emoji nằm ngoài BMP (biểu diễn bằng surrogate
    // pair — 2 code unit), gọi thẳng deleteSurroundingText(1, 0) sẽ chỉ xoá
    // một nửa, để lại surrogate mồ côi gây lỗi hiển thị/crash ở một số app.
    // Hàm này kiểm tra 2 code unit ngay trước con trỏ, nếu đúng là một cặp
    // surrogate thì xoá cả 2 cùng lúc.
    private fun deleteOneCharacterBeforeCursor() {
        val ic = currentInputConnection ?: return

        // Một số app tự vẽ ô nhập liệu riêng (Samsung Galaxy Store, Samsung
        // Internet, vài SearchView tùy biến khác...) không hỗ trợ đúng
        // deleteSurroundingText: lệnh gọi trả về "thành công" nhưng không
        // có ký tự nào bị xoá trên màn hình. Dấu hiệu nhận biết đáng tin
        // cậy nhất là getExtractedText() trả về null — các widget kiểu này
        // thường không cài API extract-text luôn. Với chúng, fallback sang
        // gửi sự kiện phím Backspace vật lý thật (KEYCODE_DEL), vì đường
        // dispatch phím thường thì hầu như widget nào cũng xử lý được.
        //
        // Riêng trình duyệt web (Chrome/Samsung Internet/WebView nhúng
        // trong app khác...): ô nhập trên trang web (thanh địa chỉ omnibox,
        // ô tìm kiếm/textarea trong nội dung HTML) khai báo inputType có
        // cờ biến thể TYPE_TEXT_VARIATION_WEB_* và VẪN trả về
        // getExtractedText() khác null — nên nhánh trên không bắt được ca
        // này — nhưng deleteSurroundingText tới nội dung web lại thường
        // không được cầu nối InputConnection của WebView xử lý đúng, nên
        // phím xoá bấm mà không thấy ký tự nào mất. Coi các trường web này
        // cũng "không đáng tin cậy" như trên và luôn dùng KEYCODE_DEL.
        val info = currentEditorInfo
        val isWebField = info != null && (info.inputType and EditorInfo.TYPE_MASK_VARIATION) in setOf(
            EditorInfo.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT,
            EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            EditorInfo.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
        )
        if (isWebField) {
            ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL, 0))
            ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL, 0))
            return
        }

        val extracted = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
        if (extracted == null) {
            ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL, 0))
            ic.sendKeyEvent(KeyEvent(0, 0, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL, 0))
            return
        }

        val before = ic.getTextBeforeCursor(2, 0)
        if (before != null && before.length == 2 &&
            Character.isSurrogatePair(before[0], before[1])
        ) {
            ic.deleteSurroundingText(2, 0)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    private fun updateComposing(newComposed: String) {
        val ic = currentInputConnection ?: return
        if (composedLength > 0) {
            ic.deleteSurroundingText(composedLength, 0)
        }
        ic.commitText(newComposed, 1)
        composedLength = newComposed.length
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                if (rawBuffer.isNotEmpty()) {
                    rawBuffer.deleteCharAt(rawBuffer.length - 1)
                    if (rawBuffer.isEmpty()) {
                        updateComposing("")
                        resetWord()
                    } else {
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    }
                } else {
                    deleteOneCharacterBeforeCursor()
                }
                clearModifiers()
            }

            KEYCODE_SHIFT -> {
                val now = System.currentTimeMillis()
                when {
                    capsLock -> {
                        // Any tap while Caps Lock is on releases it.
                        setCapsLock(false)
                    }
                    now - lastShiftTapTime < DOUBLE_TAP_MS -> {
                        // Double-tap -> Caps Lock on (stays on across words
                        // until Shift or the Caps Lock key is tapped again).
                        setCapsLock(true)
                    }
                    else -> {
                        // Single tap -> one-shot arm/disarm for just the
                        // next letter.
                        setShift(!capsOn)
                    }
                }
                lastShiftTapTime = now
            }

            KEYCODE_CAPSLOCK -> {
                // Dedicated Caps Lock key next to "a": a plain on/off
                // toggle, no double-tap needed.
                setCapsLock(!capsLock)
            }

            Keyboard.KEYCODE_MODE_CHANGE -> {
                // Always lands on symbols PAGE 1, regardless of which
                // symbols page was showing — predictable re-entry point
                // instead of remembering whatever page was last open.
                keyboardView.keyboard =
                    if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
                // Symbols keyboard has no Shift key; resync the qwerty
                // Shift key's highlight for whenever we switch back to it.
                setModifierKeyVisual(KEYCODE_SHIFT, capsOn)
                clearModifiers()
            }

            KEYCODE_SYMBOLS_PAGE -> {
                keyboardView.keyboard =
                    if (keyboardView.keyboard === symbolsKeyboard) symbolsKeyboard2 else symbolsKeyboard
                clearModifiers()
            }

            KEYCODE_CTRL -> toggleCtrl()

            KEYCODE_ALT -> toggleAlt()

            KEYCODE_LANG_TOGGLE -> toggleVietnamese()

            -4 -> { // Enter / hành động của ô nhập (Tìm/Gửi/Tiếp/Xong...)
                handleWordBoundary(ic, isSentenceEnd = true)
                if (ctrlOn || altOn) {
                    // Ctrl/Alt+Enter là tổ hợp phím tắt (vd. xuống dòng
                    // cưỡng bức trong ô có action Gửi) — luôn gửi Enter
                    // thật, không gọi performEditorAction ở đây.
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_ENTER)
                    clearModifiers()
                } else {
                    sendEnter(ic)
                    maybeAutoCapitalizeAfterBoundary()
                }
            }

            32 -> { // space = word boundary
                if (ctrlOn || altOn) {
                    sendKeyCodeWithModifiers(KeyEvent.KEYCODE_SPACE)
                    clearModifiers()
                } else {
                    handleWordBoundary(ic, isSentenceEnd = false)
                    ic.commitText(" ", 1)
                    maybeAutoCapitalizeAfterBoundary()
                }
            }

            else -> {
                var c = primaryCode.toChar()
                c = if (capsOn) c.uppercaseChar() else c.lowercaseChar()

                if (ctrlOn || altOn) {
                    // Ctrl/Alt + letter or digit = shortcut, not Telex text.
                    val keyCode = keyEventCodeFor(c.lowercaseChar())
                    if (keyCode != null) {
                        sendKeyCodeWithModifiers(keyCode)
                    } else {
                        // No shortcut mapping for this key (e.g. Ctrl + a
                        // symbol like "/") — fall back to committing the
                        // character literally instead of silently eating it.
                        ic.commitText(c.toString(), 1)
                    }
                    resetWord()
                    clearModifiers()
                } else if (c.isLetter() && keyboardView.keyboard === qwertyKeyboard) {
                    // Telex composition only ever applies on the QWERTY
                    // layer. A few symbols-page-2 characters (e.g. "π")
                    // are technically Unicode letters too, but they're
                    // meant to be inserted as-is, never fed through Telex.
                    if (vietnameseOn) {
                        rawBuffer.append(c)
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    } else {
                        // EN mode: type the letter literally, no Telex
                        // transformation, no composing buffer to manage.
                        ic.commitText(c.toString(), 1)
                    }
                } else {
                    // punctuation etc. = word boundary
                    handleWordBoundary(ic, isSentenceEnd = c in sentenceEnders)
                    ic.commitText(c.toString(), 1)
                }

                // Caps Lock stays on across letters/words; the one-shot
                // arm (from a single Shift tap) clears after this one letter.
                if (capsOn && !capsLock) {
                    setShift(false)
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {
        // Phản hồi rung nhẹ mỗi lần chạm phím — đúng như PRIVACY_POLICY.md
        // đã mô tả ("Rung: dùng cho phản hồi rung khi gõ phím") nhưng
        // trước đây KHÔNG có dòng code nào thực sự gọi rung, nên tính năng
        // này chưa từng hoạt động dù đã được quảng cáo trong chính sách.
        // performHapticFeedback() tự tôn trọng cài đặt "Rung khi gõ phím"
        // của hệ thống (Settings > Âm thanh & rung) và KHÔNG cần quyền
        // VIBRATE trong Manifest — khác với android.os.Vibrator thô — nên
        // quyền VIBRATE (không hề được dùng ở đâu khác) đã được bỏ khỏi
        // AndroidManifest.xml, giảm bớt quyền không cần thiết khi nộp lên
        // Play Store (quan trọng với app bàn phím, vốn đã bị soi permission
        // kỹ hơn bình thường). Không truyền FLAG_IGNORE_GLOBAL_SETTING —
        // đúng như PRIVACY_POLICY.md mô tả, chỉ rung "nếu bạn bật tính
        // năng rung trên hệ thống", tôn trọng lựa chọn của người dùng.
        if (::keyboardView.isInitialized) {
            keyboardView.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}

    // Đã bỏ hẳn cử chỉ vuốt: cả 4 hướng trái/phải/lên/xuống lẫn tính năng
    // gõ vuốt (glide typing, trước dùng handleGlideTouch()/GlideTrailView/
    // GlideTypingEngine để vẽ trail + nhận diện từ theo đường vuốt) đều đã
    // gỡ. Interface OnKeyboardActionListener vẫn bắt buộc override 4 hàm
    // swipe nên giữ lại nhưng để rỗng (no-op); KeyboardView giờ xử lý mọi
    // sự kiện chạm hoàn toàn theo cơ chế mặc định của nó (chạm phím nào gõ
    // phím đó), không còn OnTouchListener nào can thiệp song song nữa.
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
