package com.example.telexkeyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class TelexIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var qwertyKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    // Raw Telex keystrokes typed since the last word boundary (space,
    // punctuation, enter). Re-transformed into Vietnamese on every keystroke.
    private val rawBuffer = StringBuilder()

    // Length (in chars) of the Vietnamese text currently composed & sent
    // to the editor for rawBuffer, so we know how much to delete before
    // sending the updated version.
    private var composedLength = 0

    private var capsOn = false

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView
        qwertyKeyboard = Keyboard(this, R.xml.keyboard_qwerty)
        symbolsKeyboard = Keyboard(this, R.xml.keyboard_symbols)
        keyboardView.keyboard = qwertyKeyboard
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.isPreviewEnabled = true
        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        keyboardView.keyboard = qwertyKeyboard
    }

    override fun onFinishInput() {
        super.onFinishInput()
        resetWord()
    }

    private fun resetWord() {
        rawBuffer.setLength(0)
        composedLength = 0
    }

    private fun updateComposing(newComposed: String) {
        val ic = currentInputConnection ?: return
        if (composedLength > 0) {
            ic.deleteSurroundingText(composedLength, 0)
        }
        ic.commitText(newComposed, 1)
        composedLength = newComposed.length
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                if (rawBuffer.isNotEmpty()) {
                    rawBuffer.deleteCharAt(rawBuffer.length - 1)
                    if (rawBuffer.isEmpty()) {
                        updateComposing("")
                        resetWord()
                    } else {
                        updateComposing(TelexEngine.transform(rawBuffer.toString()))
                    }
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
            }

            Keyboard.KEYCODE_SHIFT -> {
                capsOn = !capsOn
                qwertyKeyboard.isShifted = capsOn
                keyboardView.invalidateAllKeys()
            }

            Keyboard.KEYCODE_MODE_CHANGE -> {
                keyboardView.keyboard =
                    if (keyboardView.keyboard === qwertyKeyboard) symbolsKeyboard else qwertyKeyboard
            }

            -4 -> { // Enter / Done
                resetWord()
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
            }

            32 -> { // space = word boundary
                resetWord()
                ic.commitText(" ", 1)
            }

            else -> {
                var c = primaryCode.toChar()
                c = if (capsOn) c.uppercaseChar() else c.lowercaseChar()

                if (c.isLetter()) {
                    rawBuffer.append(c)
                    updateComposing(TelexEngine.transform(rawBuffer.toString()))
                } else {
                    // punctuation etc. = word boundary
                    resetWord()
                    ic.commitText(c.toString(), 1)
                }

                if (capsOn) {
                    capsOn = false
                    qwertyKeyboard.isShifted = false
                    keyboardView.invalidateAllKeys()
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
