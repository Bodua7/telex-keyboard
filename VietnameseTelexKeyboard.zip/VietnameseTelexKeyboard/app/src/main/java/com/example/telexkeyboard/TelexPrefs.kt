package com.example.telexkeyboard

import android.content.Context
import android.content.SharedPreferences

/**
 * Single source of truth for the app's SharedPreferences file name and key
 * names. Both TelexIME (reads settings while typing) and SetupActivity
 * (writes settings from the UI) go through this object instead of
 * hard-coding "telex_prefs" and each key string separately — a typo in one
 * of the two places used to mean a setting silently stopped working with
 * no error, since SharedPreferences just returns the default value for an
 * unknown key.
 */
object TelexPrefs {
    private const val FILE_NAME = "telex_prefs"

    // Pinned clipboard content lives in ITS OWN SharedPreferences file,
    // separate from ordinary settings (keyboard size, auto-fix toggles).
    // That split is what lets res/xml/backup_rules.xml and
    // res/xml/data_extraction_rules.xml exclude just this one file from
    // Android's automatic backup — backup/extraction rules only operate at
    // file granularity, not per-key, so pinned clipboard text (which could
    // be anything the user copied) can't leave the device via backup while
    // harmless settings still restore normally on a new device. Keep this
    // file name in sync with both XML files if it's ever renamed.
    private const val CLIPBOARD_FILE_NAME = "telex_clipboard_prefs"

    const val KEY_KEYBOARD_SIZE = "keyboard_size"
    // Only read when KEY_KEYBOARD_SIZE == 3 ("Tùy chỉnh"/custom). Stores the
    // desired per-row key height in dp, chosen by the user via a slider —
    // the 3 built-in presets (0/1/2) are fixed at 34/44/54dp, this lets
    // any value in between (or slightly beyond) be picked instead.
    const val KEY_KEYBOARD_CUSTOM_HEIGHT_DP = "keyboard_custom_height_dp"
    // Cỡ chữ trên phím (sp) — độc lập với "kích thước bàn phím" (chiều cao
    // hàng phím) ở trên, áp dụng luôn bất kể đang ở preset Nhỏ/Vừa/Lớn hay
    // Tùy chỉnh. Mặc định 26 khớp android:keyTextSize cố định trước đây
    // trong ime_container.xml.
    const val KEY_KEYBOARD_TEXT_SIZE_SP = "keyboard_text_size_sp"
    const val KEY_AUTO_FIX_ENGLISH = "auto_fix_english"
    const val KEY_AUTO_FIX_DIACRITICS = "auto_fix_diacritics"
    const val KEY_CLIPBOARD_PINNED = "clipboard_pinned"

    fun of(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun clipboardOf(context: Context): SharedPreferences =
        context.getSharedPreferences(CLIPBOARD_FILE_NAME, Context.MODE_PRIVATE)
}
