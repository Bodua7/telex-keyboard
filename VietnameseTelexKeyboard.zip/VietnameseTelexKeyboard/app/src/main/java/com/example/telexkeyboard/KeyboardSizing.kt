package com.example.telexkeyboard

import android.inputmethodservice.Keyboard

/**
 * Logic dùng chung cho 3 mốc cỡ bàn phím có sẵn (nhỏ/vừa/lớn) + thanh
 * trượt "Tùy chỉnh" liên tục — dùng bởi cả TelexIME (áp cỡ thật lúc gõ)
 * lẫn SetupActivity (vẽ preview cùng cỡ đó ngay trong màn Cài đặt). Gom
 * về một chỗ để 2 nơi không bao giờ lệch nhau, giống cách TelexPrefs.kt
 * đã gom tên key SharedPreferences.
 */
object KeyboardSizing {
    // 0=nhỏ, 1=vừa, 2=lớn, 3=tùy chỉnh (dùng layout "vừa" làm khung gốc,
    // scaleKeyboardHeight() bên dưới scale nó theo chiều cao người dùng
    // chọn qua SeekBar).
    fun qwertyRes(size: Int): Int = when (size) {
        0 -> R.xml.keyboard_qwerty_small
        2 -> R.xml.keyboard_qwerty_large
        else -> R.xml.keyboard_qwerty
    }

    fun symbolsRes(size: Int): Int = when (size) {
        0 -> R.xml.keyboard_symbols_small
        2 -> R.xml.keyboard_symbols_large
        else -> R.xml.keyboard_symbols
    }

    fun symbols2Res(size: Int): Int = when (size) {
        0 -> R.xml.keyboard_symbols2_small
        2 -> R.xml.keyboard_symbols2_large
        else -> R.xml.keyboard_symbols2
    }

    // android.inputmethodservice.Keyboard KHÔNG có method resize() công
    // khai (đã từng gọi nhầm method không tồn tại này, gây lỗi build
    // "Unresolved reference: resize") và cũng không có setter công khai
    // cho chiều cao/tọa độ phím, nên tự làm thủ công:
    // 1) Dịch y và height của TỪNG phím (Keyboard.Key.x/y/width/height là
    //    field public) theo scale — chỉ đổi chiều DỌC, giữ nguyên x/width
    //    vì tính năng chỉ chỉnh "chiều cao mỗi hàng phím".
    // 2) Ghi lại tổng chiều cao vào field riêng tư mTotalHeight — không
    //    có setter công khai, nhưng KeyboardView.onMeasure() đọc
    //    getHeight() (= mTotalHeight) để tính chiều cao view, không tự
    //    suy ra từ vị trí phím.
    // Bọc try/catch quanh phần reflection riêng: nếu một bản OEM đổi tên
    // field, các phím vẫn đã được scale đúng ở bước 1 (nhìn gần đúng),
    // chỉ có báo cáo getHeight() là không khớp tuyệt đối — không crash.
    fun scaleKeyboardHeight(kb: Keyboard, scale: Float) {
        val newHeight = (kb.height * scale).toInt().coerceAtLeast(1)
        for (key in kb.keys) {
            key.y = (key.y * scale).toInt()
            key.height = (key.height * scale).toInt().coerceAtLeast(1)
        }
        try {
            val field = Keyboard::class.java.getDeclaredField("mTotalHeight")
            field.isAccessible = true
            field.setInt(kb, newHeight)
        } catch (e: Exception) {
            // Xem comment ở trên: các phím đã scale, chỉ getHeight() lệch.
        }
    }
}
